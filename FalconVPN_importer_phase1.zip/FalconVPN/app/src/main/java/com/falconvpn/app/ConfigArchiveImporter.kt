package com.falconvpn.app

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/**
 * Safe, bounded reader for ZIP bundles containing text-based VPN exports.
 * Entries are read in-memory only; archive paths are never written to disk.
 */
internal object ConfigArchiveImporter {
    data class TextEntry(val name: String, val text: String)

    private const val MAX_ENTRIES = 50
    private const val MAX_TOTAL_UNCOMPRESSED = 5 * 1024 * 1024
    private const val MAX_ENTRY_BYTES = 2 * 1024 * 1024
    private val allowedExtensions = setOf("txt", "json", "conf", "config", "yaml", "yml", "list", "vmess", "vless", "ss", "uri")

    fun isZip(bytes: ByteArray): Boolean = bytes.size >= 4 &&
        bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte() &&
        (bytes[2] == 0x03.toByte() || bytes[2] == 0x05.toByte() || bytes[2] == 0x07.toByte())

    fun readTextEntries(bytes: ByteArray): List<TextEntry> {
        require(isZip(bytes)) { "الملف ليس أرشيف ZIP." }
        val result = mutableListOf<TextEntry>()
        var total = 0
        var count = 0
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                count++
                require(count <= MAX_ENTRIES) { "الأرشيف يحتوي على ملفات كثيرة جدًا." }
                val ext = entry.name.substringAfterLast('.', "").lowercase()
                if (ext !in allowedExtensions) continue
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var entryBytes = 0
                while (true) {
                    val n = zip.read(buffer)
                    if (n < 0) break
                    entryBytes += n
                    total += n
                    require(entryBytes <= MAX_ENTRY_BYTES) { "أحد ملفات الأرشيف أكبر من 2 ميجابايت." }
                    require(total <= MAX_TOTAL_UNCOMPRESSED) { "إجمالي محتوى الأرشيف أكبر من 5 ميجابايت." }
                    out.write(buffer, 0, n)
                }
                val content = out.toByteArray()
                val text = runCatching {
                    Charsets.UTF_8.newDecoder()
                        .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                        .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                        .decode(java.nio.ByteBuffer.wrap(content)).toString()
                }.getOrNull()
                if (!text.isNullOrBlank()) result += TextEntry(entry.name, text)
                zip.closeEntry()
            }
        }
        return result
    }
}
