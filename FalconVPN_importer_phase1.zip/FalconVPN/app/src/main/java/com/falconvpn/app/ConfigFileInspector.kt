package com.falconvpn.app

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Identifies imported configuration containers before text parsing.
 * It deliberately never guesses credentials or treats encrypted bytes as UTF-8.
 */
internal object ConfigFileInspector {
    data class Inspection(val format: String, val isText: Boolean, val message: String? = null)

    fun inspect(bytes: ByteArray, displayName: String = ""): Inspection {
        require(bytes.isNotEmpty()) { "الملف فارغ." }
        val name = displayName.lowercase(Locale.ROOT)
        val head = bytes.copyOfRange(0, minOf(bytes.size, 16))
        val ascii = head.toString(Charsets.ISO_8859_1)

        if (ascii.startsWith("NPVS")) return Inspection(
            "NPVS", false,
            "تم التعرف على ملف NapsternetV (NPVS). هذا الإصدار يحتاج محلل NPVS متخصصًا؛ لن نحاول تحويل البيانات الثنائية إلى نص أو إنشاء كونفج غير صحيح."
        )
        if (ascii.startsWith("NPVT1") || ascii.startsWith("NPVTSUB1")) return Inspection(
            "NPVT", true
        )
        if (ascii.startsWith("HCX1") || ascii.startsWith("HCCFG") || name.endsWith(".hc")) return Inspection(
            "HTTP Custom", false,
            "تم التعرف على ملف HTTP Custom. تختلف بنية HC حسب إصدار التطبيق والحماية؛ يلزم محلل متوافق مع إصدار الملف قبل تحويله إلى sing-box."
        )
        if (name.endsWith(".ehi")) return Inspection("HTTP Injector", false,
            "تم التعرف على ملف HTTP Injector (.ehi)، ويحتاج محلل EHI مخصصًا.")
        if (name.endsWith(".hat")) return Inspection("HA Tunnel", false,
            "تم التعرف على ملف HA Tunnel (.hat)، ويحتاج محلل HAT مخصصًا.")
        if (name.endsWith(".json") || name.endsWith(".txt") || name.endsWith(".conf") ||
            name.endsWith(".yaml") || name.endsWith(".yml") || name.endsWith(".npvt")) {
            return Inspection("TEXT", true)
        }

        val decoded = try {
            StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: Exception) {
            return Inspection("BINARY_UNKNOWN", false,
                "الملف ثنائي أو مشفر وغير معروف. لم يتم تغيير محتواه أو حفظ بيانات غير مفهومة.")
        }
        val printable = decoded.count { it == '\\n' || it == '\\r' || it == '\\t' || it >= ' ' }
        if (decoded.isNotBlank() && printable.toDouble() / decoded.length >= 0.92) {
            return Inspection("TEXT", true)
        }
        return Inspection("UNKNOWN", false, "صيغة الملف غير معروفة أو لا يمكن قراءتها كنص.")
    }
}
