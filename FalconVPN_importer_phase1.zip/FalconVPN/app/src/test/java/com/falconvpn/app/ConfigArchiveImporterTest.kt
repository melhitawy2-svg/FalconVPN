package com.falconvpn.app

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ConfigArchiveImporterTest {
    private fun zip(vararg files: Pair<String, String>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { stream ->
            files.forEach { (name, content) ->
                stream.putNextEntry(ZipEntry(name))
                stream.write(content.toByteArray(Charsets.UTF_8))
                stream.closeEntry()
            }
        }
        return out.toByteArray()
    }

    @Test fun detectsZipMagic() {
        assertTrue(ConfigArchiveImporter.isZip(zip("list.txt" to "vless://example")))
        assertFalse(ConfigArchiveImporter.isZip("not zip".toByteArray()))
    }

    @Test fun readsOnlyTextConfigEntries() {
        val archive = zip("configs/list.txt" to "vless://one.example:443", "image.png" to "ignored")
        val entries = ConfigArchiveImporter.readTextEntries(archive)
        assertEquals(1, entries.size)
        assertEquals("vless://one.example:443", entries.single().text)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTooManyEntries() {
        val files = (1..51).map { "f$it.txt" to "vless://host.example:443" }.toTypedArray()
        ConfigArchiveImporter.readTextEntries(zip(*files))
    }
}
