# Falcon VPN importer – phase 1

This change adds bounded, in-memory ZIP bundle ingestion to the existing Android file/share import route.

- ZIP entries are never extracted to disk, so archive paths cannot perform Zip Slip writes.
- Limits: 50 entries, 2 MiB per accepted text entry, 5 MiB total uncompressed data.
- Only text-like config extensions are inspected; non-UTF-8 entries are ignored.
- Extracted text is passed through the existing link / Base64 subscription / sing-box JSON validation and user confirmation flow.
- Existing Libbox runtime, VPN service, profile store and visual assets are unchanged.

## Not yet implemented

Encrypted proprietary decoders for NPVS, HTTP Custom HCX1/HCCFG, EHI and HAT are not included in this phase. The file inspector still identifies some of these formats and reports that a format-specific decoder is required. Pantegnos currently documents support for multiple formats, but its current AGPL-3.0 licensing must be evaluated before embedding or redistributing its code in Falcon VPN. Its documented limitations also include password/HWID-locked and unsupported HC variants.
