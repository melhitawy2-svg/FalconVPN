# Falcon VPN changelog

## v0.30.2 — Native VPN diagnostics and service binding
- Changed the protected VpnService declaration to exported=true so Android's system VPN manager can bind to the service; the required BIND_VPN_SERVICE permission remains enforced.
- Added stage-by-stage Libbox startup status and Logcat error details without logging credentials or generated config JSON.
- Added a real HTTPS connectivity probe through the app UID, reporting Android VPN transport and observed public IP/country/ASN.
- Improved missing-profile guidance and native startup failure messages.
- Preserved the existing HTML UI and visual styling.

# Changelog

Per-version notes from v0.14 to v0.27.0 are kept unchanged in `docs/history/`.

## v0.30.0 — all protocol forms are real; storage bug fixed — NOT compiled or run on a device

Design and the list of services are unchanged.

- **Fixed:** `domStorageEnabled` was false while the page writes to `localStorage` (account, profile, logout) -> now true
  (only the bundled asset origin is ever loaded).
- **New engine support** (`ServiceProfiles.kt`): VMess, Trojan, Hysteria2, TUIC, WireGuard (sing-box endpoint), SOCKS5,
  HTTP proxy, SSH, Custom JSON (one outbound only). Forms save through the new bridge method `saveService`.
- **New link schemes:** `vmess://`, `trojan://`, `hysteria2://` / `hy2://` (paste, file, share sheet, VIEW intents).
  `insecure` / `allowInsecure` is rejected in links; only the explicit Hysteria2 form toggle can set it.
- **Subscriptions:** "Import URL" with an `https://` link downloads it natively (2 MB, 10 s, no redirects) and imports the links in it.
- **SOCKS and HTTP Proxy forms were empty** (no schema) -> added.
- **Honesty:** OpenVPN, UDP Custom, Psiphon, One Cloud cannot run on sing-box; they now say so instead of "saving" a fake profile.
- Content-Security-Policy added to the page. Stale `ENGINE_DECISION.md` corrected.
- Tests: `ServiceProfilesTest.kt` (Kotlin, not run here), `tools/ui_test.py` 51 checks pass.

### Still NOT real (needs a server / SDK that does not exist in this project)
Accounts/login, subscriptions/payments, community chat, rewarded ads + the ad gate, per-country server lists
(empty), "free internet services" configs (empty). They remain local previews.

## v0.29.3 — menu "إضافة / اختيار اتصال" lists the connection models

- The side-menu entry opened the country-flags browser by mistake. It now opens the list of connection models
  (SSH, VLESS, VMess, Shadowsocks, Trojan, OpenVPN, UDP Custom, Hysteria2, TUIC, WireGuard, Psiphon, One Cloud,
  SOCKS, HTTP, Custom JSON, Import URL). Each opens its form; "رجوع" in a form returns to this list.
- The flags / عام-بلاس-برو picker stays only in the "اختيار سيرفر" box on the home page. No Kotlin changes.
- `tools/ui_test.py`: 36 checks pass. Version 0.29.3 (versionCode 39).

## v0.29.2 — country-flags design (the intended one) — NOT compiled or run on a device

v0.29.1 restored the v0.27.0 preview, which had dropped the country flags. The intended design is the flags one
(the v0.28 page, `docs/legacy/index_v0.28_demo_ui.html.gz`). This release uses it, with the same native wiring as v0.29.1.

### Design (as requested)
- Row of all 22 Arab flags above the boxes; the visitor's country is detected (device language / time zone first, IP lookup
  refines it) and its flag is lit. Tapping a flag switches the country.
- "اختيار سيرفر" box: tabs عام / بلاس / برو. عام shows the country flags grid (2 per row, flag + name). بلاس / برو replace
  that same area with the subscription offer and a button to the subscription page. The box holds countries only (no protocols).
- "خدمات الإنترنت المجاني" box: shows «خدمات دولة <country>»; "اختيار خدمة" -> خطوط / راوتر / eSIM / أخرى -> provider
  (e.g. Egypt: فودافون / اتصالات / أورنج / WE) -> configs.
- Protocol forms (SSH, VLESS, VMess, Shadowsocks, ...) are reached from the side menu, as before.
- Fixed: under بلاس / برو the countries grid stayed visible next to the subscription card (CSS `display` overrode `hidden`).
- Import dialog (text / file) now really saves `ss://` and `vless://` links through the bridge and shows rejected lines.

### Native wiring: unchanged from v0.29.1 (status/timer, real speeds, form -> importLinks, back button). No Kotlin changes.
Version 0.29.2 (versionCode 38). `tools/ui_test.py`: 32 checks pass (flags, tiers, service types, forms, connect, status, back).

## v0.29.1 — original v0.27.0 design restored (NOT compiled or run on a device)

### Why
v0.29.0 replaced the approved UI with a different, simplified one. This release puts the approved design back
**exactly as in `FalconVPN-v0_27_0-preview.html`** (same layout, order, colours, map, bottom navigation, pages),
and only re-wires the places that talk to the native side. The v0.29.0 small UI is archived in
`docs/legacy/ui_v0.29.0_small_ui.tar.gz`.

### Native wiring changed (visuals untouched)
- Status/timer: reads `connectedAt` / `sessionEndsAt` / `now` from the v0.29 bridge (the old `remainingSeconds` no longer exists).
  Timer is now `HH:MM:SS` (shows connection uptime, or the remaining time when an auto-disconnect is set).
- Speeds: ↓/↑ and the map speed come from `trafficStats()` (real per-UID throughput). The hard-coded "12.6 Mbps" is gone.
- Saving: Shadowsocks and VLESS forms and `ss://` / `vless://` in "Import URL" build a link and call `importLinks()`
  (`saveShadowsocksFields` no longer exists). Rejection reasons from the parser are shown in the form.
- Saved list uses the v0.29 shape (`protocol`, `transport`, `security`) and marks the selected config after a restart.
- Hooks: `falconOnStatus` (instant push), `falconImportedConfig` (links opened from other apps), `falconHandleBack`
  (back closes dialogs / sub-pages before leaving the app).
- Unchanged native side: no Kotlin changes. Version 0.29.1 (versionCode 37).

### Still demo-only in this design (same as the v0.27.0 preview; no backend / SDK behind them)
- Accounts/login, subscriptions, community chat, rewarded-ad balance and the ad gate before connecting, AdMob slot.
- VMess, Trojan, SSH, OpenVPN, Hysteria2, TUIC, WireGuard, SOCKS, HTTP, Custom JSON forms: saved locally for the preview only;
  the sing-box engine here supports Shadowsocks and VLESS.
- The page has no CSP (inline scripts, as in the preview) and calls ipwho.is / speed.cloudflare.com for its tools.

### Verification
- `tools/ui_test.py` (mock bridge, headless Chromium): 24 checks pass (forms -> links, native select, connect flow, status push,
  real speeds, back button, no JS errors). A pixel comparison of the unconnected page against the original preview differs
  in ~50 pixels (live clock/animation), nothing structural.
- Kotlin was not touched and not compiled; first Gradle build and a device test are still the next step.

## v0.29.0 — real UI wired to the native services (NOT compiled or run; see "Verification")

### UI replaced
- `index.html` (1.6 MB, mostly demo) is replaced by a small page: `index.html` + `app.css` + `app.js` + `eagle.webp`.
  The old file is archived at `docs/legacy/index_v0.28_demo_ui.html.gz`.
- Every control is backed by a native call: import (paste / clipboard / file / Base64 subscription), list, select,
  delete (in-page confirmation, no `alert()`), connect / disconnect, live status, traffic counters, auto-disconnect.
- Removed because nothing real stands behind them (no backend, billing or ad SDK in this project): accounts and
  login (localStorage demo), subscriptions, community chat, AI helper, rewards / points, the simulated ad gate,
  the fake country/server lists, the AdMob placeholder, the JSZip file tools (loaded from a CDN).
- Strict CSP (`script-src 'self'`, no inline script, no network), no `innerHTML` with dynamic text.
- Served through `WebViewAssetLoader` from `https://appassets.androidplatform.net/assets/`; `file://` is not used.

### Services
- **Push instead of polling:** the service writes state to SharedPreferences, `MainActivity` pushes every change to
  the page (`window.falconOnStatus`). The page only ticks once a second while connected, to draw the uptime.
- Bridge reduced to 13 methods; `importLinks` handles ss:// and vless:// together (VLESS is now reachable from the UI).
- Traffic counters from `TrafficStats` (per-UID bytes on the real network).
- **Auto-disconnect** replaces the hard-coded fake 15-minute "free session": off by default, user-chosen.
  The service sets one timer instead of writing to disk every second.
- `setUnderlyingNetworks` is now set (Wi-Fi <-> mobile data switching).
- Selecting or deleting the config of a live tunnel is refused natively.
- Notification-permission denial no longer overwrites the connect state.

### Build / project
- Package unified: `com.falconvpn.app` (namespace, applicationId and sources).
- Compose, navigation and material-icons removed; `androidx.webkit` added. Launcher icon added.
- `-PfalconAbis=arm64-v8a,x86_64` selects ABIs. Broad VIEW `text/plain` / `application/json` filters removed.
- CI: headless-browser UI test job (`tools/ui_test.py`); optional `build-libbox.yml` (unverified recipe).

### Verification
- `tools/ui_test.py` (mock bridge, Chromium): 31 checks pass, including XSS, double-tap, push status and back button.
- The Kotlin changes were reviewed by reading only: no Gradle, Kotlin compiler or `libbox.aar` was available.
  First real build and a device test are still the next step.

### Still open
- Gradle wrapper (needs network to generate). JitPack AAR source (see `docs/BUILD_LIBBOX.md`).
- GPL-3.0 implications of sing-box. Play Console declaration for the `specialUse` foreground service.
- Accounts, subscriptions, ads and chat need a backend / SDKs before they can exist for real.

## v0.28.0 — security & robustness pass (NOT compiled or run; see "Verification")

### Security
- **Import confirmation.** `ss://` / `vless://` links or files opened from other apps are validated, then shown in a
  confirmation dialog. Nothing is stored until the user taps "استيراد". An existing selection is never replaced; a
  single imported config is selected only when nothing was selected before. Names are stripped of control / bidi
  characters before display.
- **Config never touches disk.** `SingBoxConfig.build()` returns the sing-box JSON as a String passed straight to
  libbox (`SingBoxConfigWriter` and the on-disk runtime file are gone). Also makes it unit-testable without a Context.
- **WebView.** `allowFileAccess=false`; navigation is limited to the bundled asset (http/https open externally,
  everything else is blocked).
- **CI.** libbox checksum mismatch now fails the build (was a warning).
- `usesCleartextTraffic` removed.

### Reliability
- **Start guard.** An atomic `engineActive` flag prevents a second CommandServer from a double tap / duplicate START
  (the service still calls `startForeground()` first, which Android requires). `connectVpn()` ignores duplicates.
- **Stale state.** `FalconVpnService.alive` + `reconcileStaleState()` reset a persisted CONNECTED/CONNECTING left by a
  killed process (on app start, on every status poll, and in `onDestroy`).
- **Rotation / recreation.** `configChanges` + `singleTask`; incoming intents are handled only on a fresh launch and are
  consumed afterwards (no re-import); `pendingConnectAfterPermission` survives recreation.
- **Android 15 edge-to-edge.** Insets (system bars, cutout, IME) applied to the WebView container.
- **Keystore.** An undecryptable store (invalidated key / corrupt data) is reset instead of crashing; the user is told once.

### Parsers (all errors are now import-time, not connect-time)
- No more `java.net.URI`: unencoded spaces, `|` and emoji in `#name` work; IPv6 hosts have no brackets.
- UUID: any hex 8-4-4-4-12 (no RFC 4122 version/variant requirement).
- VLESS: `flow` (xtls-rprx-vision), `fp`, `alpn`, **Reality** (`pbk`, `sid`), **grpc** (`serviceName`), **httpupgrade**,
  **http/h2** are implemented end to end. Rejected with a clear message: xhttp/kcp/quic, `allowInsecure=1`,
  VLESS `encryption` other than `none`, unknown `flow`, `headerType=http`.
- Shadowsocks: SIP003 `plugin=` (obfs-local / simple-obfs / v2ray-plugin) is honoured instead of silently dropped;
  legacy fully-Base64 links are supported; unknown plugins are rejected.
- Dead code removed (`toSingBoxConfig` with the old `inet4_address` schema, `VpnEngine.kt`).

### Engine config
- TUN `mtu` 1400; private/LAN destinations go `direct`; remote DNS is DoH through the proxy.

### UI
- Saved list shows the real protocol (VLESS no longer displayed as Shadowsocks).
- `window.falconImportedConfig` is now defined, so imported configs appear without restarting the app.

### Build / CI
- CI now runs `testDebugUnitTest` and uploads the report. Added `org.json` test dependency. JitPack repository removed.
- Notification icon replaced (`ic_stat_falcon`). Notification/intent-filter: `application/octet-stream` VIEW filter removed.
- Old status files moved to `docs/history/`.

### Verification
Nothing here has been compiled or run: the authoring environment had no network, JDK compiler, Kotlin or Gradle.
The first CI run is the first real compile. Expect to fix compile errors before anything else.

### Still open (not done in this pass)
- Build libbox from the official sing-box source instead of the third-party JitPack AAR; **GPL-3.0 licensing vs closed
  source + AdMob must be resolved before any release.**
- WebView: JSZip is still loaded from `cdn.jsdelivr.net` (bundle it locally), `alert()` calls, CSP meta,
  `WebViewAssetLoader`, 1s polling → push updates, `innerHTML` audit, 1.36 MB of base64 images.
- Remove demo-only pages (account / subscription / chat on `localStorage`) and the simulated ad gate before Google Play.
- Remove unused Compose / navigation / icons dependencies; add x86_64 ABI if libbox provides it;
  Gradle wrapper; unify `com.example.vpnstarter` package with `com.falconvpn.app`.
- `setUnderlyingNetworks`; foreground-service type declaration for Play Console.
