# Third-party notices

## Pantegnos

Falcon VPN bundles the Pantegnos source tree under `third_party/Pantegnos` and builds its WebAssembly decoder during the GitHub Actions APK workflow. Pantegnos is licensed under GNU Affero General Public License v3.0 (AGPL-3.0). The complete license is included at `third_party/Pantegnos/LICENSE`.

Upstream source snapshot supplied for this integration: `1bb2a6743e6d1dc85e9d5e38edad68975ad1fc37` (archive root commit identifier). The decoder runs locally in Android WebView; imported file bytes are not sent to a server.

The modified Falcon VPN project, including the integration glue, is distributed under the AGPL-3.0 terms applicable to this combined distribution.
