# Falcon VPN (Android)

WebView UI (`app/src/main/assets/index.html`, the country-flags design, single file) + native Kotlin VPN service on top of sing-box **libbox 1.13.14**.
Imports `ss://`, `vless://`, `vmess://`, `trojan://`, `hysteria2://` links and https subscriptions; forms for VMess, Trojan, Hysteria2, TUIC, WireGuard, SOCKS, HTTP, SSH, Custom JSON.

**Source revision: 0.31.11. Status: not yet compiled or run on a device — build it with GitHub Actions and test on a phone (see `docs/GITHUB_AND_APK.md`).** See `CHANGELOG.md` for changes and remaining verification.

## Build
CI: `.github/workflows/build.yml` downloads `libbox.aar` (SHA-256 pinned in `libbox.sha256`, see `docs/BUILD_LIBBOX.md`),
builds and uploads the debug APK, then runs the JVM unit tests and lint. First real run: `docs/TEST_ON_DEVICE.md`. Locally: put `libbox.aar` in `app/libs/` and run
`gradle testDebugUnitTest assembleDebug`.

## Layout
- `vpn/engine/` — `LinkSyntax`, `ShadowsocksLinkParser`, `VlessLinkParser`, `SingBoxConfig`, `SecureProfileStore`
  (pure Kotlin except the store; covered by tests in `app/src/test`).
- `vpn/platform/FalconVpnService.kt` — libbox `PlatformInterface` + `CommandServerHandler`, TUN, lifecycle.
- `com.falconvpn.app.MainActivity` — WebView host, native bridge, status push, import confirmation.
- `tools/ui_test.py` — UI logic tests against a mock bridge (needs `pip install playwright`).
- `docs/history/` — per-version notes up to v0.27.0.


## v0.30.1 connection-button fix
- The home power button now starts the native VPN connection flow immediately instead of waiting behind the unfinished AdMob test gate.
- Missing native bridge, missing selected profile, Android permission, and disconnect results are surfaced in the home status area.
- WebView JavaScript console messages are logged under the `FalconWebView` Android log tag for diagnosis.
- This change does not add VPN servers or configurations: import/select a valid profile before connecting. A successful APK build still does not prove a live server tunnel; test with a valid profile and inspect the service status.


## Encrypted configuration import

Encrypted exports supported by Pantegnos (including NPVS, NPVT, HC, EHI and HAT) are passed to the bundled local WebAssembly decoder before the normal Falcon profile parser. The decoder is built from `third_party/Pantegnos` by `.github/workflows/build.yml` using the Go version declared by that source tree. Decrypted output is still validated by Falcon's existing import parser and is not saved until the user confirms. See `THIRD_PARTY_NOTICES.md` for licensing.
