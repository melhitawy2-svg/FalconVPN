# FalconVPN service picker: config import verification

Updated `app/src/main/assets/builtin_services.json` from the user-provided `كونفج .txt` file.

## Imported entries

- Total entries: 19
- `router` (راوتر): 10
- `lines` (خطوط): 2
- `other` (أخرى): 6
- `protocol` (بروتوكول / VMess): 1

The service picker now has six top-level sections, retaining the existing four and adding the two requested sections:

1. خطوط
2. راوتر
3. eSIM
4. أخرى
5. كونفجات — lists all 19 built-in entries
6. ملفات — lists profiles saved/imported on the device through the Android profile store

Provider lists for the router and lines categories are derived from the actual built-in service data, so the imported configs appear under their assigned provider rather than only as empty placeholder options.

## Compatibility note

Nine entries use custom `nm-*` schemes (`nm-ssh`, `nm-xray-json`, `nm-trojan`, `nm-vless`). They are included and categorized for visibility, but the current app's standard link parser does not establish that these custom schemes are importable or connectable. The regular VLESS and VMess links can still fail if the remote endpoint is offline or the configuration is invalid. No server connectivity test was performed as part of this file/category change.

## Checks performed

- Parsed `builtin_services.json` successfully.
- Confirmed all 19 mapped URI entries were found in the provided text file.
- Ran `node --check` against all inline JavaScript blocks in the app page and preview; no syntax errors were reported.
- APK build and device runtime were not tested.
