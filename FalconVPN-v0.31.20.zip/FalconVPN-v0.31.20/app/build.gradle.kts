import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ABIs packaged in the APK. libbox.aar must contain the same ABIs. For an x86_64 emulator build:
//   gradle assembleDebug -PfalconAbis=arm64-v8a,x86_64
val falconAbis: List<String> = (project.findProperty("falconAbis") as String? ?: "arm64-v8a")
    .split(',').map { it.trim() }.filter { it.isNotEmpty() }

android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    namespace = "com.falconvpn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.falconvpn.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 65
        versionName = "0.31.20"
        ndk { abiFilters += falconAbis }
    }
}

dependencies {
    // sing-box libbox AAR, placed in app/libs/libbox.aar (see docs/BUILD_LIBBOX.md and the CI workflows).
    implementation(files("libs/libbox.aar"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    // Serves assets from https://appassets.androidplatform.net/ (secure origin, no file:// access needed).
    implementation("androidx.webkit:webkit:1.12.1")
    testImplementation("junit:junit:4.13.2")
    // Android's org.json is only a stub on the JVM; tests need the real implementation.
    testImplementation("org.json:json:20240303")
}


// Fail the build if the APK does not contain the built-in services and matching picker bridge.
// This prevents distributing an APK built from a stale/different source revision.
val verifyDebugApkContents by tasks.registering {
    dependsOn("assembleDebug")
    doLast {
        val apkFile = layout.buildDirectory.file("outputs/apk/debug/app-debug.apk").get().asFile
        check(apkFile.isFile) { "Debug APK was not produced: ${apkFile.absolutePath}" }
        ZipFile(apkFile).use { apk: ZipFile ->
            val servicesEntry = apk.getEntry("assets/builtin_services.json")
                ?: error("APK is missing assets/builtin_services.json. Refusing to publish an app with no built-in services.")
            val servicesJson = apk.getInputStream(servicesEntry).bufferedReader(Charsets.UTF_8).use { reader -> reader.readText() }
            check(servicesJson.contains("رفع سرعة راوتر WE") && servicesJson.contains("uk5.taskflowhub.org")) {
                "Packaged built-in services do not contain the WE router test profile."
            }
            val htmlEntry = apk.getEntry("assets/index.html")
                ?: error("APK is missing assets/index.html")
            val html = apk.getInputStream(htmlEntry).bufferedReader(Charsets.UTF_8).use { reader -> reader.readText() }
            check(html.contains("builtInServices") && html.contains("useBuiltInService")) {
                "APK HTML and native built-in-services bridge are from different source revisions."
            }
            val decoderEntry = apk.getEntry("assets/pantegnos.wasm")
                ?: error("APK is missing assets/pantegnos.wasm. Pantegnos decoder was not bundled.")
            check(decoderEntry.size > 1024L) { "Packaged Pantegnos WASM decoder is unexpectedly small." }
            val wasmRuntime = apk.getEntry("assets/wasm_exec.js")
                ?: error("APK is missing assets/wasm_exec.js. Go WASM runtime was not bundled.")
            check(wasmRuntime.size > 1024L) { "Packaged Go WASM runtime is unexpectedly small." }
            val bridgeEntry = apk.getEntry("assets/pantegnos-bridge.js")
                ?: error("APK is missing assets/pantegnos-bridge.js.")
            val bridge = apk.getInputStream(bridgeEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            check(bridge.contains("pantegnosInspect") && bridge.contains("pantegnosDecrypt") && bridge.contains("needsPassword")) {
                "Packaged Pantegnos bridge does not include inspect/decrypt/password handling."
            }
        }
        println("Verified APK contains WE built-in profile, service bridge, Pantegnos WASM decoder and Go runtime: ${apkFile.name}")
    }
}
