package com.falconvpn.app.vpn.engine

import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64

/**
 * Share-link / config-file parsers for the protocols sing-box can run that have no dedicated parser:
 * socks / socks4 / socks5, http(s) proxy, tuic, hysteria (v1), wireguard (link and .conf file), ssh.
 * Everything here is plain text parsing: nothing is decrypted, nothing is opened or connected.
 * Pure Kotlin + org.json, unit-testable on the JVM.
 */
object UniversalLinks {
    private val TRUE_VALUES = setOf("1", "true", "yes")

    /** Prefixes handled here. (http/https are matched separately because plain web URLs must not match.) */
    val PREFIXES = listOf("socks://", "socks4://", "socks5://", "tuic://", "hysteria://", "wireguard://", "wg://", "ssh://")

    /** An HTTP proxy link needs credentials AND an explicit port and no path, so an ordinary URL is never one. */
    private val HTTP_PROXY = Regex("(?i)^https?://[^\\s/@?#]+@[^\\s/?#]+:\\d+/?(?:#.*)?$")

    fun isUniversalLink(line: String): Boolean {
        val l = line.trim()
        return PREFIXES.any { l.startsWith(it, ignoreCase = true) } || HTTP_PROXY.matches(l)
    }

    /** Returns null when [raw] is not one of the schemes handled here. Throws IllegalArgumentException when it is but invalid. */
    fun fromLink(raw: String): GenericProfile? {
        val link = raw.trim()
        val lower = link.lowercase()
        return when {
            lower.startsWith("nm-ssh://") -> throw IllegalArgumentException("روابط nm-ssh:// (NetMod) تحتاج محلّلًا خاصًا وغير مدعومة حاليًا.")
            lower.startsWith("socks5://") -> socks(link.substring(9), "5")
            lower.startsWith("socks4://") -> socks(link.substring(9), "4")
            lower.startsWith("socks://") -> socks(link.substring(8), "5")
            lower.startsWith("tuic://") -> tuic(link.substring(7))
            lower.startsWith("hysteria://") -> hysteria(link.substring(11))
            lower.startsWith("wireguard://") -> wireguardLink(link.substring(12))
            lower.startsWith("wg://") -> wireguardLink(link.substring(5))
            lower.startsWith("ssh://") -> ssh(link.substring(6))
            HTTP_PROXY.matches(link) -> httpProxy(link)
            else -> null
        }
    }

    // ------------------------------------------------------------------ links

    private fun socks(body: String, version: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, _) = LinkSyntax.splitQuery(beforeFragment)
        val (user, pass, hostPart) = userInfoAndHost(main)
        val ep = LinkSyntax.parseHostPort(hostPart)
        val out = ServiceProfiles.base("socks", ep.host, ep.port).put("version", version)
        if (user.isNotEmpty()) out.put("username", user).put("password", pass)
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "SOCKS server" }
        return GenericProfile(name, "SOCKS", ep.host, ep.port, out)
    }

    private fun httpProxy(link: String): GenericProfile {
        val secure = link.startsWith("https://", ignoreCase = true)
        val body = link.substring(if (secure) 8 else 7)
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (user, pass, hostPart) = userInfoAndHost(beforeFragment)
        val ep = LinkSyntax.parseHostPort(hostPart)
        val out = ServiceProfiles.base("http", ep.host, ep.port)
        if (user.isNotEmpty()) out.put("username", user).put("password", pass)
        if (secure) out.put("tls", ServiceProfiles.tls(ep.host))
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { if (secure) "HTTPS proxy" else "HTTP proxy" }
        return GenericProfile(name, "HTTP Proxy", ep.host, ep.port, out)
    }

    private fun tuic(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val q = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        val at = main.lastIndexOf('@')
        require(at > 0) { "رابط TUIC لا يحتوي على UUID وكلمة المرور." }
        val cred = LinkSyntax.percentDecode(main.substring(0, at), lenient = true)
        val colon = cred.indexOf(':')
        require(colon > 0 && colon < cred.lastIndex) { "رابط TUIC يجب أن يكون uuid:password@host:port." }
        val ep = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))
        val congestion = q["congestion_control"].orEmpty().lowercase().ifEmpty { "bbr" }
        require(congestion in setOf("bbr", "cubic", "new_reno")) { "congestion_control غير مدعوم: ${LinkSyntax.sanitizeLabel(congestion, 20)}" }
        val tls = ServiceProfiles.tls(
            q["sni"].orEmpty().ifBlank { ep.host },
            insecure = (q["allow_insecure"] ?: q["allowinsecure"] ?: q["insecure"]).orEmpty().lowercase() in TRUE_VALUES
        )
        val alpn = q["alpn"].orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("h3") }
        tls.put("alpn", JSONArray(alpn))
        val out = ServiceProfiles.base("tuic", ep.host, ep.port)
            .put("uuid", ServiceProfiles.uuid(cred.substring(0, colon)))
            .put("password", cred.substring(colon + 1))
            .put("congestion_control", congestion)
            .put("tls", tls)
        q["udp_relay_mode"]?.lowercase()?.takeIf { it in setOf("native", "quic") }?.let { out.put("udp_relay_mode", it) }
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "TUIC server" }
        return GenericProfile(name, "TUIC", ep.host, ep.port, out)
    }

    private fun hysteria(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val q = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        val ep = LinkSyntax.parseHostPort(main.substringBefore('/'))
        fun mbps(vararg keys: String, default: Int): Int =
            keys.firstNotNullOfOrNull { q[it] }?.filter { it.isDigit() }?.toIntOrNull()?.coerceIn(1, 10_000) ?: default
        val tls = ServiceProfiles.tls(
            (q["peer"] ?: q["sni"]).orEmpty().ifBlank { ep.host },
            insecure = (q["insecure"] ?: q["allowinsecure"]).orEmpty().lowercase() in TRUE_VALUES
        )
        val alpn = q["alpn"].orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("h3") }
        tls.put("alpn", JSONArray(alpn))
        val out = ServiceProfiles.base("hysteria", ep.host, ep.port)
            .put("up_mbps", mbps("upmbps", "up", default = 50))
            .put("down_mbps", mbps("downmbps", "down", default = 100))
            .put("tls", tls)
        q["auth"]?.takeIf { it.isNotEmpty() }?.let { out.put("auth_str", it) }
        q["obfsparam"]?.takeIf { it.isNotEmpty() }?.let { out.put("obfs", it) }
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "Hysteria server" }
        return GenericProfile(name, "Hysteria", ep.host, ep.port, out)
    }

    private fun ssh(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, _) = LinkSyntax.splitQuery(beforeFragment)
        val (user, pass, hostPartRaw) = userInfoAndHost(main)
        require(user.isNotEmpty()) { "اسم مستخدم SSH مفقود." }
        require(pass.isNotEmpty()) { "كلمة مرور SSH مفقودة (المفاتيح الخاصة تُضاف من النموذج وليس من رابط)." }
        val hostPart = if (!hostPartRaw.startsWith("[") && !hostPartRaw.contains(':')) "$hostPartRaw:22" else hostPartRaw
        val ep = LinkSyntax.parseHostPort(hostPart)
        val out = ServiceProfiles.base("ssh", ep.host, ep.port).put("user", user).put("password", pass)
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "SSH server" }
        return GenericProfile(name, "SSH", ep.host, ep.port, out)
    }

    private fun wireguardLink(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val q = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        val at = main.lastIndexOf('@')
        require(at > 0) { "رابط WireGuard لا يحتوي على المفتاح الخاص." }
        val privateKey = ServiceProfiles.wgKey(LinkSyntax.percentDecode(main.substring(0, at), lenient = true), "المفتاح الخاص")
        val ep = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))
        val publicKey = ServiceProfiles.wgKey(
            (q["publickey"] ?: q["public_key"] ?: q["peer_public_key"]).orEmpty(), "المفتاح العام للنظير"
        )
        val addresses = cidrList((q["address"] ?: q["ip"]).orEmpty())
        require(addresses.isNotEmpty()) { "عنوان الواجهة (address) مفقود في رابط WireGuard." }
        val out = ServiceProfiles.wireguard(ep.host, ep.port, privateKey, publicKey, addresses)
        applyWireGuardExtras(
            out,
            mtu = q["mtu"],
            presharedKey = q["presharedkey"] ?: q["preshared_key"] ?: q["pre_shared_key"],
            reserved = q["reserved"]
        )
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "WireGuard server" }
        return GenericProfile(name, "WireGuard", ep.host, ep.port, out, endpoint = true)
    }

    // ------------------------------------------------------------------ files

    fun looksLikeWireGuardConf(text: String): Boolean =
        text.contains("[Interface]", ignoreCase = true) && text.contains("[Peer]", ignoreCase = true)

    fun looksLikeOpenVpn(text: String): Boolean {
        val lines = text.lineSequence().map { it.trim().lowercase() }.toList()
        val hasRemote = lines.any { it.startsWith("remote ") }
        val hasMarker = lines.any { it == "client" || it.startsWith("dev tun") || it.startsWith("<ca>") || it.startsWith("proto ") }
        return hasRemote && hasMarker
    }

    /** Parses a standard wg-quick `.conf` file (first [Peer] only). */
    fun fromWireGuardConf(text: String, label: String = "WireGuard"): GenericProfile {
        val iface = mutableMapOf<String, String>()
        val peers = mutableListOf<MutableMap<String, String>>()
        var section = ""
        text.lineSequence().forEach { rawLine ->
            val line = rawLine.substringBefore('#').trim()
            if (line.isEmpty()) return@forEach
            if (line.startsWith("[") && line.endsWith("]")) {
                section = line.substring(1, line.length - 1).trim().lowercase()
                if (section == "peer") peers += mutableMapOf()
                return@forEach
            }
            val eq = line.indexOf('=')
            if (eq <= 0) return@forEach
            val key = line.substring(0, eq).trim().lowercase()
            val value = line.substring(eq + 1).trim()
            if (section == "interface") {
                iface[key] = value
            }
            if (section == "peer") {
                peers.lastOrNull()?.put(key, value)
            }
        }
        val peer = peers.firstOrNull() ?: throw IllegalArgumentException("ملف WireGuard لا يحتوي على [Peer].")
        val privateKey = ServiceProfiles.wgKey(iface["privatekey"].orEmpty(), "المفتاح الخاص")
        val publicKey = ServiceProfiles.wgKey(peer["publickey"].orEmpty(), "المفتاح العام للنظير")
        val ep = LinkSyntax.parseHostPort(peer["endpoint"].orEmpty())
        val addresses = cidrList(iface["address"].orEmpty())
        require(addresses.isNotEmpty()) { "عنوان الواجهة (Address) مفقود في ملف WireGuard." }
        val out = ServiceProfiles.wireguard(ep.host, ep.port, privateKey, publicKey, addresses)
        applyWireGuardExtras(out, mtu = iface["mtu"], presharedKey = peer["presharedkey"], reserved = null)
        val name = LinkSyntax.sanitizeLabel(label).ifBlank { "WireGuard" }
        return GenericProfile(name, "WireGuard", ep.host, ep.port, out, endpoint = true)
    }

    // ------------------------------------------------------------------ helpers

    private data class Parts(val user: String, val pass: String, val hostPart: String)

    /** `user:pass@host:port`, `base64(user:pass)@host:port`, or just `host:port`. */
    private fun userInfoAndHost(main: String): Parts {
        val at = main.lastIndexOf('@')
        if (at < 0) return Parts("", "", main.substringBefore('/'))
        val raw = LinkSyntax.percentDecode(main.substring(0, at), lenient = true)
        val cred = if (raw.contains(':')) raw else decodeBase64(raw)?.takeIf { it.contains(':') } ?: raw
        val colon = cred.indexOf(':')
        val user = if (colon >= 0) cred.substring(0, colon) else cred
        val pass = if (colon >= 0) cred.substring(colon + 1) else ""
        return Parts(user, pass, main.substring(at + 1).substringBefore('/'))
    }

    private fun cidrList(text: String): List<String> =
        text.split(',').map { it.trim() }.filter { it.isNotEmpty() }.map {
            require(it.none { c -> c.isWhitespace() }) { "عنوان الواجهة غير صالح." }
            if (it.contains('/')) it else if (it.contains(':')) "$it/128" else "$it/32"
        }

    private fun applyWireGuardExtras(out: JSONObject, mtu: String?, presharedKey: String?, reserved: String?) {
        mtu?.trim()?.toIntOrNull()?.takeIf { it in 576..1500 }?.let { out.put("mtu", it) }
        val peer = out.getJSONArray("peers").getJSONObject(0)
        presharedKey?.takeIf { it.isNotBlank() }?.let { peer.put("pre_shared_key", ServiceProfiles.wgKey(it.trim(), "المفتاح المشترك المسبق")) }
        val parts = reserved?.split(',')?.map { it.trim().toIntOrNull() }
        if (parts != null && parts.size == 3 && parts.all { it != null && it in 0..255 }) {
            peer.put("reserved", JSONArray(parts.map { it!! }))
        }
    }

    private fun decodeBase64(text: String): String? {
        val normalized = text.filterNot { it.isWhitespace() }.replace('-', '+').replace('_', '/').trimEnd('=')
        if (normalized.isEmpty()) return null
        return try {
            String(Base64.getDecoder().decode(normalized + "=".repeat((4 - normalized.length % 4) % 4)), Charsets.UTF_8)
        } catch (_: IllegalArgumentException) { null }
    }
}
