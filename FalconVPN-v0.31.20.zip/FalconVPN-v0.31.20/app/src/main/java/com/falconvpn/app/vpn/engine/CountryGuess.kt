package com.falconvpn.app.vpn.engine

/**
 * Best-effort country of a saved server, derived ONLY from text the config itself carries (its name):
 * a flag emoji, an ISO code such as "DE", or an English/Arabic country name. Returns "" when unknown;
 * nothing is looked up online and an address is never geolocated.
 */
object CountryGuess {
    private val NAMES: Map<String, String> = mapOf(
        "egypt" to "EG", "مصر" to "EG", "saudi" to "SA", "السعودية" to "SA", "uae" to "AE", "emirates" to "AE", "الإمارات" to "AE", "الامارات" to "AE",
        "kuwait" to "KW", "الكويت" to "KW", "qatar" to "QA", "قطر" to "QA", "bahrain" to "BH", "البحرين" to "BH", "oman" to "OM", "عمان" to "OM",
        "jordan" to "JO", "الأردن" to "JO", "الاردن" to "JO", "iraq" to "IQ", "العراق" to "IQ", "morocco" to "MA", "المغرب" to "MA",
        "algeria" to "DZ", "الجزائر" to "DZ", "tunisia" to "TN", "تونس" to "TN", "libya" to "LY", "ليبيا" to "LY", "turkey" to "TR", "turkiye" to "TR", "تركيا" to "TR",
        "germany" to "DE", "ألمانيا" to "DE", "المانيا" to "DE", "france" to "FR", "فرنسا" to "FR", "netherlands" to "NL", "holland" to "NL", "هولندا" to "NL",
        "united kingdom" to "GB", "england" to "GB", "britain" to "GB", "بريطانيا" to "GB", "united states" to "US", "usa" to "US", "america" to "US", "أمريكا" to "US", "امريكا" to "US",
        "canada" to "CA", "كندا" to "CA", "singapore" to "SG", "سنغافورة" to "SG", "japan" to "JP", "اليابان" to "JP", "india" to "IN", "الهند" to "IN",
        "russia" to "RU", "روسيا" to "RU", "finland" to "FI", "فنلندا" to "FI", "sweden" to "SE", "السويد" to "SE", "poland" to "PL", "بولندا" to "PL",
        "italy" to "IT", "إيطاليا" to "IT", "spain" to "ES", "إسبانيا" to "ES", "switzerland" to "CH", "سويسرا" to "CH", "hong kong" to "HK", "hongkong" to "HK", "هونغ كونغ" to "HK",
        "brazil" to "BR", "البرازيل" to "BR", "australia" to "AU", "أستراليا" to "AU", "korea" to "KR", "كوريا" to "KR", "ukraine" to "UA", "أوكرانيا" to "UA"
    )
    private val CODES: Set<String> = NAMES.values.toSet() + setOf("UK")
    private val CODE_TOKEN = Regex("(?<![A-Za-z])([A-Z]{2})(?![A-Za-z])")

    /** Two-letter ISO code ("" if unknown). */
    fun codeOf(name: String): String {
        var i = 0
        while (i < name.length) {
            val cp = name.codePointAt(i)
            val next = i + Character.charCount(cp)
            if (cp in 0x1F1E6..0x1F1FF && next < name.length) {
                val cp2 = name.codePointAt(next)
                if (cp2 in 0x1F1E6..0x1F1FF) {
                    return "" + ('A' + (cp - 0x1F1E6)) + ('A' + (cp2 - 0x1F1E6))
                }
            }
            i = next
        }
        val lower = name.lowercase()
        // Short Latin names ("uae", "usa", "oman") must be whole words: "woman" is not Oman.
        NAMES.entries.firstOrNull { (key, _) ->
            if (key.length <= 4 && key.all { it in 'a'..'z' }) Regex("(?<![a-z])$key(?![a-z])").containsMatchIn(lower)
            else lower.contains(key)
        }?.let { return it.value }
        val token = CODE_TOKEN.findAll(name).map { it.groupValues[1] }.firstOrNull { it in CODES }
        return if (token == "UK") "GB" else token.orEmpty()
    }

    fun flagOf(code: String): String {
        if (code.length != 2 || !code.all { it in 'A'..'Z' }) return ""
        return String(Character.toChars(0x1F1E6 + (code[0] - 'A'))) + String(Character.toChars(0x1F1E6 + (code[1] - 'A')))
    }
}
