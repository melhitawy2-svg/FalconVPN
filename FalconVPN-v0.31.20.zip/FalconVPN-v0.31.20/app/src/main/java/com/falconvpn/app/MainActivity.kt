package com.falconvpn.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.falconvpn.app.vpn.engine.BuiltInService
import com.falconvpn.app.vpn.engine.BuiltInServices
import com.falconvpn.app.vpn.engine.SecureProfileStore
import com.falconvpn.app.vpn.engine.ConfigArchive
import com.falconvpn.app.vpn.engine.ServiceProfiles
import com.falconvpn.app.vpn.engine.UniversalLinks
import com.falconvpn.app.vpn.engine.ShadowsocksLinkParser
import com.falconvpn.app.vpn.engine.VlessLinkParser
import com.falconvpn.app.vpn.platform.FalconVpnService
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private var appWebView: WebView? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4102
    private val nativeImportPickerRequest = 4103
    private val profileStore by lazy { SecureProfileStore(applicationContext) }
    private var pendingConnectAfterPermission = false
    private var importDialog: android.app.AlertDialog? = null
    private val pendingPantegnosImports = java.util.ArrayDeque<Pair<String, String>>()
    private var pantegnosImportInFlight = false
    private val uiHandler = Handler(Looper.getMainLooper())

    /** A validated link waiting for the user's explicit confirmation. Nothing is stored before that. */
    private class PendingImport(val summary: String, val save: () -> JSONObject, val insecureTls: Boolean = false)

    // The service writes its state to SharedPreferences; this listener PUSHES every change to the page,
    // so the UI no longer polls once a second.
    private val pushRunnable = Runnable { pushStatusToPage() }
    private val statusListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        uiHandler.removeCallbacks(pushRunnable)
        uiHandler.postDelayed(pushRunnable, 50L)
    }

    private val vpnPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConnectAfterPermission) {
            pendingConnectAfterPermission = false
            startVpnService()
        } else {
            pendingConnectAfterPermission = false
            saveRuntimeState(FalconVpnService.STATE_NEEDS_PERMISSION, "لم يتم منح إذن VPN؛ لم يبدأ الاتصال.")
        }
    }
    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        // The VPN consent dialog is separate. Continue the connect flow whatever the answer is:
        // without the notification permission the tunnel still works, only the status notification is hidden.
        if (!granted) {
            android.widget.Toast.makeText(this, "إذن الإشعارات مرفوض؛ قد لا يظهر إشعار حالة VPN.", android.widget.Toast.LENGTH_LONG).show()
        }
        if (pendingConnectAfterPermission) requestVpnPermissionOrStart()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // targetSdk 35 forces edge-to-edge on Android 15; opt in everywhere so behaviour is the same.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        pendingConnectAfterPermission = savedInstanceState?.getBoolean(KEY_PENDING_CONNECT, false) ?: false
        // A CONNECTED state persisted by a process that was killed is stale: clear it before the UI reads it.
        FalconVpnService.reconcileStaleState(applicationContext)

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val webView = WebView(this)
        appWebView = webView
        webView.layoutParams = android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.setBackgroundColor(0xFF020817.toInt())
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true // the bundled page keeps account/UI state in localStorage; only our own asset origin is ever loaded
        webView.settings.allowFileAccess = false
        // The bundled page is served only from WebViewAssetLoader and external navigation is blocked.
        // File input needs WebView content-URI access after the system picker returns a SAF URI.
        // JavaScript/file access remains disabled; only a user-selected content URI is exposed.
        webView.settings.allowContentAccess = true
        webView.settings.setSupportZoom(false)
        webView.settings.mediaPlaybackRequiresUserGesture = true
        // The bridge is attached only to this WebView, which can only ever show the bundled asset page.
        webView.addJavascriptInterface(FalconNativeBridge(), "FalconNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == ASSET_HOST && (uri.path ?: "").startsWith("/assets/")) return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                }
                // Anything else (file://, content://, intent://, ...) must never replace the app page,
                // because the native bridge is attached to this WebView.
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pushStatusToPage()
                dispatchNextPantegnosImport()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: android.webkit.JsPromptResult?
            ): Boolean {
                if (url == null || !url.startsWith("https://$ASSET_HOST/assets/")) return false
                val input = android.widget.EditText(this@MainActivity).apply {
                    inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                    setSingleLine(true)
                    hint = "كلمة المرور"
                }
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("فك تشفير الملف")
                    .setMessage(message ?: "أدخل كلمة المرور")
                    .setView(input)
                    .setPositiveButton("فك التشفير") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                android.util.Log.d("FalconWebView", "${message.message()} -- line ${message.lineNumber()} of ${message.sourceId()}")
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Preserve normal WebView file inputs (profile/chat images and File Tools).
                // The dedicated config-import button uses pickConfigFile() on the native bridge,
                // so configuration bytes never need to be exposed to WebView JavaScript.
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = null
                    android.util.Log.e("FalconImport", "Unable to open document picker", e)
                    true
                }
            }
        }
        val root = android.widget.FrameLayout(this)
        root.setBackgroundColor(0xFF020817.toInt()) // same as the page background, shows behind the bars
        root.addView(webView)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
        webView.loadUrl("https://$ASSET_HOST/assets/index.html")
        // Links/files opened from a browser or the share sheet. Only on a fresh launch: after process
        // death/recreation the same intent would otherwise be imported a second time.
        if (savedInstanceState == null) {
            handleIncomingIntent(intent)
            setIntent(Intent())
        }
        if (profileStore.consumeResetNotice()) {
            android.widget.Toast.makeText(this, "تعذر فك تشفير الكونفجات المحفوظة (تغيّرت حماية الجهاز) فتم مسحها. استورد كونفجاتك من جديد.", android.widget.Toast.LENGTH_LONG).show()
        }

        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).registerOnSharedPreferenceChangeListener(statusListener)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = appWebView
                if (wv == null) { finish(); return }
                // Let the page close a dialog / leave a tab first; only exit when it has nothing to close.
                wv.evaluateJavascript("(function(){return !!(window.falconHandleBack && window.falconHandleBack());})()") { value ->
                    if (value != "true") finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        FalconVpnService.reconcileStaleState(applicationContext)
        pushStatusToPage()
    }

    private companion object {
        const val KEY_PENDING_CONNECT = "pending_connect_after_permission"
        const val MAX_IMPORT = 100
        const val MAX_TEXT = 200_000
        const val MAX_IMPORT_BYTES = 5 * 1024 * 1024
        const val ASSET_HOST = "appassets.androidplatform.net"
        val ALLOWED_AUTO_DISCONNECT = setOf(0, 15, 30, 60, 120)
    }

    // ---------------------------------------------------------------- status

    private fun statusJson(): JSONObject {
        val prefs = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
        val state = prefs.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED) ?: FalconVpnService.STATE_DISCONNECTED
        val message = prefs.getString(FalconVpnService.KEY_MESSAGE, "") ?: ""
        return JSONObject()
            .put("state", state)
            .put("message", message)
            .put("engineStage", prefs.getString(FalconVpnService.KEY_ENGINE_STAGE, "") ?: "")
            .put("lastError", prefs.getString(FalconVpnService.KEY_LAST_ERROR, "") ?: "")
            .put("verifiedExitIp", prefs.getString(FalconVpnService.KEY_VERIFIED_EXIT_IP, "") ?: "")
            .put("trafficVerifiedAt", prefs.getLong(FalconVpnService.KEY_TRAFFIC_VERIFIED_AT, 0L))
            .put("updatedAt", prefs.getLong(FalconVpnService.KEY_UPDATED_AT, 0L))
            .put("connectedAt", prefs.getLong(FalconVpnService.KEY_CONNECTED_AT, 0L))
            .put("sessionEndsAt", prefs.getLong(FalconVpnService.KEY_SESSION_ENDS_AT, 0L))
            .put("engineRunning", FalconVpnService.engineRunning)
            .put("engineStarting", FalconVpnService.engineStarting)
            .put("now", System.currentTimeMillis())
    }

    private fun pushStatusToPage() {
        val wv = appWebView ?: return
        val json = statusJson().toString()
        wv.post { wv.evaluateJavascript("window.falconOnStatus&&window.falconOnStatus($json)", null) }
    }

    private fun selectProfileForNextConnection(id: String?): Boolean {
        if (id.isNullOrBlank()) return false
        val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
            .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
        if (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING) return false
        return runCatching { profileStore.select(id) }.getOrDefault(false)
    }

    // ---------------------------------------------------------------- bridge

    private inner class FalconNativeBridge {
        private fun fail(message: String) = JSONObject().put("ok", false).put("message", message).toString()

        /** Receives the result of the local Pantegnos WebAssembly decoder. */
        @JavascriptInterface
        fun onPantegnosDecrypted(fileName: String, text: String, error: String) {
            this@MainActivity.onPantegnosDecrypted(fileName, text, error)
        }

        /** Opens the Android SAF picker for the dedicated config-import screen. */
        @JavascriptInterface
        fun pickConfigFile(): String {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                }
                try {
                    startActivityForResult(intent, nativeImportPickerRequest)
                } catch (e: Exception) {
                    showImportMessage("تعذر فتح مستعرض الملفات: ${e.message ?: "خطأ غير معروف"}")
                }
            }
            return JSONObject().put("ok", true).put("message", "افتح ملف الكونفج من مستعرض Android.").toString()
        }

        /**
         * Imports supported links, Base64 subscription bodies, and sing-box JSON objects/arrays.
         * Nothing is stored until the user confirms the native import dialog.
         */
        @JavascriptInterface
        fun importLinks(text: String): String {
            return try {
                require(text.length <= MAX_TEXT) { "حجم النص كبير جدًا." }
                require(text.isNotBlank()) { "الصق رابط الكونفج أو اختر ملفًا أولًا." }
                val trimmed = text.trimStart()
                if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                    val jsonItems = parseSingBoxJsonImports(text)
                    require(jsonItems.isNotEmpty()) { "ملف JSON لا يحتوي على outbound مدعوم يمكن استيراده." }
                    runOnUiThread { showImportConfirmation(jsonItems, 0) }
                    JSONObject().put("ok", true).put("imported", 0)
                        .put("message", "تم تحليل JSON؛ أكّد الحفظ من نافذة Android.").toString()
                } else {
                    val links = extractLinks(text)
                    require(links.isNotEmpty()) {
                        "لم أجد رابطًا مدعومًا. الصيغ الحالية: VLESS وVMess وShadowsocks وTrojan وSOCKS وHTTP وTUIC وHysteria وHysteria2 وWireGuard وSSH وsing-box JSON."
                    }
                    require(links.size <= MAX_IMPORT) { "يمكن استيراد $MAX_IMPORT رابط كحد أقصى في المرة الواحدة." }
                    // One import path for all links. VLESS insecure/insecure=1 is parsed by
                    // VlessLinkParser, shown in the native warning, and stored per profile.
                    // It is NOT rejected as a generic security permission.
                    runOnUiThread { importIncomingContent(text) }
                    JSONObject().put("ok", true).put("imported", 0)
                        .put("message", "تم تحليل ${links.size} رابط. راجع نافذة التأكيد لحفظها في الخدمات.").toString()
                }
            } catch (e: Exception) {
                fail(e.message ?: "تعذر تحليل الكونفج")
            }
        }

        /** Saves a protocol form (VMess, Trojan, Hysteria2, TUIC, WireGuard, SOCKS, HTTP Proxy, SSH, Custom JSON). */
        @JavascriptInterface
        fun saveService(service: String, fieldsJson: String): String {
            return try {
                require(fieldsJson.length <= MAX_TEXT) { "حجم النص كبير جدًا." }
                val obj = JSONObject(fieldsJson)
                val fields = obj.keys().asSequence().associateWith { obj.optString(it) }
                val profile = ServiceProfiles.fromForm(service, fields, obj.optString("__name"))
                val saved = profileStore.saveGeneric(profile)
                val id = saved.optString("id")
                val selected = selectProfileForNextConnection(id)
                JSONObject().put("ok", true).put("imported", 1)
                    .put("selected", selected)
                    .put("message", if (selected) "تم حفظ الكونفج وتحديده تلقائياً؛ أصبح جاهزاً لمحاولة الاتصال." else "تم حفظ الكونفج في الخدمات.")
                    .toString()
            } catch (e: Exception) {
                fail(e.message ?: "تعذر حفظ الاتصال")
            }
        }

        /**
         * Downloads a subscription (https only, 2 MB, 10 s) and imports every supported link in it.
         * @JavascriptInterface methods run on a background thread, so blocking here is fine.
         */
        @JavascriptInterface
        fun importSubscription(url: String): String {
            return try {
                val u = Uri.parse(url.trim())
                require(u.scheme == "https" && !u.host.isNullOrBlank()) { "رابط الاشتراك يجب أن يبدأ بـ https://" }
                val conn = java.net.URL(u.toString()).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 10_000; conn.readTimeout = 10_000
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", "FalconVPN/Android")
                val body = try {
                    require(conn.responseCode == 200) { "فشل تحميل الاشتراك (HTTP ${conn.responseCode})." }
                    conn.inputStream.use { input ->
                        val out = java.io.ByteArrayOutputStream()
                        val buf = ByteArray(8192); var total = 0
                        while (true) {
                            val n = input.read(buf); if (n < 0) break
                            total += n; require(total <= 2_000_000) { "ملف الاشتراك كبير جدًا." }
                            out.write(buf, 0, n)
                        }
                        String(out.toByteArray(), Charsets.UTF_8)
                    }
                } finally { conn.disconnect() }
                importLinks(body.take(MAX_TEXT))
            } catch (e: Exception) {
                fail(e.message ?: "تعذر تحميل الاشتراك")
            }
        }

        @JavascriptInterface
        fun pasteFromClipboard(): String {
            return try {
                val cm = getSystemService(ClipboardManager::class.java)
                val clip = cm?.primaryClip
                val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@MainActivity).toString() else ""
                JSONObject().put("ok", true).put("text", text.take(MAX_TEXT)).toString()
            } catch (e: Exception) {
                fail("تعذر قراءة الحافظة.")
            }
        }

        @JavascriptInterface
        fun listSavedProfiles(): String {
            return try {
                val selectedId = profileStore.selectedMetadata()?.optString("id").orEmpty()
                JSONObject().put("ok", true).put("profiles", profileStore.list()).put("selectedId", selectedId).toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر قراءة الكونفجات") }
        }

        /**
         * TCP connect time to a saved server, in ms (-1 = unreachable or not measurable). UDP based protocols
         * (Hysteria, Hysteria2, TUIC, WireGuard) cannot be probed with a TCP connect and report supported=false.
         * Measure before connecting: while the VPN is up this socket would travel through the tunnel.
         */
        @JavascriptInterface
        fun pingSavedProfile(id: String): String {
            val item = try { profileStore.getForEngine(id) } catch (_: Exception) { null }
                ?: return fail("الكونفج غير موجود.")
            val protocol = item.optString("protocol", "Shadowsocks").lowercase()
            if (protocol in setOf("hysteria", "hysteria2", "tuic", "wireguard")) {
                return JSONObject().put("ok", true).put("ms", -1).put("supported", false)
                    .put("message", "فحص ping غير متاح لبروتوكولات UDP.").toString()
            }
            val host = item.optString("host")
            val port = item.optInt("port")
            return try {
                val start = System.nanoTime()
                java.net.Socket().use { it.connect(java.net.InetSocketAddress(host, port), 4000) }
                JSONObject().put("ok", true).put("supported", true)
                    .put("ms", ((System.nanoTime() - start) / 1_000_000L).toInt()).toString()
            } catch (_: Exception) {
                JSONObject().put("ok", true).put("supported", true).put("ms", -1)
                    .put("message", "تعذر الوصول إلى السيرفر.").toString()
            }
        }

        @JavascriptInterface
        fun deleteSavedProfile(id: String): String {
            return try {
                // Never delete the config of a live tunnel from under the engine.
                val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                    .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
                val selectedId = profileStore.selectedMetadata()?.optString("id").orEmpty()
                if (id == selectedId && (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING)) {
                    return fail("افصل الاتصال أولًا قبل حذف الكونفج المستخدم.")
                }
                val ok = profileStore.delete(id)
                JSONObject().put("ok", ok).put("message", if (ok) "تم حذف الكونفج." else "الكونفج غير موجود.").toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر حذف الكونفج") }
        }

        @JavascriptInterface
        fun selectSavedProfile(id: String): String {
            return try {
                val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                    .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
                if (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING) {
                    return fail("افصل الاتصال أولًا ثم اختر كونفجًا آخر.")
                }
                val selected = profileStore.select(id)
                JSONObject().put("ok", selected)
                    .put("message", if (selected) "تم تحديد الكونفج." else "الكونفج غير موجود أو تعذر تحديده.")
                    .toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر تحديد الكونفج") }
        }

        @JavascriptInterface
        fun selectedSavedProfile(): String {
            return try {
                val selected = profileStore.selectedMetadata()
                JSONObject().put("ok", true).put("profile", selected ?: JSONObject.NULL).toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر قراءة الكونفج المحدد") }
        }

        @JavascriptInterface
        fun connectVpn(): String {
            FalconVpnService.reconcileStaleState(applicationContext)
            val prefs = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
            val current = prefs.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
            // Double tap / duplicate request: a start is already in flight or the tunnel is up.
            if (pendingConnectAfterPermission || current == FalconVpnService.STATE_CONNECTING || current == FalconVpnService.STATE_CONNECTED) {
                return JSONObject().put("ok", true).put("state", current ?: "CONNECTING").put("message", "الاتصال قيد التشغيل بالفعل.").toString()
            }
            val selected = runCatching { profileStore.getSelectedForEngine() }.getOrNull()
                ?: return JSONObject().put("ok", false).put("state", "ERROR").put("message", "حدد كونفجًا محفوظًا أولًا.").toString()
            if (selected.length() == 0) return fail("حدد كونفجًا محفوظًا أولًا.")
            prefs.edit().remove(FalconVpnService.KEY_LAST_ERROR)
                .putString(FalconVpnService.KEY_ENGINE_STAGE, "REQUESTED").apply()
            runOnUiThread { beginVpnPermissionFlow() }
            return JSONObject().put("ok", true).put("state", "CONNECTING").put("message", "جارٍ فحص إذن VPN وتجهيز الخدمة.").toString()
        }

        /** Picker entries that ship with a ready config. The link itself is never sent to the page. */
        @JavascriptInterface
        fun builtInServices(): String {
            return try {
                val entries = loadBuiltInServices()
                val services = JSONArray()
                entries.forEach {
                    services.put(JSONObject().put("label", it.label).put("category", it.category)
                        .put("provider", it.provider).put("description", it.description))
                }
                JSONObject().put("ok", true).put("count", entries.size).put("services", services).toString()
            } catch (e: Exception) {
                android.util.Log.e("FalconServices", "Failed to load built-in services asset", e)
                JSONObject().put("ok", false)
                    .put("message", e.message ?: "تعذر تحميل ملف الخدمات المدمجة.")
                    .put("services", JSONArray()).toString()
            }
        }

        /**
         * Picking a service in the free-internet picker: when it has a built-in config, store it and make it
         * the selected profile so the next connect uses it. These configs ship inside the app, so no
         * import confirmation is needed (unlike links opened from other apps).
         */
        @JavascriptInterface
        fun useBuiltInService(label: String): String {
            return try {
                val entry = BuiltInServices.find(loadBuiltInServices(), label)
                    ?: return JSONObject().put("ok", true).put("builtIn", false).toString()
                val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                    .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
                if (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING) {
                    return fail("افصل الاتصال أولًا ثم اختر خدمة أخرى.")
                }
                val saved = saveLink(entry.link, entry.label)
                require(saved.optBoolean("saved")) { "لم يؤكد مخزن الكونفجات حفظ الخدمة." }
                val id = saved.optString("id")
                require(id.isNotBlank() && profileStore.select(id)) { "تعذر تحديد كونفج الخدمة." }
                val stored = profileStore.getForEngine(id)
                    ?: throw IllegalStateException("تم الحفظ لكن تعذر استرجاع الكونفج لمحرك VPN.")
                // VLESS keeps its fields at the top level; every other protocol (VMess, Trojan, SOCKS, SSH ...)
                // is stored as a ready sing-box outbound under "singbox".
                val complete = if (stored.optString("protocol").equals("VLESS", true)) {
                    stored.optString("uuid").isNotBlank()
                } else {
                    stored.optString("singbox").isNotBlank() && stored.optString("host").isNotBlank()
                }
                require(complete) { "الكونفج المحفوظ غير مكتمل ولا يمكن تشغيله." }
                JSONObject().put("ok", true).put("builtIn", true).put("id", id)
                    .put("message", "تم حفظ خدمة ${entry.label} وتحديدها للاتصال.").toString()
            } catch (e: Exception) {
                fail(e.message ?: "تعذر تجهيز الخدمة")
            }
        }

        @JavascriptInterface
        fun disconnectVpn(): String {
            runOnUiThread {
                startService(Intent(this@MainActivity, FalconVpnService::class.java).setAction(FalconVpnService.ACTION_STOP))
            }
            return JSONObject().put("ok", true).put("message", "تم طلب إيقاف VPN.").toString()
        }

        @JavascriptInterface
        fun engineStatus(): String {
            FalconVpnService.reconcileStaleState(applicationContext)
            return statusJson().toString()
        }

        /** A real HTTPS request made by this app UID. With an active VPN, Android routes it through the tunnel. */
        @JavascriptInterface
        fun runConnectivityTest(): String {
            return try {
                val cm = getSystemService(android.net.ConnectivityManager::class.java)
                val active = cm.activeNetwork
                val caps = active?.let { cm.getNetworkCapabilities(it) }
                val vpnTransport = caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN) == true
                val selected = profileStore.selectedMetadata()
                val connection = (java.net.URL("https://ipinfo.io/json").openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "FalconVPN-ConnectivityCheck/0.30.2")
                }
                val body = try {
                    require(connection.responseCode == 200) { "HTTP ${connection.responseCode}" }
                    connection.inputStream.bufferedReader().use { it.readText().take(12000) }
                } finally { connection.disconnect() }
                val result = JSONObject(body)
                JSONObject().put("ok", true)
                    .put("vpnTransport", vpnTransport)
                    .put("permissionGranted", VpnService.prepare(this@MainActivity) == null)
                    .put("profileSelected", selected != null)
                    .put("ip", result.optString("ip"))
                    .put("country", result.optString("country"))
                    .put("org", result.optString("org"))
                    .put("message", if (vpnTransport) "نجح طلب HTTPS أثناء وجود شبكة VPN نشطة." else "نجح الإنترنت، لكن Android لا يعرض شبكة VPN نشطة؛ قد يكون الاتصال مباشراً.")
                    .toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false)
                    .put("vpnTransport", false)
                    .put("permissionGranted", VpnService.prepare(this@MainActivity) == null)
                    .put("profileSelected", runCatching { profileStore.selectedMetadata() != null }.getOrDefault(false))
                    .put("message", "فشل اختبار HTTPS: ${e.message ?: e.javaClass.simpleName}")
                    .toString()
            }
        }

        /**
         * Bytes the tunnel has moved over the real network, read from Android's per-UID counters
         * (this app's own sockets carry the proxied traffic). The page turns two samples into a speed.
         */
        @JavascriptInterface
        fun trafficStats(): String {
            val uid = android.os.Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)
            if (rx < 0L || tx < 0L) return fail("إحصاءات الاستهلاك غير متاحة على هذا الجهاز.")
            return JSONObject().put("ok", true).put("rx", rx).put("tx", tx).put("t", SystemClock.elapsedRealtime()).toString()
        }

        @JavascriptInterface
        fun getSettings(): String {
            val minutes = getSharedPreferences(FalconVpnService.SETTINGS_PREFS, MODE_PRIVATE)
                .getInt(FalconVpnService.KEY_AUTO_DISCONNECT_MIN, 0)
            return JSONObject().put("ok", true).put("autoDisconnectMinutes", minutes).toString()
        }

        @JavascriptInterface
        fun setAutoDisconnect(minutes: Int): String {
            if (minutes !in ALLOWED_AUTO_DISCONNECT) return fail("قيمة غير مسموحة.")
            getSharedPreferences(FalconVpnService.SETTINGS_PREFS, MODE_PRIVATE).edit()
                .putInt(FalconVpnService.KEY_AUTO_DISCONNECT_MIN, minutes).apply()
            val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
            val live = state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING
            return JSONObject().put("ok", true)
                .put("message", if (live) "تم الحفظ، ويُطبَّق عند الاتصال التالي." else "تم الحفظ.")
                .toString()
        }

        @JavascriptInterface
        fun appInfo(): String {
            @Suppress("DEPRECATION")
            val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""
            return JSONObject().put("ok", true).put("version", version).put("sdk", Build.VERSION.SDK_INT).toString()
        }
    }

    // ---------------------------------------------------------------- incoming links / files

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
        setIntent(Intent()) // consumed: never re-import the same intent
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_PENDING_CONNECT, pendingConnectAfterPermission)
    }

    private fun scanLinks(text: String): List<String> {
        // Group posts often put a label or emoji before the URI on the same line. The look-behind stops
        // "nm-ssh://" or "wss://" from being read as "ssh://" / "ss://".
        val pattern = Regex("(?i)(?<![\\w-])(?:ss|vless|vmess|trojan|hysteria2|hy2|hysteria|tuic|socks5|socks4|socks|wireguard|wg|ssh)://[^\\s<>\"']+")
        // An HTTP(S) proxy link needs credentials + explicit port, so ordinary web URLs are never matched.
        val proxyPattern = Regex("(?i)(?<![\\w-])https?://[^\\s/@<>\"']+@[^\\s/<>\"']+:\\d+/?(?:#[^\\s<>\"']*)?")
        return (pattern.findAll(text) + proxyPattern.findAll(text)).map { match ->
            match.value.trim().trimEnd(',', ';', ')', ']', '}', '.', '،')
        }.filter { ServiceProfiles.isSupportedLink(it) }.distinct().toList()
    }

    /** Parses and stores one share link of any supported scheme. Throws with a user-facing message. */
    private fun saveLink(line: String, nameOverride: String? = null): JSONObject = when {
        line.startsWith("vless://", ignoreCase = true) ->
            profileStore.saveVless(VlessLinkParser.parse(line).let { if (nameOverride != null) it.copy(name = nameOverride) else it })
        line.startsWith("ss://", ignoreCase = true) ->
            profileStore.save(ShadowsocksLinkParser.parse(line).let { if (nameOverride != null) it.copy(name = nameOverride) else it })
        else ->
            profileStore.saveGeneric(ServiceProfiles.fromLink(line).let { if (nameOverride != null) it.copy(name = nameOverride) else it })
    }

    /** Services of the free-internet picker that ship with a ready config. */
    private fun loadBuiltInServices(): List<BuiltInService> {
        val json = assets.open("builtin_services.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val services = BuiltInServices.parse(json)
        check(services.isNotEmpty()) { "ملف builtin_services.json موجود لكنه لا يحتوي على خدمات صالحة." }
        return services
    }

    /** Links found in the text; falls back to a Base64 subscription body (the usual "sub link" format). */
    private fun extractLinks(text: String): List<String> {
        val direct = scanLinks(text)
        if (direct.isNotEmpty()) return direct
        val compact = text.filter { !it.isWhitespace() }
        if (compact.length < 16) return emptyList()
        for (flags in intArrayOf(Base64.DEFAULT, Base64.URL_SAFE)) {
            val decoded = runCatching { String(Base64.decode(compact, flags), Charsets.UTF_8) }.getOrNull() ?: continue
            val found = scanLinks(decoded)
            if (found.isNotEmpty()) return found
        }
        return emptyList()
    }

    @Suppress("DEPRECATION")
    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        if (action != Intent.ACTION_VIEW && action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return
        try {
            val raw = when (action) {
                Intent.ACTION_VIEW -> {
                    val uri = intent.data ?: return
                    if (uri.scheme.equals("content", true) || uri.scheme.equals("file", true)) {
                        contentResolver.openInputStream(uri)?.use { input ->
                            val bytes = readBounded(input)
                            importIncomingBytes(bytes, queryDisplayName(uri))
                            null
                        }
                    } else uri.toString()
                }
                Intent.ACTION_SEND -> {
                    intent.getStringExtra(Intent.EXTRA_TEXT)
                        ?: intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                            ?.let { uri -> contentResolver.openInputStream(uri)?.use { input ->
                            val bytes = readBounded(input)
                            importIncomingBytes(bytes, queryDisplayName(uri))
                            null
                        } }
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    val streams = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
                    if (streams.isEmpty()) {
                        showImportMessage("لم يتم استلام أي ملفات.")
                        return
                    }
                    if (streams.size > MAX_IMPORT) {
                        showImportMessage("تم تحديد أول $MAX_IMPORT ملفًا فقط من المشاركة.")
                    }
                    val incoming = mutableListOf<Pair<String, ByteArray>>()
                    var totalBytes = 0
                    var sizeLimitReached = false
                    streams.take(MAX_IMPORT).forEach { uri ->
                        if (sizeLimitReached) return@forEach
                        try {
                            val bytes = contentResolver.openInputStream(uri)?.use { readBounded(it) }
                            if (bytes == null) {
                                showImportMessage("تعذر فتح أحد الملفات المستلمة.")
                            } else if (totalBytes + bytes.size > MAX_IMPORT_BYTES) {
                                showImportMessage("تجاوز مجموع الملفات حد الاستيراد البالغ 5 ميجابايت؛ تم تجاهل بقية الملفات.")
                                sizeLimitReached = true
                                return@forEach
                            } else {
                                totalBytes += bytes.size
                                incoming += queryDisplayName(uri) to bytes
                            }
                        } catch (e: Exception) {
                            showImportMessage("تعذر قراءة أحد الملفات: ${e.message ?: "صيغة غير مدعومة"}")
                        }
                    }
                    importMultipleSharedFiles(incoming)
                    // One batch confirmation is shown for all readable open-format files.
                    return
                }
                else -> null
            } ?: return
            importIncomingContent(raw)
        } catch (e: Exception) {
            showImportMessage("تعذر قراءة الملف. تأكد أنه ملف نصي أو رابط مشاركة مدعوم.")
        }
    }

    /** Read a multi-file Android share as one batch so one confirmation dialog does not replace another. */
    private fun importMultipleSharedFiles(files: List<Pair<String, ByteArray>>) {
        if (files.isEmpty()) {
            showImportMessage("لم يتم العثور على ملفات قابلة للاستيراد.")
            return
        }
        val texts = mutableListOf<Pair<String, String>>()
        val skipped = mutableListOf<String>()
        for ((displayName, bytes) in files) {
            when {
                ConfigArchive.isZip(bytes) || ConfigArchive.isGzip(bytes) -> {
                    try {
                        val result = ConfigArchive.read(bytes, displayName)
                        texts.addAll(result.texts)
                        skipped.addAll(result.skipped)
                    } catch (e: Exception) {
                        skipped += displayName.ifBlank { "أرشيف غير صالح" }
                    }
                }
                isPantegnosFile(bytes, displayName) -> {
                    // Encrypted formats use an asynchronous decoder and cannot safely share one batch dialog.
                    skipped += displayName.ifBlank { "ملف مشفر" }
                }
                else -> {
                    val inspected = runCatching { ConfigFileInspector.inspect(bytes, displayName) }.getOrNull()
                    if (inspected?.isText != true) {
                        skipped += displayName.ifBlank { "ملف غير نصي" }
                    } else {
                        val text = runCatching {
                            Charsets.UTF_8.newDecoder()
                                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                                .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
                        }.getOrNull()
                        if (text.isNullOrBlank()) skipped += displayName.ifBlank { "ملف فارغ" }
                        else texts.add(displayName.ifBlank { "config.txt" } to text)
                    }
                }
            }
        }
        if (texts.isEmpty()) {
            showImportMessage("لم يتم العثور على ملفات نصية مدعومة. الملفات المشفرة تحتاج إلى استيرادها كلٌ على حدة." +
                if (skipped.isNotEmpty()) "\nتم تجاهل ${skipped.size} ملفًا." else "")
            return
        }
        if (texts.size == 1 && skipped.isEmpty()) {
            importIncomingContent(texts.single().second)
        } else {
            importArchiveEntries(ConfigArchive.Result(texts, skipped))
        }
    }

    private fun readBounded(input: java.io.InputStream): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= MAX_IMPORT_BYTES) { "حجم الملف أكبر من 5 ميجابايت." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun queryDisplayName(uri: Uri): String {
        return runCatching {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else "" }
        }.getOrNull().orEmpty()
    }

    private fun importIncomingBytes(bytes: ByteArray, displayName: String = "") {
        if (bytes.isEmpty() || bytes.size > MAX_IMPORT_BYTES) {
            showImportMessage("الملف فارغ أو أكبر من الحد المسموح (5 ميجابايت).")
            return
        }
        if (ConfigArchive.isZip(bytes) || ConfigArchive.isGzip(bytes)) {
            val archive = try {
                ConfigArchive.read(bytes, displayName)
            } catch (e: Exception) {
                showImportMessage("تعذر فتح الأرشيف: ${e.message}")
                return
            }
            if (archive.texts.isEmpty()) {
                showImportMessage("لا توجد داخل الأرشيف ملفات نصية قابلة للقراءة." +
                    if (archive.skipped.isNotEmpty()) " (تم تجاهل ${archive.skipped.size} ملف ثنائي أو غير نصي)" else "")
                return
            }
            if (archive.texts.size == 1) {
                // Preserve the full single-file path (JSON, YAML, WireGuard .conf, or share links).
                importIncomingContent(archive.texts.single().second)
            } else {
                // Parse every entry independently and show one confirmation dialog. The previous
                // implementation extracted only share links from multi-entry archives, silently
                // dropping valid sing-box JSON and WireGuard .conf files.
                importArchiveEntries(archive)
            }
            return
        }
        if (isPantegnosFile(bytes, displayName)) {
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            synchronized(pendingPantegnosImports) {
                if (pendingPantegnosImports.size >= MAX_IMPORT) {
                    showImportMessage("عدد الملفات المستوردة في نفس الوقت تجاوز الحد المسموح.")
                    return
                }
                pendingPantegnosImports.addLast(displayName.ifBlank { "config.bin" } to encoded)
            }
            dispatchNextPantegnosImport()
            return
        }
        val inspected = ConfigFileInspector.inspect(bytes, displayName)
        if (!inspected.isText) {
            showImportMessage(inspected.message ?: "صيغة الملف غير مدعومة حاليًا.")
            return
        }
        val raw = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
        } catch (_: Exception) {
            showImportMessage("تعذر قراءة النص داخل الملف.")
            return
        }
        importIncomingContent(raw)
    }

    /** Pantegnos handles binary/encrypted exports locally inside the bundled WebAssembly core. */
    private fun isPantegnosFile(bytes: ByteArray, displayName: String): Boolean {
        val ext = displayName.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)
        val supported = setOf("npvs", "npvt", "hc", "ehi", "hat", "slip", "dark", "nm", "happ", "bpf", "tls", "v2box", "zsx")
        if (ext in supported) return true
        return bytes.size >= 4 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "NPVS"
    }

    private fun dispatchNextPantegnosImport() {
        val webView = appWebView ?: return
        // Incoming share intents can arrive before the bundled page has finished loading.
        if (webView.progress < 100) return
        val item: Pair<String, String>
        synchronized(pendingPantegnosImports) {
            if (pantegnosImportInFlight || pendingPantegnosImports.isEmpty()) return
            pantegnosImportInFlight = true
            item = pendingPantegnosImports.removeFirst()
        }
        val fileNameJson = JSONObject.quote(item.first)
        val dataJson = JSONObject.quote(item.second)
        webView.post {
            webView.evaluateJavascript("(function(){if(typeof window.falconDecryptImportedFile!=='function')return false;window.falconDecryptImportedFile($fileNameJson,$dataJson);return true;})()") { result ->
                if (result == null || result == "null" || result == "false") {
                    synchronized(pendingPantegnosImports) { pantegnosImportInFlight = false }
                    showImportMessage("محرك فك الملفات لم يبدأ. أغلق التطبيق وافتحه مرة أخرى ثم جرّب.")
                    dispatchNextPantegnosImport()
                }
            }
        }
    }

    /** Called by the bundled Pantegnos WebAssembly bridge after local decryption. */
    fun onPantegnosDecrypted(fileName: String, text: String, error: String) {
        runOnUiThread {
            synchronized(pendingPantegnosImports) { pantegnosImportInFlight = false }
            if (error.isNotBlank()) {
                showImportMessage("تعذر فك ملف ${fileName}: $error")
            } else if (text.isBlank()) {
                showImportMessage("تم فك الملف، لكن لم يتم العثور على روابط أو بيانات اتصال قابلة للاستيراد.")
            } else {
                importIncomingContent(text)
            }
            dispatchNextPantegnosImport()
        }
    }

    private fun importIncomingContent(raw: String) {
        if (raw.isBlank() || raw.length > MAX_TEXT) {
            showImportMessage("الملف فارغ أو حجمه أكبر من المسموح.")
            return
        }
        if (UniversalLinks.looksLikeOpenVpn(raw)) {
            showImportMessage(ServiceProfiles.UNSUPPORTED["OpenVPN"] ?: "OpenVPN غير مدعوم في محرك sing-box.")
            return
        }
        if (UniversalLinks.looksLikeWireGuardConf(raw)) {
            try {
                val p = UniversalLinks.fromWireGuardConf(raw)
                val item = PendingImport("${p.protocol} • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveGeneric(p) })
                runOnUiThread { showImportConfirmation(listOf(item), 0) }
            } catch (e: Exception) {
                showImportMessage("تعذر استيراد ملف WireGuard: ${e.message}")
            }
            return
        }
        // Clash/Mihomo YAML: converted to share links by the page's tested converter, then re-imported.
        if (Regex("(?m)^\\s*proxies\\s*:").containsMatchIn(raw) && appWebView != null) {
            runOnUiThread {
                val js = "(function(){try{return JSON.stringify(window.falconClashToLinks(" + JSONObject.quote(raw) + "));}catch(e){return '{}';}})()"
                appWebView?.evaluateJavascript(js) { result ->
                    val links = runCatching {
                        val o = JSONObject(org.json.JSONTokener(result).nextValue() as String)
                        val a = o.optJSONArray("links")
                        (0 until (a?.length() ?: 0)).map { a!!.getString(it) }
                    }.getOrDefault(emptyList())
                    if (links.isEmpty()) showImportMessage("ملف YAML لا يحتوي على بروكسي مدعوم (VLESS / VMess / Trojan / Shadowsocks / SOCKS5 / Hysteria2).")
                    else importIncomingContent(links.joinToString("\n"))
                }
            }
            return
        }
        // Unknown formats are rejected rather than silently converted incorrectly.
        if (raw.trimStart().let { it.startsWith("{") || it.startsWith("[") }) {
            runCatching { parseSingBoxJsonImports(raw) }.onSuccess { items ->
                if (items.isNotEmpty()) showImportConfirmation(items, 0)
                else showImportMessage("ملف JSON لا يحتوي على outbound مدعوم.")
            }.onFailure { showImportMessage("تعذر تحليل JSON: ${it.message}") }
            return
        }
        val candidates = extractLinks(raw).take(MAX_IMPORT)
        // NetMod nm-*:// links are encrypted with NetMod's own key; they are counted, never decoded.
        val netModSkipped = Regex("(?i)(?<![\\w-])nm-[a-z0-9-]+://").findAll(raw).count()
        if (candidates.isEmpty() && netModSkipped > 0) {
            showImportMessage("الملف يحتوي على $netModSkipped رابط NetMod (nm-...) وهي مشفّرة بمفتاح NetMod ولا يمكن استيرادها. اطلب نسخة رابط عادي (vless:// أو vmess:// ...) أو صدّرها كنص من NetMod.")
            return
        }
        if (candidates.isEmpty()) {
            showImportMessage("وصل الملف إلى Falcon VPN، لكن نوعه غير مدعوم بمحرك الاتصال الحالي. يدعم التطبيق روابط VLESS وVMess وShadowsocks وTrojan وSOCKS وHTTP وTUIC وHysteria وHysteria2 وWireGuard وSSH وملفات sing-box JSON وWireGuard .conf وأرشيفات ZIP/GZ؛ صيغ OpenVPN/Psiphon والملفات المغلقة لتطبيقات أخرى غير مدعومة.")
            return
        }
        // Validate everything first, but store NOTHING until the user confirms: a link opened from any
        // other app must not be able to silently add (or select) an attacker's server.
        val pending = mutableListOf<PendingImport>()
        var rejected = netModSkipped
        var lastError: String? = null
        candidates.forEach { line ->
            try {
                pending += pendingImportForLink(line)
            } catch (e: Exception) {
                rejected++
                lastError = e.message
            }
        }
        if (pending.isEmpty()) {
            showImportMessage(if (candidates.size == 1 && lastError != null) "تعذر استيراد الكونفج: $lastError"
                              else "تعذر استيراد الكونفج: صيغة الرابط غير صحيحة أو غير مدعومة.")
            return
        }
        runOnUiThread { showImportConfirmation(pending, rejected) }
    }

    /** Convert one supported share link into a validated, not-yet-saved import item. */
    private fun pendingImportForLink(line: String): PendingImport {
        return when {
            line.startsWith("vless://", ignoreCase = true) -> {
                val p = VlessLinkParser.parse(line)
                PendingImport("VLESS • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveVless(p) }, p.allowInsecure)
            }
            line.startsWith("ss://", ignoreCase = true) -> {
                val p = ShadowsocksLinkParser.parse(line)
                PendingImport("Shadowsocks • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.save(p) })
            }
            else -> {
                val p = ServiceProfiles.fromLink(line)
                PendingImport("${p.protocol} • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveGeneric(p) }, p.singbox.optJSONObject("tls")?.optBoolean("insecure") == true)
            }
        }
    }

    /** Parse every readable entry in a multi-file archive and present one confirmation dialog. */
    private fun importArchiveEntries(archive: ConfigArchive.Result) {
        val pending = mutableListOf<PendingImport>()
        var rejected = archive.skipped.size
        var lastError: String? = null
        for ((entryName, raw) in archive.texts) {
            if (pending.size >= MAX_IMPORT) {
                rejected += 1
                continue
            }
            if (raw.length > MAX_TEXT) { rejected++; lastError = "أحد الملفات الداخلية أكبر من الحد النصي المسموح."; continue }
            val text = raw.trim()
            if (text.isEmpty()) { rejected++; continue }
            try {
                when {
                    UniversalLinks.looksLikeOpenVpn(text) -> {
                        rejected++
                        lastError = "ملف OpenVPN غير مدعوم في محرك الاتصال الحالي."
                    }
                    UniversalLinks.looksLikeWireGuardConf(text) -> {
                        val suggestedName = entryName.substringAfterLast('/').substringBeforeLast('.').ifBlank { "WireGuard" }
                        val p = UniversalLinks.fromWireGuardConf(text, suggestedName)
                        pending += PendingImport("${p.protocol} • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveGeneric(p) })
                    }
                    text.startsWith("{") || text.startsWith("[") -> {
                        val parsed = parseSingBoxJsonImports(text)
                        if (parsed.isEmpty()) rejected++ else pending.addAll(parsed.take(MAX_IMPORT - pending.size))
                    }
                    else -> {
                        val links = extractLinks(text)
                        if (links.isEmpty()) {
                            rejected++
                        } else {
                            for (link in links.take(MAX_IMPORT - pending.size)) {
                                try { pending += pendingImportForLink(link) }
                                catch (e: Exception) { rejected++; lastError = e.message }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                rejected++
                lastError = e.message
            }
        }
        if (pending.isEmpty()) {
            showImportMessage("لم يتم العثور على كونفجات مدعومة داخل الأرشيف." + (lastError?.let { "\n$it" } ?: ""))
            return
        }
        showImportConfirmation(pending, rejected)
    }

    /** Import sing-box JSON (single outbound or a full config containing outbounds). */
    private fun parseSingBoxJsonImports(raw: String): List<PendingImport> {
        val trimmed = raw.trimStart()
        val candidates: List<JSONObject> = if (trimmed.startsWith("[")) {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { array.optJSONObject(it) }
        } else {
            val root = JSONObject(raw)
            val outbounds = root.optJSONArray("outbounds")
            if (outbounds != null) (0 until outbounds.length()).mapNotNull { outbounds.optJSONObject(it) }
            else listOf(root)
        }
        require(candidates.size <= MAX_IMPORT) { "يحتوي ملف JSON على أكثر من $MAX_IMPORT عنصر؛ قسّم الملف إلى دفعات أصغر." }
        val supported = setOf("vless", "vmess", "shadowsocks", "trojan", "hysteria2", "hysteria", "tuic", "socks", "http", "ssh", "wireguard")
        return candidates.mapNotNull { outbound ->
            val type = outbound.optString("type").lowercase()
            if (type !in supported) return@mapNotNull null
            val copy = JSONObject(outbound.toString())
            val host: String
            val port: Int
            val endpoint = type == "wireguard"
            if (endpoint) {
                val peer = copy.optJSONArray("peers")?.optJSONObject(0) ?: return@mapNotNull null
                host = peer.optString("address"); port = peer.optInt("port")
            } else {
                host = copy.optString("server"); port = copy.optInt("server_port")
            }
            require(host.isNotBlank() && port in 1..65535) { "بيانات الخادم غير مكتملة في outbound من نوع $type." }
            val importedName = copy.optString("tag").ifBlank { type.uppercase() + " imported" }
            copy.remove("tag")
            val generic = com.falconvpn.app.vpn.engine.GenericProfile(
                name = importedName,
                protocol = type.uppercase(), host = host, port = port, singbox = copy, endpoint = endpoint
            )
            val insecure = copy.optJSONObject("tls")?.optBoolean("insecure") == true
            PendingImport("${type.uppercase()} • ${generic.name}\n   ${displayHost(host)}:$port", { profileStore.saveGeneric(generic) }, insecure)
        }
    }

    private fun displayHost(host: String) = if (host.contains(':')) "[$host]" else host

    private fun showImportConfirmation(items: List<PendingImport>, rejected: Int) {
        if (isFinishing || isDestroyed) return
        importDialog?.dismiss()
        val preview = items.take(5).joinToString("\n") { "• ${it.summary}" } +
            if (items.size > 5) "\n… و${items.size - 5} آخرين" else ""
        val skipped = if (rejected > 0) "\n\nتم تجاهل $rejected رابط غير صالح أو غير مدعوم." else ""
        importDialog = android.app.AlertDialog.Builder(this)
            .setTitle("استيراد ${items.size} كونفج؟")
            .setMessage("وصلت هذه الكونفجات من تطبيق أو ملف خارجي. السيرفر يرى كل حركة مرورك، فاستورد فقط ما تثق بمصدره.\n\n$preview$skipped" +
                if (items.any { it.insecureTls }) "\n\nتحذير أمني: بعض الكونفجات تطلب تعطيل التحقق من شهادة TLS (allowInsecure). هذا يسمح باحتمال اعتراض الاتصال. سيتم تطبيقه على هذه الكونفجات فقط، وليس على بقية الاتصالات." else "")
            .setPositiveButton("حفظ الكونفج") { _, _ -> commitImport(items) }
            .setNegativeButton("رجوع للقائمة") { _, _ -> returnToServicesList() }
            .setOnDismissListener { importDialog = null }
            .show()
    }

    private fun commitImport(items: List<PendingImport>) {
        var imported = 0
        var firstSavedId: String? = null
        var lastError: String? = null
        items.forEach { item ->
            try {
                val saved = item.save()
                check(saved.optBoolean("saved", false)) { "مخزن الكونفجات لم يؤكد عملية الحفظ." }
                val id = saved.optString("id").takeIf { it.isNotBlank() }
                    ?: error("تمت الكتابة دون إرجاع معرّف للكونفج.")
                // Verify the encrypted store can read the exact profile back before reporting success.
                val persisted = profileStore.getForEngine(id)
                    ?: error("لم يظهر الكونفج في التخزين بعد الحفظ.")
                check(persisted.optString("id") == id) { "فشل التحقق من الكونفج المحفوظ." }
                if (firstSavedId == null) firstSavedId = id
                imported++
            } catch (e: Exception) {
                lastError = e.message ?: "تعذر حفظ أحد الكونفجات."
            }
        }

        // The newly imported profile becomes the ready-to-run selection, unless a tunnel is active.
        // Never change the selected profile underneath a live engine.
        val runtime = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
        val state = runtime.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
        val tunnelBusy = state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING
        val selected = firstSavedId
        val selectedNow = if (!tunnelBusy && selected != null) runCatching { profileStore.select(selected) }.getOrDefault(false) else false

        val persistedCount = runCatching { profileStore.list().length() }.getOrDefault(0)
        val message = when {
            imported == 0 -> "تعذر حفظ الكونفج${lastError?.let { ": $it" } ?: "."}"
            tunnelBusy -> "تم حفظ $imported كونفج في الخدمات. افصل الاتصال الحالي أولاً ثم اختر الكونفج الجديد."
            selectedNow -> "تم حفظ $imported كونفج والتحقق من التخزين المشفر (الإجمالي: $persistedCount)، وتم تحديد أول كونفج تلقائياً. أصبح جاهزاً لمحاولة الاتصال."
            else -> "تم حفظ $imported كونفج والتحقق من التخزين المشفر (الإجمالي: $persistedCount). اختر الكونفج المطلوب قبل الاتصال."
        }
        showImportMessage(message)
    }

    private fun returnToServicesList() {
        runOnUiThread {
            appWebView?.evaluateJavascript("window.falconReturnToServicesList && window.falconReturnToServicesList()", null)
        }
    }

    private fun showImportMessage(message: String) {
        val safe = JSONObject.quote(message)
        runOnUiThread {
            appWebView?.post {
                appWebView?.evaluateJavascript("if (window.falconImportedConfig) { window.falconImportedConfig($safe); } else { window.__falconImportNotice = $safe; }", null)
            }
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- VPN permission + start

    private fun beginVpnPermissionFlow() {
        pendingConnectAfterPermission = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestVpnPermissionOrStart()
    }

    private fun requestVpnPermissionOrStart() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            saveRuntimeState(FalconVpnService.STATE_NEEDS_PERMISSION, "مطلوب السماح لاتصال VPN من نافذة أندرويد.")
            vpnPermissionLauncher.launch(prepareIntent)
        } else if (pendingConnectAfterPermission) {
            pendingConnectAfterPermission = false
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, FalconVpnService::class.java).setAction(FalconVpnService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            saveRuntimeState(FalconVpnService.STATE_ERROR, e.message ?: "تعذر تشغيل خدمة VPN.")
        }
    }

    private fun saveRuntimeState(state: String, message: String) {
        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).edit()
            .putString(FalconVpnService.KEY_STATE, state)
            .putString(FalconVpnService.KEY_MESSAGE, message)
            .putLong(FalconVpnService.KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == nativeImportPickerRequest) {
            val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
            if (uri == null) {
                showImportMessage("لم يتم اختيار ملف.")
                return
            }
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_IMPORT_BYTES) { "حجم الملف أكبر من 5 ميجابايت." }
                        out.write(buffer, 0, count)
                    }
                    out.toByteArray()
                } ?: error("تعذر فتح الملف من مزود المستندات.")
                val displayName = queryDisplayName(uri)
                appWebView?.post {
                    appWebView?.evaluateJavascript("window.falconNativeFileImported && window.falconNativeFileImported()", null)
                }
                importIncomingBytes(bytes, displayName)
            } catch (e: Exception) {
                showImportMessage("تعذر قراءة الملف: ${e.message ?: "تأكد أنه ملف نصي أو JSON."}")
            }
        } else if (requestCode == filePickerRequest) {
            val result = if (resultCode == Activity.RESULT_OK) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                    ?: data?.data?.let { arrayOf(it) }
            } else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        }
    }

    override fun onDestroy() {
        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(statusListener)
        uiHandler.removeCallbacks(pushRunnable)
        importDialog?.dismiss()
        importDialog = null
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        appWebView?.let { wv ->
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        appWebView = null
        super.onDestroy()
    }
}
