package com.falconvpn.app.vpn.engine

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Reads the plain-text entries of a .zip / .gz so their links can be imported. Only open text formats are read;
 * binary or encrypted entries are reported as skipped and are never decoded. Size limits stop zip bombs.
 */
object ConfigArchive {
    const val MAX_TOTAL_BYTES = 5 * 1024 * 1024
    const val MAX_ENTRIES = 100
    private val TEXT_EXTENSIONS = setOf("txt", "json", "conf", "ini", "yaml", "yml", "vpn", "sub", "list", "")

    class Result(val texts: List<Pair<String, String>>, val skipped: List<String>)

    fun isZip(b: ByteArray) = b.size >= 4 && b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && b[2] == 3.toByte() && b[3] == 4.toByte()
    fun isGzip(b: ByteArray) = b.size >= 2 && b[0] == 0x1F.toByte() && b[1] == 0x8B.toByte()

    fun read(bytes: ByteArray, displayName: String = ""): Result {
        val texts = mutableListOf<Pair<String, String>>()
        val skipped = mutableListOf<String>()
        when {
            isZip(bytes) -> {
                var budget = MAX_TOTAL_BYTES
                var entries = 0
                ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) continue
                        require(++entries <= MAX_ENTRIES) { "عدد الملفات داخل الأرشيف أكبر من $MAX_ENTRIES." }
                        val name = entry.name.substringAfterLast('/')
                        val data = readLimited(zip, budget)
                        budget -= data.size
                        addEntry(name, data, texts, skipped)
                    }
                }
            }
            isGzip(bytes) -> {
                val data = GZIPInputStream(ByteArrayInputStream(bytes)).use { readLimited(it, MAX_TOTAL_BYTES) }
                addEntry(displayName.removeSuffix(".gz").removeSuffix(".GZ").ifBlank { "content" }, data, texts, skipped, forceText = true)
            }
            else -> throw IllegalArgumentException("ليس أرشيف zip أو gz.")
        }
        return Result(texts, skipped)
    }

    private fun addEntry(
        name: String, data: ByteArray,
        texts: MutableList<Pair<String, String>>, skipped: MutableList<String>, forceText: Boolean = false
    ) {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (!forceText && ext !in TEXT_EXTENSIONS) { skipped += name; return }
        val text = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(data)).toString()
        } catch (_: Exception) { skipped += name; return }
        if (text.isBlank()) { skipped += name; return }
        texts += name to text
    }

    private fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            require(total <= limit) { "محتوى الأرشيف بعد فك الضغط أكبر من الحد المسموح (5 ميجابايت)." }
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
