/* Pantegnos AGPL-3.0 WebAssembly bridge. All decoding is local on-device. */
(function () {
  'use strict';
  let corePromise = null;

  function notifyNative(fileName, text, error) {
    const bridge = globalThis.FalconNative;
    if (bridge && typeof bridge.onPantegnosDecrypted === 'function') {
      bridge.onPantegnosDecrypted(String(fileName || ''), String(text || ''), String(error || ''));
    }
  }

  async function startCore() {
    if (corePromise) return corePromise;
    corePromise = (async function () {
      if (typeof globalThis.Go !== 'function') {
        throw new Error('ملف تشغيل WebAssembly (wasm_exec.js) غير موجود أو لم يتم تحميله.');
      }
      const go = new globalThis.Go();
      const response = await fetch('pantegnos.wasm', { cache: 'no-store' });
      if (!response.ok) throw new Error('تعذر تحميل محرك فك الملفات (HTTP ' + response.status + ').');
      const bytes = await response.arrayBuffer();
      if (!bytes.byteLength) throw new Error('ملف محرك فك الملفات فارغ.');
      const result = await WebAssembly.instantiate(bytes, go.importObject);
      // The Go WASM program registers its functions before waiting forever.
      const runtime = go.run(result.instance);
      runtime.catch(function (error) { console.error('Pantegnos runtime:', error); });
      for (let i = 0; i < 250; i++) {
        if (typeof globalThis.pantegnosDecrypt === 'function' &&
            typeof globalThis.pantegnosInspect === 'function') return true;
        await new Promise(resolve => setTimeout(resolve, 20));
      }
      throw new Error('بدأ محرك Pantegnos لكنه لم يسجل وظائف فك الملفات.');
    })().catch(function (error) {
      corePromise = null; // allow a clean retry after a transient load failure
      throw error;
    });
    return corePromise;
  }

  globalThis.falconDecryptImportedFile = async function (fileName, base64Data) {
    const name = String(fileName || 'config.bin');
    try {
      await startCore();
      const binary = atob(String(base64Data || ''));
      const data = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) data[i] = binary.charCodeAt(i);

      const inspected = globalThis.pantegnosInspect(name, data);
      if (!inspected || !inspected.ok) {
        throw new Error(inspected && inspected.error ? inspected.error : 'الصيغة غير مدعومة بواسطة محرك Pantegnos.');
      }

      let password = '';
      if (inspected.needsPassword) {
        password = globalThis.prompt('الملف محمي بكلمة مرور. أدخل كلمة المرور لفك التشفير:');
        if (password === null) throw new Error('تم إلغاء فك الملف لعدم إدخال كلمة المرور.');
      }

      const result = globalThis.pantegnosDecrypt(name, data, password);
      if (!result || !result.ok) {
        throw new Error(result && result.error ? result.error : 'فشل فك تشفير الملف.');
      }
      if (!result.text) throw new Error('تم فك الحاوية، لكن لم ينتج عنها نص إعدادات قابل للاستيراد.');
      notifyNative(name, result.text, '');
    } catch (error) {
      notifyNative(name, '', error && error.message ? error.message : String(error));
    }
  };

  globalThis.falconPantegnosStatus = async function () {
    try {
      await startCore();
      return { ok: true, decrypt: typeof globalThis.pantegnosDecrypt === 'function' };
    } catch (error) {
      return { ok: false, error: error && error.message ? error.message : String(error) };
    }
  };
})();
