package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class VlessLinkParserTest {
    private val uuid = "11111111-2222-3333-4444-555555555555"

    @Test fun parsesTlsWebSocketLink() {
        val p = VlessLinkParser.parse(
            "vless://$uuid@example.com:443?security=tls&type=ws&host=cdn.example.com&path=%2Fws%3Fed%3D2048" +
                "&sni=example.com&fp=chrome&alpn=h2%2Chttp%2F1.1#My%20Node"
        )
        assertEquals("example.com", p.host)
        assertEquals(443, p.port)
        assertEquals("tls", p.security)
        assertEquals("ws", p.transport)
        assertEquals("cdn.example.com", p.wsHost)
        assertEquals("/ws?ed=2048", p.path)
        assertEquals("example.com", p.sni)
        assertEquals("chrome", p.fingerprint)
        assertEquals(listOf("h2", "http/1.1"), p.alpn)
        assertEquals("My Node", p.name)
    }

    @Test fun acceptsUuidsThatAreNotRfc4122VersionOrVariant() {
        // The old regex required version 1-5 and variant [89ab] and rejected this.
        val p = VlessLinkParser.parse("vless://12345678-1234-1234-1234-123456789abc@example.com:443")
        assertEquals("12345678-1234-1234-1234-123456789abc", p.uuid)
    }

    @Test fun ipv6HostIsReturnedWithoutBrackets() {
        val p = VlessLinkParser.parse("vless://$uuid@[2001:db8::2]:8443?security=none")
        assertEquals("2001:db8::2", p.host)
        assertEquals(8443, p.port)
    }

    @Test fun parsesRealityWithVisionFlow() {
        val p = VlessLinkParser.parse(
            "vless://$uuid@example.com:443?security=reality&type=tcp&flow=xtls-rprx-vision&pbk=PUBKEY123" +
                "&sid=6ba85179e30d4fc2&fp=chrome&sni=www.microsoft.com#Reality"
        )
        assertEquals("reality", p.security)
        assertEquals("xtls-rprx-vision", p.flow)
        assertEquals("PUBKEY123", p.publicKey)
        assertEquals("6ba85179e30d4fc2", p.shortId)
        assertEquals("chrome", p.fingerprint)
        assertEquals("www.microsoft.com", p.sni)
    }

    @Test fun parsesGrpcServiceName() {
        val p = VlessLinkParser.parse("vless://$uuid@example.com:443?security=tls&type=grpc&serviceName=myGrpc")
        assertEquals("grpc", p.transport)
        assertEquals("myGrpc", p.serviceName)
    }

    @Test fun unencodedSpacesPipeAndEmojiInNameDoNotBreakParsing() {
        val p = VlessLinkParser.parse("vless://$uuid@example.com:443?security=tls#🇺🇸 US | Node 1")
        assertEquals("🇺🇸 US | Node 1", p.name)
    }

    @Test fun queryKeysAreCaseInsensitive() {
        val p = VlessLinkParser.parse("vless://$uuid@example.com:443?security=tls&serverName=sni.example.com")
        assertEquals("sni.example.com", p.sni)
    }

    @Test fun doubleEncodedPathIsDecoded() {
        val p = VlessLinkParser.parse("vless://$uuid@example.com:443?type=ws&path=%252Fws")
        assertEquals("/ws", p.path)
    }

    @Test fun wsWithoutPathDefaultsToSlash() {
        assertEquals("/", VlessLinkParser.parse("vless://$uuid@example.com:443?type=ws").path)
    }


    @Test fun preservesExplicitAllowInsecureFlagForPerProfileTlsPolicy() {
        val p = VlessLinkParser.parse("vless://$uuid@example.com:443?security=tls&allowInsecure=1")
        assertTrue(p.allowInsecure)
    }


    @Test fun importsCommonSharedVlessWebSocketTlsConfigWithInsecureFlag() {
        val p = VlessLinkParser.parse(
            "vless://$uuid@node.example.org:8443?path=%2Frealtime&security=tls&encryption=none&insecure=1&host=cdn.example.org&fp=ios&type=ws&allowInsecure=1&sni=cdn.example.org#shared-node"
        )
        assertEquals("node.example.org", p.host)
        assertEquals(8443, p.port)
        assertEquals("/realtime", p.path)
        assertEquals("ws", p.transport)
        assertEquals("cdn.example.org", p.wsHost)
        assertEquals("cdn.example.org", p.sni)
        assertEquals("ios", p.fingerprint)
        assertTrue(p.allowInsecure)
    }

    @Test fun insecureTlsFlagIsMappedToSingBoxPerProfile() {
        val parsed = VlessLinkParser.parse(
            "vless://$uuid@node.example.org:8443?security=tls&type=ws&path=%2Frealtime&insecure=1&allowInsecure=1&sni=scorm.example.org"
        )
        assertTrue(parsed.allowInsecure)
        val stored = org.json.JSONObject()
            .put("protocol", "VLESS")
            .put("host", parsed.host)
            .put("port", parsed.port)
            .put("uuid", parsed.uuid)
            .put("security", parsed.security)
            .put("sni", parsed.sni)
            .put("transport", parsed.transport)
            .put("path", parsed.path)
            .put("ws_host", parsed.wsHost)
            .put("allow_insecure", parsed.allowInsecure)
        val config = org.json.JSONObject(SingBoxConfig.build(stored))
        val outbound = config.getJSONArray("outbounds").getJSONObject(0)
        assertTrue(outbound.getJSONObject("tls").getBoolean("insecure"))
    }

    @Test fun rejectsLinksThatCannotBeHonoured() {
        val bad = mapOf(
            "reality without public key" to "vless://$uuid@example.com:443?security=reality&sni=a.com",
            "unsupported transport xhttp" to "vless://$uuid@example.com:443?type=xhttp",
            "vless encryption" to "vless://$uuid@example.com:443?encryption=mlkem768x25519plus.native.0rtt.xxx",
            "flow without tls" to "vless://$uuid@example.com:443?flow=xtls-rprx-vision",
            "unknown flow" to "vless://$uuid@example.com:443?security=tls&flow=xtls-rprx-direct",
            "bad uuid" to "vless://not-a-uuid@example.com:443",
            "missing port" to "vless://$uuid@example.com",
            "missing uuid" to "vless://example.com:443",
            "not vless" to "ss://abc@example.com:443"
        )
        bad.forEach { (why, link) ->
            val e = assertThrows("should reject: $why", IllegalArgumentException::class.java) { VlessLinkParser.parse(link) }
            assertTrue(e.message.orEmpty().isNotBlank())
        }
    }

    @Test
    fun flowNoneIsTreatedAsNoFlow() {
        val p = VlessLinkParser.parse("vless://7e364b66-3d3d-40c4-8721-f4dad203c7e2@h.example.com:8443?security=tls&encryption=none&headerType=none&type=ws&path=%252Frealtime&sni=a.example.com&flow=none&host=a.example.com&fp=chrome#t")
        org.junit.Assert.assertEquals("", p.flow)
        org.junit.Assert.assertEquals("/realtime", p.path)
    }
}
