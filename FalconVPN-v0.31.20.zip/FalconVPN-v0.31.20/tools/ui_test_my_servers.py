import asyncio, json, pathlib
from playwright.async_api import async_playwright
html = pathlib.Path('app/src/main/assets/index.html').resolve().as_uri()
MOCK = """
window.__sel='b';
window.FalconNative={
 listSavedProfiles(){return JSON.stringify({ok:true,selectedId:window.__sel,profiles:[
  {id:'a',name:'Germany-1',protocol:'VLESS',host:'de.example.com',port:443,flag:'🇩🇪'},
  {id:'b',name:'WE router',protocol:'VLESS',host:'uk5.example.org',port:8443,flag:''},
  {id:'c',name:'مصر UDP',protocol:'TUIC',host:'eg.example.com',port:443,flag:'🇪🇬'}]})},
 pingSavedProfile(id){return JSON.stringify(id==='a'?{ok:true,supported:true,ms:48}:id==='b'?{ok:true,supported:true,ms:-1}:{ok:true,supported:false,ms:-1})},
 selectSavedProfile(id){window.__sel=id;return JSON.stringify({ok:true})}
};"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.add_init_script(MOCK)
        await pg.goto(html); await pg.wait_for_timeout(1200)
        rows = await pg.locator('#falconMyServers .fms-row').count()
        print('rows', rows)
        await pg.locator('#falconMyServers .fms-actions button').first.click()
        await pg.wait_for_timeout(1500)
        txt = await pg.locator('#falconMyServers').inner_text()
        print(txt.replace('\n',' | '))
        await pg.locator('#falconMyServers .fms-actions button').nth(1).click()
        await pg.wait_for_timeout(500)
        print('selected first row:', await pg.locator('#falconMyServers .fms-row').first.get_attribute('class'))
        print('errors', errs)
        await b.close()
asyncio.run(main())
