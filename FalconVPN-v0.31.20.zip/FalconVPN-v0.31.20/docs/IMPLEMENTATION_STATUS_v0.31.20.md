# Falcon VPN — implementation status 0.31.20

## Changes in this revision
- Multi-entry ZIP/GZ imports are parsed entry-by-entry and presented in one native confirmation dialog.
- Multi-entry archives can preserve supported sing-box JSON outbounds, WireGuard `.conf` entries, and supported share links instead of extracting share links only.
- WireGuard archive entries use the filename as a suggested profile name.
- Android `ACTION_SEND_MULTIPLE` files are read as one bounded batch so successive confirmation dialogs do not replace one another.
- A multi-file share is capped at 100 items and 5 MiB total input; individual archive entries are capped by the existing 200,000-character text limit before parsing.
- Reuses the same link parser and pending-import construction for regular imports and archive imports.
- VersionCode 65 / versionName 0.31.20.

## Static checks performed for this edit
- `builtin_services.json` parses as JSON.
- All 19 inline JavaScript blocks in `assets/index.html` pass `node --check`.
- `assets/pantegnos-bridge.js` passes `node --check`.
- ZIP archive integrity and source markers are checked when packaging.

## Not verified here
- Kotlin/Gradle compilation and Android lint.
- JVM unit test execution.
- APK assembly and APK contents verification.
- Actual device testing of import dialogs, libbox startup, VPN routing, DNS, exit IP, reconnect, or traffic-leak behaviour.

These remaining checks must be run by the GitHub Actions workflow and on a physical Android device. A valid parse/import result is not proof that a server is reachable or that the VPN tunnel works.
