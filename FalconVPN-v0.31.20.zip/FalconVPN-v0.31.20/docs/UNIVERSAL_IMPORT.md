# Universal config import — what is supported

| Input | Status |
|---|---|
| `vless://` `vmess://` `ss://` `trojan://` `hysteria2://` `hy2://` | supported (earlier versions) |
| `socks://` `socks4://` `socks5://` | supported (0.31.14) |
| `http://user:pass@host:port` / `https://...` proxy | supported; needs credentials + explicit port, otherwise it is treated as an ordinary URL |
| `tuic://` `hysteria://` `wireguard://` `wg://` `ssh://` | supported (0.31.14); `ssh://` needs a password (private keys: use the form) |
| `.json` (sing-box outbound / full config) | supported |
| `.txt` lists, Base64 subscriptions, https subscription URL (`importSubscription`) | supported |
| WireGuard `.conf` | supported (first `[Peer]`) |
| `.zip`, `.gz` | text entries only, max 100 entries / 5 MB after decompression |
| `.yaml` / `.yml` | only links inside the text are read; Clash/sing-box YAML structure is not parsed yet |
| `.ovpn` / OpenVPN | not supported: sing-box has no OpenVPN. Needs a separate engine |
| `nm-ssh://` | recognised, rejected (needs a dedicated parser) |
| `.hat` `.ehi` `.hc` `.npv` `.npvt` `.nm` `.tnl` ... | closed/encrypted formats of other apps: only config files exported in an open form can be imported |

## About `third_party/Pantegnos`
That module decrypts locked exports of other VPN apps. It was in the uploaded project and has not been modified or extended here. Recommendation: remove it. Locked files are usually locked on purpose by whoever made the config (hidden server, expiry, device binding), and it is AGPL-3.0, which obliges you to publish the source of the whole app that bundles it.

## Country / flag
Guessed from the config name only (flag emoji, ISO code like `DE`, English or Arabic country name). A server whose name carries no country shows no flag. Nothing is geolocated online.

## Ping
`pingSavedProfile(id)` = TCP connect time. Run it before connecting (while connected it goes through the tunnel). Hysteria / Hysteria2 / TUIC / WireGuard are UDP and report "not measurable".
