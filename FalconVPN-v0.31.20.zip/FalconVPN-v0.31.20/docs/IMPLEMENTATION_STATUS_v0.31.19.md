# Falcon VPN — implementation status 0.31.19

This document separates source-level changes from functionality that still requires a successful Android build and device testing.

## Changes in this revision

- Built-in service selection changes the visible picker only after the Android bridge confirms that the config was saved, selected, and returned with a profile ID.
- An unsupported or unrecognized built-in entry no longer replaces the selected service in the UI. The picker remains open and displays an explanation.
- The import dialog's normal text-file input now uses the WebView/Android file chooser path, so a selected text/JSON/YAML file can populate the import text area and be inspected before saving.
- ZIP/GZIP and recognized encrypted formats have a separate action that uses the native Android import path, where archive limits and the existing local decoder/import pipeline apply. That native path uses Android confirmation; it does not pretend that the browser's text inspection has run.
- The build workflow prefers a complete Android project committed at the repository root. If the repository contains only project ZIPs, it examines all valid Falcon project archives and selects the one with the highest numeric `versionCode`.
- App version is now `versionName 0.31.19`, `versionCode 64`.

## Current known limits (not claimed as completed)

- NetMod-specific `nm-*` formats are not automatically supported by sing-box. They must be decoded/converted using a compatible implementation before they can be run; they should not be presented as ready-to-connect profiles merely because their labels are visible.
- OpenVPN, UDP Custom, Psiphon, and One Cloud require separate compatible engine/integration work where the current engine does not support them.
- Parsing a config is not proof that a remote server is online. The app must successfully start Libbox, create a valid TUN, make Android route traffic through the VPN, and pass the existing HTTPS exit-IP probe before reporting CONNECTED.
- A source-level inspection cannot prove that any particular server is reachable or that the current APK works on a device.

## Checks performed for this revision

- Parsed `builtin_services.json`; confirmed 19 entries and required label/link/category/provider metadata.
- Ran Node syntax checks on all 17 inline JavaScript blocks in `app/src/main/assets/index.html`.
- Parsed `.github/workflows/build.yml` with PyYAML. PyYAML's YAML 1.1 parser reads the GitHub Actions key `on` as a boolean; this is a known parser behavior, not a change to the workflow key.
- Ran Python bytecode compilation on the UI test scripts.
- Attempted `python3 tools/ui_test.py`, but the test could not launch because the Playwright Chromium executable is not installed in this environment.
- Gradle/Android build and on-device tests were not run here. Run the GitHub Actions workflow and test the resulting APK on a phone before treating the VPN connection as verified.
