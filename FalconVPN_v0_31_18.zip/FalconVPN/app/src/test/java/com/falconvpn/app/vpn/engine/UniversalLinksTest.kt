package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class UniversalLinksTest {
    private val uuid = "11111111-2222-3333-4444-555555555555"
    private val key = Base64.getEncoder().encodeToString(ByteArray(32) { it.toByte() })
    private val key2 = Base64.getEncoder().encodeToString(ByteArray(32) { (it + 1).toByte() })

    private fun rejects(block: () -> Unit) {
        try { block(); fail("expected IllegalArgumentException") } catch (_: IllegalArgumentException) {}
    }

    @Test fun socks5WithCredentials() {
        val p = UniversalLinks.fromLink("socks5://user:p%40ss@1.2.3.4:1080#Cairo")!!
        assertEquals("Cairo", p.name)
        assertEquals("socks", p.singbox.getString("type"))
        assertEquals("5", p.singbox.getString("version"))
        assertEquals("p@ss", p.singbox.getString("password"))
        assertEquals(1080, p.port)
    }

    @Test fun socksBase64UserInfo() {
        val cred = Base64.getEncoder().encodeToString("bob:secret".toByteArray())
        val p = UniversalLinks.fromLink("socks://$cred@h.example.com:1081")!!
        assertEquals("bob", p.singbox.getString("username"))
        assertEquals("secret", p.singbox.getString("password"))
    }

    @Test fun httpProxyOnlyWithCredentialsAndPort() {
        assertTrue(UniversalLinks.isUniversalLink("http://u:p@1.2.3.4:8080#P"))
        assertFalse(UniversalLinks.isUniversalLink("https://example.com/sub/abcdef"))
        assertFalse(UniversalLinks.isUniversalLink("https://example.com:443"))
        val p = UniversalLinks.fromLink("https://u:p@h.example.com:8443#S")!!
        assertEquals("http", p.singbox.getString("type"))
        assertTrue(p.singbox.getJSONObject("tls").getBoolean("enabled"))
    }

    @Test fun tuicLink() {
        val p = UniversalLinks.fromLink(
            "tuic://$uuid:secret@t.example.com:443?congestion_control=bbr&alpn=h3&sni=t.example.com&allow_insecure=1#T1"
        )!!
        assertEquals("tuic", p.singbox.getString("type"))
        assertEquals(uuid, p.singbox.getString("uuid"))
        assertEquals("secret", p.singbox.getString("password"))
        assertTrue(p.singbox.getJSONObject("tls").getBoolean("insecure"))
        rejects { UniversalLinks.fromLink("tuic://not-a-uuid:pw@t.example.com:443") }
    }

    @Test fun hysteriaV1Link() {
        val p = UniversalLinks.fromLink("hysteria://h.example.com:443?auth=abc&peer=h.example.com&upmbps=20&downmbps=100&obfsParam=pw#H1")!!
        assertEquals("hysteria", p.singbox.getString("type"))
        assertEquals(20, p.singbox.getInt("up_mbps"))
        assertEquals("abc", p.singbox.getString("auth_str"))
        assertEquals("pw", p.singbox.getString("obfs"))
    }

    @Test fun sshLinkDefaultsPort22() {
        val p = UniversalLinks.fromLink("ssh://root:pw@h.example.com#S")!!
        assertEquals(22, p.port)
        assertEquals("root", p.singbox.getString("user"))
        rejects { UniversalLinks.fromLink("ssh://root@h.example.com:22") }
    }

    @Test fun wireguardLinkAndConf() {
        val p = UniversalLinks.fromLink("wireguard://$key@1.2.3.4:51820?publickey=$key2&address=10.0.0.2&mtu=1280&reserved=1,2,3#WG")!!
        assertTrue(p.endpoint)
        assertEquals("10.0.0.2/32", p.singbox.getJSONArray("address").getString(0))
        assertEquals(1280, p.singbox.getInt("mtu"))
        assertEquals(3, p.singbox.getJSONArray("peers").getJSONObject(0).getJSONArray("reserved").length())

        val conf = "[Interface]\nPrivateKey = $key\nAddress = 10.0.0.2/32, fd00::2/128\nDNS = 1.1.1.1\n\n" +
            "[Peer]\nPublicKey = $key2\nEndpoint = 5.6.7.8:51820\nAllowedIPs = 0.0.0.0/0\n"
        assertTrue(UniversalLinks.looksLikeWireGuardConf(conf))
        val c = UniversalLinks.fromWireGuardConf(conf, "Office")
        assertEquals("5.6.7.8", c.host)
        assertEquals(2, c.singbox.getJSONArray("address").length())
    }

    @Test fun unknownSchemesAreNotHandled() {
        assertNull(UniversalLinks.fromLink("vless://x@y:1"))
        assertFalse(UniversalLinks.isUniversalLink("nm-ssh://abc"))
        rejects { UniversalLinks.fromLink("nm-ssh://abc") }
    }

    @Test fun detectsOpenVpn() {
        assertTrue(UniversalLinks.looksLikeOpenVpn("client\ndev tun\nproto udp\nremote 1.2.3.4 1194\n"))
        assertFalse(UniversalLinks.looksLikeOpenVpn("vless://abc@def:443"))
    }

    @Test fun countryGuessUsesOnlyTheName() {
        assertEquals("DE", CountryGuess.codeOf("\uD83C\uDDE9\uD83C\uDDEA node"))
        assertEquals("DE", CountryGuess.codeOf("Germany-1"))
        assertEquals("EG", CountryGuess.codeOf("سيرفر مصر"))
        assertEquals("", CountryGuess.codeOf("WE router speed"))
        assertEquals("", CountryGuess.codeOf("woman"))
        assertEquals("AE", CountryGuess.codeOf("UAE fast"))
        assertEquals("\uD83C\uDDE9\uD83C\uDDEA", CountryGuess.flagOf("DE"))
    }

    @Test fun archiveReadsTextAndSkipsBinary() {
        val zipBytes = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                z.putNextEntry(ZipEntry("a.txt")); z.write("socks5://u:p@1.2.3.4:1080".toByteArray()); z.closeEntry()
                z.putNextEntry(ZipEntry("locked.hat")); z.write(byteArrayOf(1, 2, 3)); z.closeEntry()
            }
        }.toByteArray()
        assertTrue(ConfigArchive.isZip(zipBytes))
        val r = ConfigArchive.read(zipBytes)
        assertEquals(1, r.texts.size)
        assertEquals(listOf("locked.hat"), r.skipped)

        val gz = ByteArrayOutputStream().also { b -> GZIPOutputStream(b).use { it.write("ssh://r:p@h:22".toByteArray()) } }.toByteArray()
        assertTrue(ConfigArchive.isGzip(gz))
        assertEquals("ssh://r:p@h:22", ConfigArchive.read(gz, "list.txt.gz").texts.single().second)
    }
}
