# Getting libbox.aar

`app/libs/libbox.aar` is native code that runs inside the VPN process, so its origin matters.

* `build.yml` currently downloads 1.13.14 from JitPack and **fails** unless the SHA-256 matches the pinned value.
  JitPack is a third-party mirror; the pin protects against a swapped file, not against a bad first download.
* Preferred: run the manual workflow `build-libbox.yml` (or `make lib_android` in a sing-box checkout) to build the
  AAR from the official SagerNet/sing-box tag, read the printed SHA-256, and pin THAT hash in `build.yml`.
* The recipe in `build-libbox.yml` was written from memory of the sing-box build system and has never been run
  here. If a step fails, follow the current sing-box documentation ("Build from source" -> Android / libbox).
* The AAR must contain the ABIs you package (`-PfalconAbis=arm64-v8a,x86_64` for an emulator build).

License: sing-box is GPL-3.0. Distributing the APK means distributing under compatible terms (source offer).
Decide this before publishing, especially together with closed-source code or ad SDKs.
