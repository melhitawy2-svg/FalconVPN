# Falcon VPN v0.30.2 — Connection diagnostics

## Important manifest correction
The VpnService is now `android:exported="true"` while retaining `android.permission.BIND_VPN_SERVICE`. Android's system VPN manager must be able to bind to the declared VPN service; the signature-level permission prevents ordinary third-party apps from binding.

## Runtime stages
The native service now reports these stages to SharedPreferences and Logcat: service accepted, VPN permission available, profile validation, Libbox setup, CommandServer start, TUN creation, and successful Libbox start. Failures are recorded as an error state and logged under `FalconVpnService`. No UUID, password, private key, or full config JSON is logged.

## Real connectivity probe
`FalconNative.runConnectivityTest()` makes an HTTPS request to `https://ipinfo.io/json` from the app process and reports the observed public IP, country, ASN/organization, and whether Android's active network has `TRANSPORT_VPN`. A successful HTTP response alone is not proof of tunnel routing; `vpnTransport=true` is an additional OS-level indicator. Compare the observed IP with the baseline while disconnected.

## Required device test
1. Import a known-good, currently active server profile (the project does not ship free/working server credentials).
2. Select that profile.
3. Connect and grant Android VPN permission.
4. Run the connectivity probe and compare IP/country/ASN with VPN disconnected.
5. If startup fails, inspect `mapConfig` status text and Logcat tag `FalconVpnService`.

This build does not provision VPN servers or create carrier-specific configs. A valid external server profile is still required.
