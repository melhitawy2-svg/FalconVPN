# Connection diagnostics v0.30.4

This release tightens the connection button and runtime state handling. The button now disconnects only when the native bridge reports both `state=CONNECTED` and `engineRunning=true`; it waits during CONNECTING only when `engineStarting=true`. Otherwise it invokes the native connect flow. This prevents a persisted or stale UI state from being treated as an active VPN session.

The UI treats CONNECTED as valid only when the native bridge reports `engineRunning=true`, which is set only after Libbox has opened a valid Android TUN descriptor. CONNECTING is retained only while a native start attempt is active. The bridge now exposes the engine stage and last native error to the page.

The map no longer displays a country marker based only on the country dropdown; actual server geolocation is not yet available from the configured profile.

A successful APK build does not prove a working remote proxy. A real saved server profile is still required, followed by on-device validation of VPN permission, TUN creation, Android VPN transport, public IP change, and traffic flow.
