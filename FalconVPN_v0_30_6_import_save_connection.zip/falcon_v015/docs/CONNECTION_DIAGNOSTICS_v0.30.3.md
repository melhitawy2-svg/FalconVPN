# Falcon VPN v0.30.3 — connection-state correction

- Runtime `CONNECTED` is no longer trusted merely because `startOrReloadService` returned.
- The app waits for `openTun` to provide a valid, open Android `ParcelFileDescriptor`.
- The in-memory `engineRunning` flag is set only after that descriptor is verified and is never persisted.
- Persisted `CONNECTED` state is reconciled to `DISCONNECTED` after process death or when no live TUN was established.
- Failure and shutdown paths close the command server/TUN and clear the runtime engine flag.
- Removed hard-coded 12.6/8.4 Mbps display values. Traffic remains unavailable until real per-UID deltas are sampled.
- Map label now explicitly identifies the selected country; the fabricated route line is hidden. This is not server geolocation.

A valid imported server profile is still required. This source change has not been device-tested; GitHub Actions build and a real server test are required.
