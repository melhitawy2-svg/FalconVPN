# Falcon VPN v0.30.6 — Import and save flow

## Import form
- The import dialog has separate actions: `فحص الكونفج`, `حفظ الكونفج`, and `رجوع للقائمة`.
- Preview is read-only; it does not persist profiles.
- Save delegates parsing and validation to the Android native bridge.
- Supported links and sing-box JSON are persisted through the encrypted profile store.

## Saved profile behavior
- A newly imported profile becomes the selected profile for the next connection when no VPN tunnel is active.
- When a tunnel is already connected/connecting, imports are saved but the active selection is not changed.
- After a successful save, the app refreshes and reveals the saved services list.
- Service-template forms use the same `حفظ الكونفج` / `رجوع للقائمة` wording and save through the native profile store.

## External share behavior
- Android share/open intents show a native confirmation summary.
- `حفظ الكونفج` commits the parsed profiles.
- `رجوع للقائمة` returns to the service chooser without saving.
- TLS `allowInsecure` remains per-profile and triggers an explicit warning; it is not a global Android permission.

## Connection behavior
- The Connect action uses the selected saved profile and starts the Android `VpnService` / sing-box libbox engine.
- A successful import only means the profile was parsed and saved; it does not prove that the remote server is online or that credentials are valid.
- Real connection must be verified on-device with a valid live server by checking TUN creation, traffic through the tunnel, and public IP change.
