# Falcon VPN 0.30.5 — Import compatibility

## Import paths
- Android `ACTION_VIEW` custom links: ss, vless, vmess, trojan, hysteria2, hy2.
- Android `ACTION_SEND` / `ACTION_SEND_MULTIPLE`: text and JSON files shared from other apps.
- Text subscription bodies: supported link lines are extracted; Base64 subscription bodies are decoded.
- sing-box JSON: one outbound object or a full config containing an `outbounds` array; supported outbound types are vless, vmess, shadowsocks, trojan, hysteria2, tuic, socks, http, ssh, and wireguard.

## TLS insecure flag
`allowInsecure=1`, `insecure=1`, and equivalent true values are preserved only on the imported profile. The import confirmation warns that certificate verification is disabled. This is not an Android permission. It weakens TLS identity verification and should only be used for a server whose operator/source the user trusts. Other profiles keep normal certificate validation.

## Limits
This is a protocol-aware importer, not a universal converter for every VPN app. Proprietary formats and protocols requiring their own engine (for example OpenVPN `.ovpn`, Psiphon, and vendor-specific app exports) are not converted by sing-box. The app reports unsupported formats instead of saving fake profiles.

## Validation
Import parsing and config generation have unit tests. Real connection still requires a valid server, compatible protocol settings, a packaged libbox AAR, and on-device tunnel testing.
