package com.falconvpn.app.vpn.engine

import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the sing-box JSON configuration for a stored profile.
 *
 * The result is returned as a String and handed to libbox in memory: the proxy password / UUID is
 * never written to disk. Needs no Android Context, so it can be unit-tested on the JVM.
 * Never log the returned string.
 */
object SingBoxConfig {
    /** Conservative tunnel MTU; the libbox default is too large for many mobile / tunnelled paths. */
    const val TUN_MTU = 1400

    fun build(profile: JSONObject): String {
        val host = profile.optString("host")
        val port = profile.optInt("port")
        require(host.isNotBlank() && port in 1..65535) { "بيانات السيرفر المحدد غير مكتملة." }

        // Profiles of the generic protocols carry a ready sing-box outbound (or WireGuard endpoint).
        val generic = profile.optString("singbox").takeIf { it.isNotBlank() }?.let { JSONObject(it).put("tag", "proxy") }
        val isEndpoint = generic != null && profile.optBoolean("endpoint")
        val outbound: JSONObject? = when {
            generic != null -> if (isEndpoint) null else generic
            profile.optString("protocol", "Shadowsocks").lowercase() == "vless" -> vlessOutbound(profile, host, port)
            else -> shadowsocksOutbound(profile, host, port)
        }
        val direct = JSONObject().put("type", "direct").put("tag", "direct")

        // dns-direct resolves the proxy server's own hostname outside the tunnel (bootstrap).
        // dns-remote is DNS-over-HTTPS carried through the proxy, so lookups are encrypted and
        // do not depend on the proxy server supporting UDP.
        val dnsDirect = JSONObject()
            .put("type", "udp").put("tag", "dns-direct")
            .put("server", "1.1.1.1").put("server_port", 53)
        val dnsRemote = JSONObject()
            .put("type", "https").put("tag", "dns-remote")
            .put("server", "1.1.1.1")
            .put("detour", "proxy")

        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", TUN_MTU)
            .put("auto_route", true)
            .put("strict_route", false)
            .put("stack", "mixed")

        val rules = JSONArray()
            .put(JSONObject().put("action", "sniff"))
            .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
            // Local network (printers, router, casting) must not be sent through the proxy.
            .put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))

        val outbounds = JSONArray()
        outbound?.let { outbounds.put(it) }
        outbounds.put(direct)
        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", JSONObject()
                .put("servers", JSONArray().put(dnsRemote).put(dnsDirect))
                .put("final", "dns-remote"))
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject()
                .put("final", "proxy")
                .put("auto_detect_interface", true)
                .put("default_domain_resolver", "dns-direct")
                .put("rules", rules))
        if (isEndpoint) root.put("endpoints", JSONArray().put(generic))
        return root.toString()
    }

    private fun shadowsocksOutbound(profile: JSONObject, host: String, port: Int): JSONObject {
        val method = profile.optString("method")
        val password = profile.optString("password")
        require(method.isNotBlank() && password.isNotEmpty()) { "بيانات Shadowsocks غير مكتملة." }
        val item = JSONObject()
            .put("type", "shadowsocks").put("tag", "proxy")
            .put("server", host).put("server_port", port)
            .put("method", method).put("password", password)
        profile.optString("plugin").takeIf { it.isNotBlank() }?.let { plugin ->
            item.put("plugin", plugin)
            profile.optString("plugin_opts").takeIf { it.isNotBlank() }?.let { item.put("plugin_opts", it) }
        }
        return item
    }

    private fun vlessOutbound(profile: JSONObject, host: String, port: Int): JSONObject {
        val uuid = profile.optString("uuid")
        require(uuid.isNotBlank()) { "UUID الخاص بكونفج VLESS غير موجود." }
        val item = JSONObject()
            .put("type", "vless").put("tag", "proxy")
            .put("server", host).put("server_port", port)
            .put("uuid", uuid)
        profile.optString("flow").takeIf { it.isNotBlank() }?.let { item.put("flow", it) }

        val security = profile.optString("security", "none").lowercase()
        val fingerprint = profile.optString("fp")
        when (security) {
            "tls", "reality" -> {
                val tls = JSONObject().put("enabled", true)
                if (profile.optBoolean("allow_insecure")) tls.put("insecure", true)
                profile.optString("sni").takeIf { it.isNotBlank() }?.let { tls.put("server_name", it) }
                val alpn = profile.optString("alpn").split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (alpn.isNotEmpty()) tls.put("alpn", JSONArray(alpn))
                if (security == "reality") {
                    val publicKey = profile.optString("pbk")
                    require(publicKey.isNotBlank()) { "كونفج Reality لا يحتوي على المفتاح العام (pbk)." }
                    tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint.ifBlank { "chrome" }))
                    tls.put("reality", JSONObject()
                        .put("enabled", true)
                        .put("public_key", publicKey)
                        .put("short_id", profile.optString("sid")))
                } else if (fingerprint.isNotBlank()) {
                    tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint))
                }
                item.put("tls", tls)
            }
            "none" -> Unit
            else -> error("نوع الحماية غير مدعوم: $security")
        }

        val path = profile.optString("path")
        val hostHeader = profile.optString("ws_host")
        when (val transport = profile.optString("transport", "tcp").lowercase()) {
            "tcp", "" -> Unit
            "ws" -> {
                val ws = JSONObject().put("type", "ws")
                path.takeIf { it.isNotBlank() }?.let { ws.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { ws.put("headers", JSONObject().put("Host", it)) }
                item.put("transport", ws)
            }
            "grpc" -> item.put("transport", JSONObject()
                .put("type", "grpc").put("service_name", profile.optString("service_name")))
            "httpupgrade" -> {
                val t = JSONObject().put("type", "httpupgrade")
                path.takeIf { it.isNotBlank() }?.let { t.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { t.put("host", it) }
                item.put("transport", t)
            }
            "http" -> {
                val t = JSONObject().put("type", "http")
                path.takeIf { it.isNotBlank() }?.let { t.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { t.put("host", JSONArray().put(it)) }
                item.put("transport", t)
            }
            else -> error("نقل VLESS من نوع $transport غير مدعوم.")
        }
        return item
    }
}
