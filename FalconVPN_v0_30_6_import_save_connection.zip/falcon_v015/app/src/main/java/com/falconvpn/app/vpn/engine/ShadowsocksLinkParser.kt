package com.falconvpn.app.vpn.engine

import java.util.Base64

/**
 * Parses Shadowsocks share links:
 *  - SIP002:  ss://BASE64URL(method:password)@host:port/?plugin=...#name
 *  - SIP002 with a percent-encoded plain userinfo: ss://method:pass%40word@host:port#name
 *  - legacy:  ss://BASE64(method:password@host:port)#name
 *
 * Parsing/importing does not open a socket or establish a VPN.
 */
data class ShadowsocksProfile(
    val name: String,
    val host: String,
    val port: Int,
    val method: String,
    val password: String,
    /** sing-box plugin name ("obfs-local" or "v2ray-plugin"), empty when none. */
    val plugin: String = "",
    /** Plugin options in SIP003 form, e.g. "obfs=http;obfs-host=example.com". */
    val pluginOpts: String = ""
)

object ShadowsocksLinkParser {
    /** SIP003 plugin name -> the name sing-box understands. Anything else is rejected at import. */
    private val SUPPORTED_PLUGINS = mapOf(
        "obfs-local" to "obfs-local",
        "simple-obfs" to "obfs-local",
        "v2ray-plugin" to "v2ray-plugin"
    )
    private val METHOD_PATTERN = Regex("[a-z0-9._-]+")

    fun parse(rawLink: String): ShadowsocksProfile {
        val raw = rawLink.trim()
        require(raw.startsWith("ss://", ignoreCase = true)) { "Not a Shadowsocks link" }

        val (beforeFragment, fragment) = LinkSyntax.splitFragment(raw.substring(5))
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val query = LinkSyntax.parseQuery(rawQuery)

        val credentials: Pair<String, String>
        val endpoint: LinkSyntax.HostPort
        val at = main.lastIndexOf('@')
        if (at >= 0) {
            credentials = decodeCredentials(main.substring(0, at))
            endpoint = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))
        } else {
            // Legacy form: the whole "method:password@host:port" is Base64-encoded.
            val decoded = decodeBase64(main.trimEnd('/')) ?: decodeBase64(main)
                ?: throw IllegalArgumentException("رابط Shadowsocks غير صالح.")
            val inner = decoded.lastIndexOf('@')
            require(inner > 0) { "رابط Shadowsocks غير صالح." }
            credentials = splitCredentials(decoded.substring(0, inner))
            endpoint = LinkSyntax.parseHostPort(decoded.substring(inner + 1))
        }

        val method = credentials.first.lowercase()
        val password = credentials.second
        require(METHOD_PATTERN.matches(method)) { "Invalid encryption method" }
        require(password.isNotEmpty()) { "Missing password" }

        var plugin = ""
        var pluginOpts = ""
        val pluginRaw = query["plugin"].orEmpty().trim()
        if (pluginRaw.isNotEmpty()) {
            val pluginName = pluginRaw.substringBefore(';').trim().lowercase()
            plugin = SUPPORTED_PLUGINS[pluginName]
                ?: throw IllegalArgumentException("إضافة Shadowsocks غير مدعومة: ${LinkSyntax.sanitizeLabel(pluginName, 40)}")
            pluginOpts = pluginRaw.substringAfter(';', "")
        }

        val label = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "Shadowsocks server" }
        return ShadowsocksProfile(label, endpoint.host, endpoint.port, method, password, plugin, pluginOpts)
    }

    private fun decodeCredentials(userInfo: String): Pair<String, String> {
        val decoded = LinkSyntax.percentDecode(userInfo, lenient = true)
        // "method:password" always contains ':', which is not a Base64 character, so this is unambiguous.
        val plain = if (decoded.contains(':')) decoded
        else decodeBase64(decoded) ?: throw IllegalArgumentException("Missing encrypted method/password section")
        return splitCredentials(plain)
    }

    private fun splitCredentials(plain: String): Pair<String, String> {
        val splitAt = plain.indexOf(':')
        require(splitAt > 0 && splitAt < plain.lastIndex) { "Expected method:password in Shadowsocks link" }
        return plain.substring(0, splitAt) to plain.substring(splitAt + 1)
    }

    /** Accepts standard and URL-safe Base64, with or without padding. Returns null if invalid. */
    private fun decodeBase64(text: String): String? {
        val normalized = text.filterNot { it.isWhitespace() }
            .replace('-', '+').replace('_', '/').trimEnd('=')
        if (normalized.isEmpty()) return null
        return try {
            val padded = normalized + "=".repeat((4 - normalized.length % 4) % 4)
            String(Base64.getDecoder().decode(padded), Charsets.UTF_8)
        } catch (_: IllegalArgumentException) {
            null
        }
    }
}
