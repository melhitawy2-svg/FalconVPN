package com.falconvpn.app.vpn.engine

import java.net.URLDecoder

/**
 * Small, tolerant parser for share-link syntax.
 *
 * java.net.URI is deliberately NOT used: it throws on unencoded spaces, '|' and other characters
 * that real-world subscription links contain in the #name part, and it returns IPv6 hosts with
 * brackets, which sing-box rejects. Pure Kotlin, no Android classes, so it is unit-testable.
 */
internal object LinkSyntax {

    data class HostPort(val host: String, val port: Int)

    /** Splits "rest#fragment" at the FIRST '#'. The fragment is percent-decoded leniently. */
    fun splitFragment(rest: String): Pair<String, String?> {
        val at = rest.indexOf('#')
        if (at < 0) return rest to null
        return rest.substring(0, at) to percentDecode(rest.substring(at + 1), lenient = true)
    }

    /** Splits "main?query" at the FIRST '?'. The query is returned raw (still encoded). */
    fun splitQuery(rest: String): Pair<String, String> {
        val at = rest.indexOf('?')
        if (at < 0) return rest to ""
        return rest.substring(0, at) to rest.substring(at + 1)
    }

    /** key=value&key=value, values percent-decoded leniently, '+' kept literal. First key wins. */
    fun parseQuery(rawQuery: String): Map<String, String> {
        val out = linkedMapOf<String, String>()
        rawQuery.split('&').filter { it.isNotBlank() }.forEach { pair ->
            val key = percentDecode(pair.substringBefore('='), lenient = true)
            val value = percentDecode(pair.substringAfter('=', ""), lenient = true)
            if (key.isNotEmpty() && key !in out) out[key] = value
        }
        return out
    }

    /**
     * Parses "host:port", "[ipv6]:port" or "ipv4:port". IPv6 is returned WITHOUT brackets.
     * Throws IllegalArgumentException with a user-facing (Arabic) message on bad input.
     */
    fun parseHostPort(hostPort: String): HostPort {
        val hp = hostPort.trim()
        val host: String
        val portText: String
        if (hp.startsWith("[")) {
            val close = hp.indexOf(']')
            require(close > 1) { "عنوان IPv6 غير صالح." }
            host = hp.substring(1, close)
            val tail = hp.substring(close + 1)
            require(tail.startsWith(":")) { "منفذ السيرفر مفقود." }
            portText = tail.substring(1)
        } else {
            val colon = hp.lastIndexOf(':')
            require(colon > 0) { "منفذ السيرفر مفقود." }
            host = hp.substring(0, colon)
            portText = hp.substring(colon + 1)
        }
        require(host.isNotBlank()) { "عنوان السيرفر مفقود." }
        require(host.none { it.isWhitespace() || it == '/' || it == '@' || it == '\\' }) { "عنوان السيرفر غير صالح." }
        val port = portText.toIntOrNull()
        require(port != null && port in 1..65535) { "منفذ السيرفر غير صالح." }
        return HostPort(host, port)
    }

    /**
     * Percent-decoding that keeps '+' literal (URLDecoder would turn it into a space, which
     * corrupts passwords, paths and Base64). With lenient=true malformed escapes ("%zz")
     * return the input unchanged instead of throwing.
     */
    fun percentDecode(value: String, lenient: Boolean = false): String {
        if (!value.contains('%')) return value
        return try {
            URLDecoder.decode(value.replace("+", "%2B"), "UTF-8")
        } catch (e: IllegalArgumentException) {
            if (lenient) value else throw e
        }
    }

    /** Removes control characters and bidi overrides so imported names cannot spoof the UI. */
    fun sanitizeLabel(value: String, maxLength: Int = 80): String {
        val cleaned = buildString {
            for (ch in value) {
                val code = ch.code
                val isControl = ch.isISOControl()
                val isBidi = code in 0x202A..0x202E || code in 0x2066..0x2069 || code == 0x200E || code == 0x200F
                if (!isControl && !isBidi) append(ch)
            }
        }.trim()
        return if (cleaned.length > maxLength) cleaned.take(maxLength) + "…" else cleaned
    }
}
