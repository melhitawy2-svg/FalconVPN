package com.falconvpn.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.falconvpn.app.vpn.engine.SecureProfileStore
import com.falconvpn.app.vpn.engine.ServiceProfiles
import com.falconvpn.app.vpn.engine.ShadowsocksLinkParser
import com.falconvpn.app.vpn.engine.VlessLinkParser
import com.falconvpn.app.vpn.platform.FalconVpnService
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private var appWebView: WebView? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4102
    private val profileStore by lazy { SecureProfileStore(applicationContext) }
    private var pendingConnectAfterPermission = false
    private var importDialog: android.app.AlertDialog? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    /** A validated link waiting for the user's explicit confirmation. Nothing is stored before that. */
    private class PendingImport(val summary: String, val save: () -> JSONObject, val insecureTls: Boolean = false)

    // The service writes its state to SharedPreferences; this listener PUSHES every change to the page,
    // so the UI no longer polls once a second.
    private val pushRunnable = Runnable { pushStatusToPage() }
    private val statusListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        uiHandler.removeCallbacks(pushRunnable)
        uiHandler.postDelayed(pushRunnable, 50L)
    }

    private val vpnPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConnectAfterPermission) {
            pendingConnectAfterPermission = false
            startVpnService()
        } else {
            pendingConnectAfterPermission = false
            saveRuntimeState(FalconVpnService.STATE_NEEDS_PERMISSION, "لم يتم منح إذن VPN؛ لم يبدأ الاتصال.")
        }
    }
    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        // The VPN consent dialog is separate. Continue the connect flow whatever the answer is:
        // without the notification permission the tunnel still works, only the status notification is hidden.
        if (!granted) {
            android.widget.Toast.makeText(this, "إذن الإشعارات مرفوض؛ قد لا يظهر إشعار حالة VPN.", android.widget.Toast.LENGTH_LONG).show()
        }
        if (pendingConnectAfterPermission) requestVpnPermissionOrStart()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // targetSdk 35 forces edge-to-edge on Android 15; opt in everywhere so behaviour is the same.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        pendingConnectAfterPermission = savedInstanceState?.getBoolean(KEY_PENDING_CONNECT, false) ?: false
        // A CONNECTED state persisted by a process that was killed is stale: clear it before the UI reads it.
        FalconVpnService.reconcileStaleState(applicationContext)

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val webView = WebView(this)
        appWebView = webView
        webView.layoutParams = android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.setBackgroundColor(0xFF020817.toInt())
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true // the bundled page keeps account/UI state in localStorage; only our own asset origin is ever loaded
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.setSupportZoom(false)
        webView.settings.mediaPlaybackRequiresUserGesture = true
        // The bridge is attached only to this WebView, which can only ever show the bundled asset page.
        webView.addJavascriptInterface(FalconNativeBridge(), "FalconNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == ASSET_HOST && (uri.path ?: "").startsWith("/assets/")) return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                }
                // Anything else (file://, content://, intent://, ...) must never replace the app page,
                // because the native bridge is attached to this WebView.
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pushStatusToPage()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                android.util.Log.d("FalconWebView", "${message.message()} -- line ${message.lineNumber()} of ${message.sourceId()}")
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                return try { startActivityForResult(intent, filePickerRequest); true }
                catch (_: Exception) { this@MainActivity.fileChooserCallback = null; false }
            }
        }
        val root = android.widget.FrameLayout(this)
        root.setBackgroundColor(0xFF020817.toInt()) // same as the page background, shows behind the bars
        root.addView(webView)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
        webView.loadUrl("https://$ASSET_HOST/assets/index.html")
        // Links/files opened from a browser or the share sheet. Only on a fresh launch: after process
        // death/recreation the same intent would otherwise be imported a second time.
        if (savedInstanceState == null) {
            handleIncomingIntent(intent)
            setIntent(Intent())
        }
        if (profileStore.consumeResetNotice()) {
            android.widget.Toast.makeText(this, "تعذر فك تشفير الكونفجات المحفوظة (تغيّرت حماية الجهاز) فتم مسحها. استورد كونفجاتك من جديد.", android.widget.Toast.LENGTH_LONG).show()
        }

        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).registerOnSharedPreferenceChangeListener(statusListener)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = appWebView
                if (wv == null) { finish(); return }
                // Let the page close a dialog / leave a tab first; only exit when it has nothing to close.
                wv.evaluateJavascript("(function(){return !!(window.falconHandleBack && window.falconHandleBack());})()") { value ->
                    if (value != "true") finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        FalconVpnService.reconcileStaleState(applicationContext)
        pushStatusToPage()
    }

    private companion object {
        const val KEY_PENDING_CONNECT = "pending_connect_after_permission"
        const val MAX_IMPORT = 100
        const val MAX_TEXT = 200_000
        const val ASSET_HOST = "appassets.androidplatform.net"
        val ALLOWED_AUTO_DISCONNECT = setOf(0, 15, 30, 60, 120)
    }

    // ---------------------------------------------------------------- status

    private fun statusJson(): JSONObject {
        val prefs = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
        val state = prefs.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED) ?: FalconVpnService.STATE_DISCONNECTED
        val message = prefs.getString(FalconVpnService.KEY_MESSAGE, "") ?: ""
        return JSONObject()
            .put("state", state)
            .put("message", message)
            .put("engineStage", prefs.getString(FalconVpnService.KEY_ENGINE_STAGE, "") ?: "")
            .put("lastError", prefs.getString(FalconVpnService.KEY_LAST_ERROR, "") ?: "")
            .put("updatedAt", prefs.getLong(FalconVpnService.KEY_UPDATED_AT, 0L))
            .put("connectedAt", prefs.getLong(FalconVpnService.KEY_CONNECTED_AT, 0L))
            .put("sessionEndsAt", prefs.getLong(FalconVpnService.KEY_SESSION_ENDS_AT, 0L))
            .put("engineRunning", FalconVpnService.engineRunning)
            .put("engineStarting", FalconVpnService.engineStarting)
            .put("now", System.currentTimeMillis())
    }

    private fun pushStatusToPage() {
        val wv = appWebView ?: return
        val json = statusJson().toString()
        wv.post { wv.evaluateJavascript("window.falconOnStatus&&window.falconOnStatus($json)", null) }
    }

    private fun selectProfileForNextConnection(id: String?): Boolean {
        if (id.isNullOrBlank()) return false
        val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
            .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
        if (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING) return false
        return runCatching { profileStore.select(id) }.getOrDefault(false)
    }

    // ---------------------------------------------------------------- bridge

    private inner class FalconNativeBridge {
        private fun fail(message: String) = JSONObject().put("ok", false).put("message", message).toString()

        /**
         * Imports every ss:// and vless:// link found in the text typed/pasted/loaded by the user in the app.
         * Also accepts a Base64-encoded subscription body. Invalid lines are reported, valid ones are stored.
         */
        @JavascriptInterface
        fun importLinks(text: String): String {
            return try {
                require(text.length <= MAX_TEXT) { "حجم النص كبير جدًا." }
                val links = extractLinks(text)
                if (links.any { Regex("(?i)(allowinsecure|insecure)=(1|true|yes)").containsMatchIn(it) }) {
                    runOnUiThread { importIncomingContent(text) }
                    return JSONObject().put("ok", true).put("imported", 0).put("message", "هذا الكونفج يحتاج تأكيد إعداد TLS؛ راجع التحذير قبل الاستيراد.").toString()
                }
                if (links.isEmpty() && text.trimStart().startsWith("{")) {
                    val jsonItems = parseSingBoxJsonImports(text)
                    require(jsonItems.isNotEmpty()) { "ملف JSON لا يحتوي على outbound مدعوم يمكن استيراده." }
                    runOnUiThread { showImportConfirmation(jsonItems, 0) }
                    return JSONObject().put("ok", true).put("imported", 0).put("message", "تم تحليل ملف JSON؛ أكّد الاستيراد من النافذة.").toString()
                }
                require(links.isNotEmpty()) { "لم أجد روابط أو ملف JSON مدعومًا. الصيغ المدعومة: VLESS وVMess وShadowsocks وTrojan وHysteria2 وsing-box JSON." }
                require(links.size <= MAX_IMPORT) { "يمكن استيراد $MAX_IMPORT رابط كحد أقصى في المرة الواحدة." }
                var imported = 0
                var firstId: String? = null
                val rejected = JSONArray()
                links.forEachIndexed { index, line ->
                    try {
                        val saved = saveLink(line)
                        imported++
                        if (firstId == null) firstId = saved.optString("id").takeIf { it.isNotBlank() }
                    } catch (e: Exception) {
                        if (rejected.length() < 10) {
                            rejected.put(JSONObject().put("line", index + 1).put("reason", e.message ?: "رابط غير صالح"))
                        }
                    }
                }
                val rejectedCount = links.size - imported
                // The newly imported profile is selected for the next connection, unless a tunnel is live.
                val first = firstId
                val selectedForNext = selectProfileForNextConnection(first)
                val message = when {
                    imported == 0 -> "لم يتم استيراد أي كونفج."
                    rejectedCount == 0 && selectedForNext -> "تم حفظ الكونفج وتحديده تلقائياً في قائمة الخدمات؛ أصبح جاهزاً لمحاولة الاتصال."
                    rejectedCount == 0 -> "تم استيراد $imported كونفج. افصل الاتصال الحالي أو اختر الكونفج يدوياً قبل الاتصال."
                    else -> "تم استيراد $imported وتجاهل $rejectedCount رابط غير صالح أو غير مدعوم."
                }
                JSONObject().put("ok", imported > 0).put("imported", imported)
                    .put("rejectedCount", rejectedCount).put("rejected", rejected)
                    .put("message", message).toString()
            } catch (e: Exception) {
                fail(e.message ?: "تعذر استيراد الروابط")
            }
        }

        /** Saves a protocol form (VMess, Trojan, Hysteria2, TUIC, WireGuard, SOCKS, HTTP Proxy, SSH, Custom JSON). */
        @JavascriptInterface
        fun saveService(service: String, fieldsJson: String): String {
            return try {
                require(fieldsJson.length <= MAX_TEXT) { "حجم النص كبير جدًا." }
                val obj = JSONObject(fieldsJson)
                val fields = obj.keys().asSequence().associateWith { obj.optString(it) }
                val profile = ServiceProfiles.fromForm(service, fields, obj.optString("__name"))
                val saved = profileStore.saveGeneric(profile)
                val id = saved.optString("id")
                val selected = selectProfileForNextConnection(id)
                JSONObject().put("ok", true).put("imported", 1)
                    .put("selected", selected)
                    .put("message", if (selected) "تم حفظ الكونفج وتحديده تلقائياً؛ أصبح جاهزاً لمحاولة الاتصال." else "تم حفظ الكونفج في الخدمات.")
                    .toString()
            } catch (e: Exception) {
                fail(e.message ?: "تعذر حفظ الاتصال")
            }
        }

        /**
         * Downloads a subscription (https only, 2 MB, 10 s) and imports every supported link in it.
         * @JavascriptInterface methods run on a background thread, so blocking here is fine.
         */
        @JavascriptInterface
        fun importSubscription(url: String): String {
            return try {
                val u = Uri.parse(url.trim())
                require(u.scheme == "https" && !u.host.isNullOrBlank()) { "رابط الاشتراك يجب أن يبدأ بـ https://" }
                val conn = java.net.URL(u.toString()).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 10_000; conn.readTimeout = 10_000
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", "FalconVPN/Android")
                val body = try {
                    require(conn.responseCode == 200) { "فشل تحميل الاشتراك (HTTP ${conn.responseCode})." }
                    conn.inputStream.use { input ->
                        val out = java.io.ByteArrayOutputStream()
                        val buf = ByteArray(8192); var total = 0
                        while (true) {
                            val n = input.read(buf); if (n < 0) break
                            total += n; require(total <= 2_000_000) { "ملف الاشتراك كبير جدًا." }
                            out.write(buf, 0, n)
                        }
                        String(out.toByteArray(), Charsets.UTF_8)
                    }
                } finally { conn.disconnect() }
                importLinks(body.take(MAX_TEXT))
            } catch (e: Exception) {
                fail(e.message ?: "تعذر تحميل الاشتراك")
            }
        }

        @JavascriptInterface
        fun pasteFromClipboard(): String {
            return try {
                val cm = getSystemService(ClipboardManager::class.java)
                val clip = cm?.primaryClip
                val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@MainActivity).toString() else ""
                JSONObject().put("ok", true).put("text", text.take(MAX_TEXT)).toString()
            } catch (e: Exception) {
                fail("تعذر قراءة الحافظة.")
            }
        }

        @JavascriptInterface
        fun listSavedProfiles(): String {
            return try {
                val selectedId = profileStore.selectedMetadata()?.optString("id").orEmpty()
                JSONObject().put("ok", true).put("profiles", profileStore.list()).put("selectedId", selectedId).toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر قراءة الكونفجات") }
        }

        @JavascriptInterface
        fun deleteSavedProfile(id: String): String {
            return try {
                // Never delete the config of a live tunnel from under the engine.
                val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                    .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
                val selectedId = profileStore.selectedMetadata()?.optString("id").orEmpty()
                if (id == selectedId && (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING)) {
                    return fail("افصل الاتصال أولًا قبل حذف الكونفج المستخدم.")
                }
                val ok = profileStore.delete(id)
                JSONObject().put("ok", ok).put("message", if (ok) "تم حذف الكونفج." else "الكونفج غير موجود.").toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر حذف الكونفج") }
        }

        @JavascriptInterface
        fun selectSavedProfile(id: String): String {
            return try {
                val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                    .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
                if (state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING) {
                    return fail("افصل الاتصال أولًا ثم اختر كونفجًا آخر.")
                }
                val selected = profileStore.select(id)
                JSONObject().put("ok", selected)
                    .put("message", if (selected) "تم تحديد الكونفج." else "الكونفج غير موجود أو تعذر تحديده.")
                    .toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر تحديد الكونفج") }
        }

        @JavascriptInterface
        fun selectedSavedProfile(): String {
            return try {
                val selected = profileStore.selectedMetadata()
                JSONObject().put("ok", true).put("profile", selected ?: JSONObject.NULL).toString()
            } catch (e: Exception) { fail(e.message ?: "تعذر قراءة الكونفج المحدد") }
        }

        @JavascriptInterface
        fun connectVpn(): String {
            FalconVpnService.reconcileStaleState(applicationContext)
            val prefs = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
            val current = prefs.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
            // Double tap / duplicate request: a start is already in flight or the tunnel is up.
            if (pendingConnectAfterPermission || current == FalconVpnService.STATE_CONNECTING || current == FalconVpnService.STATE_CONNECTED) {
                return JSONObject().put("ok", true).put("state", current ?: "CONNECTING").put("message", "الاتصال قيد التشغيل بالفعل.").toString()
            }
            val selected = runCatching { profileStore.getSelectedForEngine() }.getOrNull()
                ?: return JSONObject().put("ok", false).put("state", "ERROR").put("message", "حدد كونفجًا محفوظًا أولًا.").toString()
            if (selected.length() == 0) return fail("حدد كونفجًا محفوظًا أولًا.")
            prefs.edit().remove(FalconVpnService.KEY_LAST_ERROR)
                .putString(FalconVpnService.KEY_ENGINE_STAGE, "REQUESTED").apply()
            runOnUiThread { beginVpnPermissionFlow() }
            return JSONObject().put("ok", true).put("state", "CONNECTING").put("message", "جارٍ فحص إذن VPN وتجهيز الخدمة.").toString()
        }

        @JavascriptInterface
        fun disconnectVpn(): String {
            runOnUiThread {
                startService(Intent(this@MainActivity, FalconVpnService::class.java).setAction(FalconVpnService.ACTION_STOP))
            }
            return JSONObject().put("ok", true).put("message", "تم طلب إيقاف VPN.").toString()
        }

        @JavascriptInterface
        fun engineStatus(): String {
            FalconVpnService.reconcileStaleState(applicationContext)
            return statusJson().toString()
        }

        /** A real HTTPS request made by this app UID. With an active VPN, Android routes it through the tunnel. */
        @JavascriptInterface
        fun runConnectivityTest(): String {
            return try {
                val cm = getSystemService(android.net.ConnectivityManager::class.java)
                val active = cm.activeNetwork
                val caps = active?.let { cm.getNetworkCapabilities(it) }
                val vpnTransport = caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN) == true
                val selected = profileStore.selectedMetadata()
                val connection = (java.net.URL("https://ipinfo.io/json").openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "FalconVPN-ConnectivityCheck/0.30.2")
                }
                val body = try {
                    require(connection.responseCode == 200) { "HTTP ${connection.responseCode}" }
                    connection.inputStream.bufferedReader().use { it.readText().take(12000) }
                } finally { connection.disconnect() }
                val result = JSONObject(body)
                JSONObject().put("ok", true)
                    .put("vpnTransport", vpnTransport)
                    .put("permissionGranted", VpnService.prepare(this@MainActivity) == null)
                    .put("profileSelected", selected != null)
                    .put("ip", result.optString("ip"))
                    .put("country", result.optString("country"))
                    .put("org", result.optString("org"))
                    .put("message", if (vpnTransport) "نجح طلب HTTPS أثناء وجود شبكة VPN نشطة." else "نجح الإنترنت، لكن Android لا يعرض شبكة VPN نشطة؛ قد يكون الاتصال مباشراً.")
                    .toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false)
                    .put("vpnTransport", false)
                    .put("permissionGranted", VpnService.prepare(this@MainActivity) == null)
                    .put("profileSelected", runCatching { profileStore.selectedMetadata() != null }.getOrDefault(false))
                    .put("message", "فشل اختبار HTTPS: ${e.message ?: e.javaClass.simpleName}")
                    .toString()
            }
        }

        /**
         * Bytes the tunnel has moved over the real network, read from Android's per-UID counters
         * (this app's own sockets carry the proxied traffic). The page turns two samples into a speed.
         */
        @JavascriptInterface
        fun trafficStats(): String {
            val uid = android.os.Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)
            if (rx < 0L || tx < 0L) return fail("إحصاءات الاستهلاك غير متاحة على هذا الجهاز.")
            return JSONObject().put("ok", true).put("rx", rx).put("tx", tx).put("t", SystemClock.elapsedRealtime()).toString()
        }

        @JavascriptInterface
        fun getSettings(): String {
            val minutes = getSharedPreferences(FalconVpnService.SETTINGS_PREFS, MODE_PRIVATE)
                .getInt(FalconVpnService.KEY_AUTO_DISCONNECT_MIN, 0)
            return JSONObject().put("ok", true).put("autoDisconnectMinutes", minutes).toString()
        }

        @JavascriptInterface
        fun setAutoDisconnect(minutes: Int): String {
            if (minutes !in ALLOWED_AUTO_DISCONNECT) return fail("قيمة غير مسموحة.")
            getSharedPreferences(FalconVpnService.SETTINGS_PREFS, MODE_PRIVATE).edit()
                .putInt(FalconVpnService.KEY_AUTO_DISCONNECT_MIN, minutes).apply()
            val state = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
                .getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
            val live = state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING
            return JSONObject().put("ok", true)
                .put("message", if (live) "تم الحفظ، ويُطبَّق عند الاتصال التالي." else "تم الحفظ.")
                .toString()
        }

        @JavascriptInterface
        fun appInfo(): String {
            @Suppress("DEPRECATION")
            val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""
            return JSONObject().put("ok", true).put("version", version).put("sdk", Build.VERSION.SDK_INT).toString()
        }
    }

    // ---------------------------------------------------------------- incoming links / files

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
        setIntent(Intent()) // consumed: never re-import the same intent
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_PENDING_CONNECT, pendingConnectAfterPermission)
    }

    private fun scanLinks(text: String): List<String> {
        // Group posts often put a label or emoji before the URI on the same line.
        val pattern = Regex("(?i)(?:ss|vless|vmess|trojan|hysteria2|hy2)://[^\\s<>\"']+")
        return pattern.findAll(text).map { match ->
            match.value.trim().trimEnd(',', ';', ')', ']', '}', '.', '،')
        }.filter { ServiceProfiles.isSupportedLink(it) }.distinct().toList()
    }

    /** Parses and stores one share link of any supported scheme. Throws with a user-facing message. */
    private fun saveLink(line: String): JSONObject = when {
        line.startsWith("vless://", ignoreCase = true) -> profileStore.saveVless(VlessLinkParser.parse(line))
        line.startsWith("ss://", ignoreCase = true) -> profileStore.save(ShadowsocksLinkParser.parse(line))
        else -> profileStore.saveGeneric(ServiceProfiles.fromLink(line))
    }

    /** Links found in the text; falls back to a Base64 subscription body (the usual "sub link" format). */
    private fun extractLinks(text: String): List<String> {
        val direct = scanLinks(text)
        if (direct.isNotEmpty()) return direct
        val compact = text.filter { !it.isWhitespace() }
        if (compact.length < 16) return emptyList()
        for (flags in intArrayOf(Base64.DEFAULT, Base64.URL_SAFE)) {
            val decoded = runCatching { String(Base64.decode(compact, flags), Charsets.UTF_8) }.getOrNull() ?: continue
            val found = scanLinks(decoded)
            if (found.isNotEmpty()) return found
        }
        return emptyList()
    }

    @Suppress("DEPRECATION")
    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        if (action != Intent.ACTION_VIEW && action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return
        try {
            val raw = when (action) {
                Intent.ACTION_VIEW -> {
                    val uri = intent.data ?: return
                    if (uri.scheme.equals("content", true) || uri.scheme.equals("file", true)) {
                        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    } else uri.toString()
                }
                Intent.ACTION_SEND -> {
                    intent.getStringExtra(Intent.EXTRA_TEXT)
                        ?: intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                            ?.let { uri -> contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } }
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    val streams = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
                    streams.take(MAX_IMPORT).mapNotNull { uri ->
                        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    }.joinToString("\n")
                }
                else -> null
            } ?: return
            importIncomingContent(raw)
        } catch (e: Exception) {
            showImportMessage("تعذر قراءة الملف. تأكد أنه ملف نصي أو رابط مشاركة مدعوم.")
        }
    }

    private fun importIncomingContent(raw: String) {
        if (raw.isBlank() || raw.length > MAX_TEXT) {
            showImportMessage("الملف فارغ أو حجمه أكبر من المسموح.")
            return
        }
        // Unknown formats are rejected rather than silently converted incorrectly.
        if (raw.trimStart().startsWith("{")) {
            runCatching { parseSingBoxJsonImports(raw) }.onSuccess { items ->
                if (items.isNotEmpty()) showImportConfirmation(items, 0)
                else showImportMessage("ملف JSON لا يحتوي على outbound مدعوم.")
            }.onFailure { showImportMessage("تعذر تحليل JSON: ${it.message}") }
            return
        }
        val candidates = extractLinks(raw).take(MAX_IMPORT)
        if (candidates.isEmpty()) {
            showImportMessage("وصل الملف إلى Falcon VPN، لكن نوعه غير مدعوم بمحرك الاتصال الحالي. يدعم التطبيق روابط VLESS وVMess وShadowsocks وTrojan وHysteria2 وملفات sing-box JSON؛ صيغ OpenVPN/Psiphon تحتاج محركًا منفصلًا.")
            return
        }
        // Validate everything first, but store NOTHING until the user confirms: a link opened from any
        // other app must not be able to silently add (or select) an attacker's server.
        val pending = mutableListOf<PendingImport>()
        var rejected = 0
        var lastError: String? = null
        candidates.forEach { line ->
            try {
                if (line.startsWith("vless://", ignoreCase = true)) {
                    val p = VlessLinkParser.parse(line)
                    pending += PendingImport("VLESS • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveVless(p) }, p.allowInsecure)
                } else if (line.startsWith("ss://", ignoreCase = true)) {
                    val p = ShadowsocksLinkParser.parse(line)
                    pending += PendingImport("Shadowsocks • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.save(p) })
                } else {
                    val p = ServiceProfiles.fromLink(line)
                    pending += PendingImport("${p.protocol} • ${p.name}\n   ${displayHost(p.host)}:${p.port}", { profileStore.saveGeneric(p) }, p.singbox.optJSONObject("tls")?.optBoolean("insecure") == true)
                }
            } catch (e: Exception) {
                rejected++
                lastError = e.message
            }
        }
        if (pending.isEmpty()) {
            showImportMessage(if (candidates.size == 1 && lastError != null) "تعذر استيراد الكونفج: $lastError"
                              else "تعذر استيراد الكونفج: صيغة الرابط غير صحيحة أو غير مدعومة.")
            return
        }
        runOnUiThread { showImportConfirmation(pending, rejected) }
    }

    /** Import sing-box JSON (single outbound or a full config containing outbounds). */
    private fun parseSingBoxJsonImports(raw: String): List<PendingImport> {
        val root = JSONObject(raw)
        val outbounds = root.optJSONArray("outbounds")
        val candidates = if (outbounds != null) (0 until outbounds.length()).mapNotNull { outbounds.optJSONObject(it) }
            else listOf(root)
        val supported = setOf("vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic", "socks", "http", "ssh", "wireguard")
        return candidates.mapNotNull { outbound ->
            val type = outbound.optString("type").lowercase()
            if (type !in supported) return@mapNotNull null
            val copy = JSONObject(outbound.toString())
            val host: String
            val port: Int
            val endpoint = type == "wireguard"
            if (endpoint) {
                val peer = copy.optJSONArray("peers")?.optJSONObject(0) ?: return@mapNotNull null
                host = peer.optString("address"); port = peer.optInt("port")
            } else {
                host = copy.optString("server"); port = copy.optInt("server_port")
            }
            require(host.isNotBlank() && port in 1..65535) { "بيانات الخادم غير مكتملة في outbound من نوع $type." }
            val importedName = copy.optString("tag").ifBlank { type.uppercase() + " imported" }
            copy.remove("tag")
            val generic = com.falconvpn.app.vpn.engine.GenericProfile(
                name = importedName,
                protocol = type.uppercase(), host = host, port = port, singbox = copy, endpoint = endpoint
            )
            val insecure = copy.optJSONObject("tls")?.optBoolean("insecure") == true
            PendingImport("${type.uppercase()} • ${generic.name}\n   ${displayHost(host)}:$port", { profileStore.saveGeneric(generic) }, insecure)
        }
    }

    private fun displayHost(host: String) = if (host.contains(':')) "[$host]" else host

    private fun showImportConfirmation(items: List<PendingImport>, rejected: Int) {
        if (isFinishing || isDestroyed) return
        importDialog?.dismiss()
        val preview = items.take(5).joinToString("\n") { "• ${it.summary}" } +
            if (items.size > 5) "\n… و${items.size - 5} آخرين" else ""
        val skipped = if (rejected > 0) "\n\nتم تجاهل $rejected رابط غير صالح أو غير مدعوم." else ""
        importDialog = android.app.AlertDialog.Builder(this)
            .setTitle("استيراد ${items.size} كونفج؟")
            .setMessage("وصلت هذه الكونفجات من تطبيق أو ملف خارجي. السيرفر يرى كل حركة مرورك، فاستورد فقط ما تثق بمصدره.\n\n$preview$skipped" +
                if (items.any { it.insecureTls }) "\n\nتحذير أمني: بعض الكونفجات تطلب تعطيل التحقق من شهادة TLS (allowInsecure). هذا يسمح باحتمال اعتراض الاتصال. سيتم تطبيقه على هذه الكونفجات فقط، وليس على بقية الاتصالات." else "")
            .setPositiveButton("حفظ الكونفج") { _, _ -> commitImport(items) }
            .setNegativeButton("رجوع للقائمة") { _, _ -> returnToServicesList() }
            .setOnDismissListener { importDialog = null }
            .show()
    }

    private fun commitImport(items: List<PendingImport>) {
        var imported = 0
        var firstSavedId: String? = null
        var lastError: String? = null
        items.forEach { item ->
            try {
                val saved = item.save()
                val id = saved.optString("id").takeIf { it.isNotBlank() }
                if (firstSavedId == null) firstSavedId = id
                imported++
            } catch (e: Exception) {
                lastError = e.message ?: "تعذر حفظ أحد الكونفجات."
            }
        }

        // The newly imported profile becomes the ready-to-run selection, unless a tunnel is active.
        // Never change the selected profile underneath a live engine.
        val runtime = getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE)
        val state = runtime.getString(FalconVpnService.KEY_STATE, FalconVpnService.STATE_DISCONNECTED)
        val tunnelBusy = state == FalconVpnService.STATE_CONNECTED || state == FalconVpnService.STATE_CONNECTING
        val selected = firstSavedId
        val selectedNow = if (!tunnelBusy && selected != null) runCatching { profileStore.select(selected) }.getOrDefault(false) else false

        val message = when {
            imported == 0 -> "تعذر حفظ الكونفج${lastError?.let { ": $it" } ?: "."}"
            tunnelBusy -> "تم حفظ $imported كونفج في الخدمات. افصل الاتصال الحالي أولاً ثم اختر الكونفج الجديد."
            selectedNow -> "تم حفظ $imported كونفج وتحديد أول كونفج تلقائياً. أصبح جاهزاً لمحاولة الاتصال من قائمة الخدمات."
            else -> "تم حفظ $imported كونفج في قائمة الخدمات. اختر الكونفج المطلوب قبل الاتصال."
        }
        showImportMessage(message)
    }

    private fun returnToServicesList() {
        runOnUiThread {
            appWebView?.evaluateJavascript("window.falconReturnToServicesList && window.falconReturnToServicesList()", null)
        }
    }

    private fun showImportMessage(message: String) {
        val safe = JSONObject.quote(message)
        runOnUiThread {
            appWebView?.post {
                appWebView?.evaluateJavascript("if (window.falconImportedConfig) { window.falconImportedConfig($safe); } else { window.__falconImportNotice = $safe; }", null)
            }
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- VPN permission + start

    private fun beginVpnPermissionFlow() {
        pendingConnectAfterPermission = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestVpnPermissionOrStart()
    }

    private fun requestVpnPermissionOrStart() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            saveRuntimeState(FalconVpnService.STATE_NEEDS_PERMISSION, "مطلوب السماح لاتصال VPN من نافذة أندرويد.")
            vpnPermissionLauncher.launch(prepareIntent)
        } else if (pendingConnectAfterPermission) {
            pendingConnectAfterPermission = false
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, FalconVpnService::class.java).setAction(FalconVpnService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            saveRuntimeState(FalconVpnService.STATE_ERROR, e.message ?: "تعذر تشغيل خدمة VPN.")
        }
    }

    private fun saveRuntimeState(state: String, message: String) {
        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).edit()
            .putString(FalconVpnService.KEY_STATE, state)
            .putString(FalconVpnService.KEY_MESSAGE, message)
            .putLong(FalconVpnService.KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result = if (resultCode == Activity.RESULT_OK) {
                data?.data?.let { arrayOf(it) }
            } else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        }
    }

    override fun onDestroy() {
        getSharedPreferences(FalconVpnService.STATUS_PREFS, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(statusListener)
        uiHandler.removeCallbacks(pushRunnable)
        importDialog?.dismiss()
        importDialog = null
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        appWebView?.let { wv ->
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        appWebView = null
        super.onDestroy()
    }
}
