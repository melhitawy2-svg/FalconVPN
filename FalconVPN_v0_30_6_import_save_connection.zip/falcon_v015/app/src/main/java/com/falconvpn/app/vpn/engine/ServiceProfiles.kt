package com.falconvpn.app.vpn.engine

import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64

/**
 * A profile for every protocol sing-box can run besides Shadowsocks / VLESS (which have their own
 * parsers). [singbox] is the ready-to-use sing-box outbound (or WireGuard endpoint) with tag "proxy".
 * Pure Kotlin + org.json, so it is unit-testable on the JVM.
 */
data class GenericProfile(
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val singbox: JSONObject,
    /** true for sing-box "endpoints" (WireGuard), false for normal outbounds. */
    val endpoint: Boolean = false
)

object ServiceProfiles {
    /** Services shown in the UI that sing-box cannot run. They are rejected honestly instead of "saved". */
    val UNSUPPORTED: Map<String, String> = mapOf(
        "OpenVPN" to "OpenVPN غير مدعوم في محرك sing-box. استخدم بروتوكولًا مدعومًا (Shadowsocks / VLESS / VMess / Trojan / Hysteria2 / TUIC / WireGuard).",
        "UDP Custom" to "UDP Custom غير مدعوم في محرك sing-box.",
        "Psiphon" to "Psiphon يحتاج مكتبته الخاصة وغير مدمج في هذا التطبيق.",
        "One Cloud" to "One Cloud يحتاج مكتبته الخاصة وغير مدمج في هذا التطبيق."
    )

    val LINK_PREFIXES = listOf("ss://", "vless://", "vmess://", "trojan://", "hysteria2://", "hy2://")

    private val UUID_PATTERN = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private val CUSTOM_TYPES = setOf(
        "shadowsocks", "vless", "vmess", "trojan", "hysteria2", "tuic", "socks", "http", "ssh", "wireguard"
    )

    // ------------------------------------------------------------------ forms

    fun fromForm(service: String, fields: Map<String, String>, name: String): GenericProfile {
        UNSUPPORTED[service]?.let { throw IllegalArgumentException(it) }
        fun f(key: String) = fields[key].orEmpty().trim()
        fun secret(key: String) = fields[key].orEmpty()
        val label = LinkSyntax.sanitizeLabel(name).ifBlank { service }

        return when (service) {
            "VMess" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                val uuid = uuid(f("uuid"))
                val out = base("vmess", host, port).put("uuid", uuid).put("security", "auto")
                    .put("alter_id", f("alterId").toIntOrNull()?.coerceIn(0, 1024) ?: 0)
                if (f("tls") == "مفعّل") out.put("tls", tls(f("sni").ifBlank { host }))
                transport(formTransport(f("transport")), "", "", "")?.let { out.put("transport", it) }
                GenericProfile(label, "VMess", host, port, out)
            }
            "Trojan" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                require(secret("password").isNotEmpty()) { "كلمة مرور Trojan مفقودة." }
                val out = base("trojan", host, port).put("password", secret("password"))
                    .put("tls", tls(f("sni").ifBlank { host }))
                GenericProfile(label, "Trojan", host, port, out)
            }
            "Hysteria2" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                require(secret("password").isNotEmpty()) { "رمز Hysteria2 مفقود." }
                // The user explicitly chose "نعم" in the form; links can never turn this on.
                val out = base("hysteria2", host, port).put("password", secret("password"))
                    .put("tls", tls(f("sni").ifBlank { host }, insecure = f("insecure") == "نعم"))
                GenericProfile(label, "Hysteria2", host, port, out)
            }
            "TUIC" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                require(secret("password").isNotEmpty()) { "كلمة مرور TUIC مفقودة." }
                val out = base("tuic", host, port).put("uuid", uuid(f("uuid")))
                    .put("password", secret("password")).put("congestion_control", "bbr")
                    .put("tls", tls(f("sni").ifBlank { host }))
                GenericProfile(label, "TUIC", host, port, out)
            }
            "SOCKS", "HTTP Proxy" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                val isSocks = service == "SOCKS"
                val out = base(if (isSocks) "socks" else "http", host, port)
                if (isSocks) out.put("version", "5")
                if (f("username").isNotEmpty()) out.put("username", f("username")).put("password", secret("password"))
                GenericProfile(label, service, host, port, out)
            }
            "SSH" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                require(f("username").isNotEmpty()) { "اسم مستخدم SSH مفقود." }
                require(secret("credential").isNotEmpty()) { "بيانات مصادقة SSH مفقودة." }
                val out = base("ssh", host, port).put("user", f("username"))
                if (f("authType") == "مفتاح خاص") out.put("private_key", secret("credential"))
                else out.put("password", secret("credential"))
                GenericProfile(label, "SSH", host, port, out)
            }
            "WireGuard" -> {
                val (host, port) = endpoint(f("server"), f("port"))
                val priv = wgKey(f("privateKey"), "المفتاح الخاص")
                val pub = wgKey(f("peerKey"), "المفتاح العام للنظير")
                val addresses = f("address").split(',').map { it.trim() }.filter { it.isNotEmpty() }
                require(addresses.isNotEmpty() && addresses.all { it.contains('/') && it.none { c -> c.isWhitespace() } }) {
                    "عنوان الواجهة يجب أن يكون بصيغة CIDR مثل 10.0.0.2/32."
                }
                GenericProfile(label, "WireGuard", host, port, wireguard(host, port, priv, pub, addresses), endpoint = true)
            }
            "Custom JSON" -> customJson(f("json"), label)
            else -> throw IllegalArgumentException("نوع الاتصال غير معروف: ${LinkSyntax.sanitizeLabel(service, 30)}")
        }
    }

    private fun customJson(text: String, label: String): GenericProfile {
        val obj = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("صيغة JSON غير صحيحة.") }
        require(!obj.has("outbounds") && !obj.has("inbounds")) {
            "الصق outbound واحد فقط (يحتوي type وserver)، وليس إعداد sing-box كاملًا."
        }
        val type = obj.optString("type").lowercase()
        require(type in CUSTOM_TYPES) { "نوع outbound غير مدعوم: ${LinkSyntax.sanitizeLabel(type, 30)}" }
        obj.remove("detour"); obj.remove("domain_resolver"); obj.put("tag", "proxy")
        if (type == "wireguard") {
            val peers = obj.optJSONArray("peers")
            val peer = peers?.optJSONObject(0)
            val host = peer?.optString("address").orEmpty()
            val port = peer?.optInt("port") ?: 0
            require(host.isNotBlank() && port in 1..65535) { "بيانات النظير (peers) في WireGuard غير مكتملة." }
            obj.put("system", false)
            return GenericProfile(label, "Custom JSON", host, port, obj, endpoint = true)
        }
        val host = obj.optString("server")
        val port = obj.optInt("server_port")
        require(host.isNotBlank() && port in 1..65535) { "الحقلان server وserver_port مطلوبان." }
        return GenericProfile(label, "Custom JSON", host, port, obj)
    }

    // ------------------------------------------------------------------ links

    fun isSupportedLink(line: String): Boolean = LINK_PREFIXES.any { line.startsWith(it, ignoreCase = true) }

    /** vmess:// , trojan:// , hysteria2:// , hy2:// . (ss:// and vless:// have dedicated parsers.) */
    fun fromLink(rawLink: String): GenericProfile {
        val raw = rawLink.trim()
        val lower = raw.lowercase()
        return when {
            lower.startsWith("vmess://") -> vmessLink(raw.substring(8))
            lower.startsWith("trojan://") -> trojanLink(raw.substring(9))
            lower.startsWith("hysteria2://") -> hysteria2Link(raw.substring(12))
            lower.startsWith("hy2://") -> hysteria2Link(raw.substring(6))
            else -> throw IllegalArgumentException("نوع الرابط غير مدعوم.")
        }
    }

    private fun vmessLink(body: String): GenericProfile {
        val decoded = decodeBase64(body.substringBefore('#').trim())
            ?: throw IllegalArgumentException("رابط VMess غير صالح (Base64).")
        val j = try { JSONObject(decoded) } catch (e: Exception) { throw IllegalArgumentException("رابط VMess غير صالح (JSON).") }
        val host = j.optString("add").trim()
        val port = j.optString("port").trim().toIntOrNull() ?: 0
        val (h, p) = endpoint(host, port.toString())
        val net = j.optString("net", "tcp").lowercase().ifEmpty { "tcp" }.let { if (it == "h2") "http" else it }
        require(net in setOf("tcp", "ws", "grpc", "httpupgrade", "http")) { "نقل VMess غير مدعوم: ${LinkSyntax.sanitizeLabel(net, 20)}" }
        require(!(net == "tcp" && j.optString("type").lowercase() == "http")) { "تمويه HTTP على TCP غير مدعوم." }
        val out = base("vmess", h, p).put("uuid", uuid(j.optString("id").trim()))
            .put("security", j.optString("scy").ifBlank { "auto" })
            .put("alter_id", j.optString("aid").trim().toIntOrNull()?.coerceIn(0, 1024) ?: 0)
        if (j.optString("tls").lowercase() == "tls") {
            out.put("tls", tls(j.optString("sni").ifBlank { j.optString("host") }.ifBlank { h }, insecure = j.optBoolean("allowInsecure") || j.optBoolean("allow_insecure") || j.optString("allowInsecure").lowercase() in setOf("1", "true", "yes") || j.optString("allow_insecure").lowercase() in setOf("1", "true", "yes")))
        }
        val path = j.optString("path")
        transport(net, path, j.optString("host"), path)?.let { out.put("transport", it) }
        val name = LinkSyntax.sanitizeLabel(j.optString("ps")).ifBlank { "VMess server" }
        return GenericProfile(name, "VMess", h, p, out)
    }

    private fun trojanLink(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val q = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        val at = main.lastIndexOf('@')
        require(at > 0) { "رابط Trojan لا يحتوي على كلمة مرور." }
        val password = LinkSyntax.percentDecode(main.substring(0, at), lenient = true)
        require(password.isNotEmpty()) { "كلمة مرور Trojan مفقودة." }
        val ep = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))
        require(q["security"].orEmpty().lowercase() in setOf("", "tls")) { "Trojan يتطلب TLS." }
        val out = base("trojan", ep.host, ep.port).put("password", password)
            .put("tls", tls((q["sni"] ?: q["peer"]).orEmpty().ifBlank { ep.host }, insecure = (q["allowinsecure"] ?: q["insecure"]).orEmpty().lowercase() in setOf("1", "true", "yes")))
        val type = q["type"].orEmpty().lowercase().ifEmpty { "tcp" }.let { if (it == "h2") "http" else it }
        require(type in setOf("tcp", "ws", "grpc", "httpupgrade", "http")) { "نقل Trojan غير مدعوم: ${LinkSyntax.sanitizeLabel(type, 20)}" }
        transport(type, q["path"].orEmpty(), q["host"].orEmpty(), q["servicename"].orEmpty())?.let { out.put("transport", it) }
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "Trojan server" }
        return GenericProfile(name, "Trojan", ep.host, ep.port, out)
    }

    private fun hysteria2Link(body: String): GenericProfile {
        val (beforeFragment, fragment) = LinkSyntax.splitFragment(body)
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        val q = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        val at = main.lastIndexOf('@')
        require(at > 0) { "رابط Hysteria2 لا يحتوي على كلمة مرور." }
        val password = LinkSyntax.percentDecode(main.substring(0, at), lenient = true)
        require(password.isNotEmpty()) { "رمز Hysteria2 مفقود." }
        val ep = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))
        val out = base("hysteria2", ep.host, ep.port).put("password", password)
            .put("tls", tls(q["sni"].orEmpty().ifBlank { ep.host }, insecure = q["insecure"].orEmpty().lowercase() in setOf("1", "true", "yes")))
        val obfs = q["obfs"].orEmpty().lowercase()
        if (obfs.isNotEmpty()) {
            require(obfs == "salamander") { "obfs غير مدعوم: ${LinkSyntax.sanitizeLabel(obfs, 20)}" }
            val obfsPassword = q["obfs-password"].orEmpty()
            require(obfsPassword.isNotEmpty()) { "obfs-password مفقود." }
            out.put("obfs", JSONObject().put("type", "salamander").put("password", obfsPassword))
        }
        val name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "Hysteria2 server" }
        return GenericProfile(name, "Hysteria2", ep.host, ep.port, out)
    }

    // ------------------------------------------------------------------ helpers

    private fun base(type: String, host: String, port: Int) =
        JSONObject().put("type", type).put("tag", "proxy").put("server", host).put("server_port", port)

    private fun endpoint(host: String, portText: String): Pair<String, Int> {
        require(host.isNotBlank()) { "عنوان الخادم مفقود." }
        require(host.none { it.isWhitespace() || it == '/' || it == '@' || it == '\\' }) { "عنوان الخادم غير صالح." }
        val port = portText.trim().toIntOrNull()
        require(port != null && port in 1..65535) { "المنفذ لازم يكون رقمًا من 1 إلى 65535." }
        return host.removePrefix("[").removeSuffix("]") to port
    }

    private fun uuid(value: String): String {
        require(UUID_PATTERN.matches(value)) { "UUID غير صالح." }
        return value
    }

    private fun tls(serverName: String, insecure: Boolean = false): JSONObject {
        val t = JSONObject().put("enabled", true)
        if (serverName.isNotBlank()) t.put("server_name", serverName)
        if (insecure) t.put("insecure", true)
        return t
    }

    private fun formTransport(label: String): String = when (label) {
        "WebSocket" -> "ws"
        "gRPC" -> "grpc"
        "HTTPUpgrade" -> "httpupgrade"
        else -> "tcp"
    }

    /** Returns null for plain TCP. [serviceName] is only used by gRPC. */
    private fun transport(kind: String, path: String, host: String, serviceName: String): JSONObject? = when (kind) {
        "tcp", "" -> null
        "ws" -> JSONObject().put("type", "ws").put("path", path.ifBlank { "/" }).also {
            if (host.isNotBlank()) it.put("headers", JSONObject().put("Host", host))
        }
        "grpc" -> JSONObject().put("type", "grpc").put("service_name", serviceName)
        "httpupgrade" -> JSONObject().put("type", "httpupgrade").put("path", path.ifBlank { "/" }).also {
            if (host.isNotBlank()) it.put("host", host)
        }
        "http" -> JSONObject().put("type", "http").put("path", path.ifBlank { "/" }).also {
            if (host.isNotBlank()) it.put("host", JSONArray().put(host))
        }
        else -> throw IllegalArgumentException("نوع النقل غير مدعوم: $kind")
    }

    private fun wgKey(value: String, label: String): String {
        val bytes = try { Base64.getDecoder().decode(value) } catch (e: IllegalArgumentException) { null }
        require(bytes != null && bytes.size == 32) { "$label غير صالح (يجب أن يكون Base64 بطول 32 بايت)." }
        return value
    }

    private fun wireguard(host: String, port: Int, privateKey: String, peerKey: String, addresses: List<String>) =
        JSONObject().put("type", "wireguard").put("tag", "proxy").put("system", false)
            .put("address", JSONArray(addresses))
            .put("private_key", privateKey)
            .put("mtu", 1280)
            .put("peers", JSONArray().put(JSONObject()
                .put("address", host).put("port", port).put("public_key", peerKey)
                .put("allowed_ips", JSONArray().put("0.0.0.0/0").put("::/0"))))

    private fun decodeBase64(text: String): String? {
        val normalized = text.filterNot { it.isWhitespace() }.replace('-', '+').replace('_', '/').trimEnd('=')
        if (normalized.isEmpty()) return null
        return try {
            String(Base64.getDecoder().decode(normalized + "=".repeat((4 - normalized.length % 4) % 4)), Charsets.UTF_8)
        } catch (_: IllegalArgumentException) { null }
    }
}
