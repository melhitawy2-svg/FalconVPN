package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class ShadowsocksLinkParserTest {
    @Test fun parsesSip002Link() {
        val link = "ss://YWVzLTEyOC1nY206c2hhZG93c29ja3M=@37.19.198.236:443#%F0%9F%87%BA%F0%9F%87%B8US-37.19.198.236-0169"
        val profile = ShadowsocksLinkParser.parse(link)
        assertEquals("37.19.198.236", profile.host)
        assertEquals(443, profile.port)
        assertEquals("aes-128-gcm", profile.method)
        assertEquals("shadowsocks", profile.password)
        assertTrue(profile.name.contains("US-37.19.198.236-0169"))
        assertEquals("", profile.plugin)
    }

    @Test fun ipv6HostIsReturnedWithoutBrackets() {
        val profile = ShadowsocksLinkParser.parse("ss://YWVzLTI1Ni1nY206cGFzcw@[2001:db8::1]:8388#v6")
        assertEquals("2001:db8::1", profile.host)
        assertEquals(8388, profile.port)
        assertEquals("aes-256-gcm", profile.method)
        assertEquals("pass", profile.password)
    }

    @Test fun parsesLegacyFullyBase64Link() {
        val profile = ShadowsocksLinkParser.parse(
            "ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTpzZWNyZXRAZXhhbXBsZS5jb206ODM4OA==#Legacy Name"
        )
        assertEquals("example.com", profile.host)
        assertEquals(8388, profile.port)
        assertEquals("chacha20-ietf-poly1305", profile.method)
        assertEquals("secret", profile.password)
        assertEquals("Legacy Name", profile.name)
    }

    @Test fun unencodedSpacesAndPipeInNameDoNotBreakParsing() {
        val profile = ShadowsocksLinkParser.parse("ss://YWVzLTI1Ni1nY206cGFzcw@example.com:8388#My Server | fast 🚀")
        assertEquals("My Server | fast 🚀", profile.name)
        assertEquals("example.com", profile.host)
    }

    @Test fun plainPercentEncodedUserInfoKeepsPlusAndAt() {
        val profile = ShadowsocksLinkParser.parse("ss://aes-128-gcm:p%40ss+word@example.com:8388")
        assertEquals("p@ss+word", profile.password)
    }

    @Test fun parsesObfsPluginInsteadOfDroppingItSilently() {
        val profile = ShadowsocksLinkParser.parse(
            "ss://YWVzLTEyOC1nY206b2Jmc3B3@example.com:8388/?plugin=obfs-local%3Bobfs%3Dhttp%3Bobfs-host%3Dexample.org#n"
        )
        assertEquals("obfs-local", profile.plugin)
        assertEquals("obfs=http;obfs-host=example.org", profile.pluginOpts)
    }

    @Test fun simpleObfsIsMappedToObfsLocal() {
        val profile = ShadowsocksLinkParser.parse("ss://YWVzLTEyOC1nY206b2Jmc3B3@example.com:8388/?plugin=simple-obfs%3Bobfs%3Dtls#n")
        assertEquals("obfs-local", profile.plugin)
    }

    @Test fun unsupportedPluginIsRejectedAtImport() {
        assertThrows(IllegalArgumentException::class.java) {
            ShadowsocksLinkParser.parse("ss://YWVzLTEyOC1nY206b2Jmc3B3@example.com:8388/?plugin=kcptun%3Bkey%3D1#n")
        }
    }

    @Test fun bidiOverrideCharactersAreStrippedFromName() {
        val profile = ShadowsocksLinkParser.parse("ss://YWVzLTI1Ni1nY206cGFzcw@example.com:8388#evil%E2%80%AEname")
        assertFalse(profile.name.contains('\u202E'))
        assertEquals("evilname", profile.name)
    }

    @Test fun rejectsMalformedLinks() {
        listOf(
            "https://example.com",
            "ss://YWVzLTI1Ni1nY206cGFzcw@example.com",          // no port
            "ss://YWVzLTI1Ni1nY206cGFzcw@example.com:70000",     // port out of range
            "ss://YWVzLTI1Ni1nY206cGFzcw@example.com:abc",       // port not a number
            "ss://YWVzLTEyOC1nY206@example.com:8388",            // empty password
            "ss://@example.com:8388",                            // no credentials
            "ss://not base64 at all"
        ).forEach { link ->
            assertThrows("should reject: $link", IllegalArgumentException::class.java) { ShadowsocksLinkParser.parse(link) }
        }
    }
}
