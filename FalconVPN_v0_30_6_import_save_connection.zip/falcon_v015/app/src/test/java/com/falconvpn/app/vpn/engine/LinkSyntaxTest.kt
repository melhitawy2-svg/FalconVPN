package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class LinkSyntaxTest {
    @Test fun parsesHostPortVariants() {
        assertEquals(LinkSyntax.HostPort("example.com", 443), LinkSyntax.parseHostPort("example.com:443"))
        assertEquals(LinkSyntax.HostPort("1.2.3.4", 80), LinkSyntax.parseHostPort("1.2.3.4:80"))
        assertEquals(LinkSyntax.HostPort("::1", 8080), LinkSyntax.parseHostPort("[::1]:8080"))
    }

    @Test fun rejectsBadHostPort() {
        listOf("example.com", "example.com:0", "example.com:65536", ":443", "[::1]", "[]:443", "a b:443").forEach {
            assertThrows("should reject: $it", IllegalArgumentException::class.java) { LinkSyntax.parseHostPort(it) }
        }
    }

    @Test fun percentDecodeKeepsPlusAndToleratesBrokenEscapes() {
        assertEquals("a+b c", LinkSyntax.percentDecode("a+b%20c"))
        assertEquals("100%zz", LinkSyntax.percentDecode("100%zz", lenient = true))
        assertThrows(IllegalArgumentException::class.java) { LinkSyntax.percentDecode("100%zz") }
    }

    @Test fun fragmentIsSplitAtFirstHashOnly() {
        val (rest, fragment) = LinkSyntax.splitFragment("abc#name with # inside")
        assertEquals("abc", rest)
        assertEquals("name with # inside", fragment)
    }

    @Test fun firstQueryKeyWins() {
        assertEquals("1", LinkSyntax.parseQuery("a=1&a=2")["a"])
    }

    @Test fun sanitizeLabelRemovesControlAndBidiAndTruncates() {
        assertEquals("ab", LinkSyntax.sanitizeLabel("a\u0000\u202Eb"))
        assertEquals(81, LinkSyntax.sanitizeLabel("x".repeat(200)).length) // 80 chars + ellipsis
    }
}
