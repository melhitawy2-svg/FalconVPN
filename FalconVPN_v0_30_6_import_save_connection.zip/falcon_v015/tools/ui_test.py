"""Headless-browser logic test for the Falcon VPN design page (mock native bridge).
Run:  pip install playwright && playwright install chromium && python3 tools/ui_test.py
"""
import json, threading, http.server, socketserver, functools, os
from playwright.sync_api import sync_playwright

ASSETS=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','app','src','main','assets')
Handler=functools.partial(http.server.SimpleHTTPRequestHandler, directory=ASSETS)
Handler.log_message=lambda *a,**k: None
srv=socketserver.TCPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()

MOCK = r"""
(() => {
  const db={profiles:[],selected:'',state:'DISCONNECTED',calls:[],links:[],rx:0,tx:0,connectedAt:0,t:1000};
  window.__db=db; let id=0; const j=o=>JSON.stringify(o);
  window.FalconNative={
    importLinks(text){db.calls.push('import');db.links.push(text);
      if(text.includes('BAD'))return j({ok:false,imported:0,message:'لم يتم استيراد أي كونفج.',rejected:[{line:1,reason:'UUID في رابط VLESS غير صالح'}]});
      const proto=/^vless/i.test(text)?'VLESS':'Shadowsocks';
      db.profiles.push({id:'p'+(++id),name:decodeURIComponent(text.split('#')[1]||'srv'),host:'h.example.com',port:443,protocol:proto,security:'tls',transport:'ws',method:'aes-256-gcm'});
      db.selected=db.profiles[db.profiles.length-1].id;
      return j({ok:true,imported:1,rejectedCount:0,rejected:[],message:'تم استيراد 1 كونفج.'});},
    listSavedProfiles(){return j({ok:true,profiles:db.profiles,selectedId:db.selected});},
    selectSavedProfile(i){db.calls.push('select:'+i);if(db.state!=='DISCONNECTED')return j({ok:false,message:'افصل الاتصال أولًا ثم اختر كونفجًا آخر.'});db.selected=i;return j({ok:true});},
    selectedSavedProfile(){return j({ok:true,profile:db.profiles.find(p=>p.id===db.selected)||null});},
    connectVpn(){db.calls.push('connect');return j({ok:true,state:'CONNECTING',message:'جارٍ فحص إذن VPN.'});},
    disconnectVpn(){db.calls.push('disconnect');return j({ok:true});},
    engineStatus(){return j({state:db.state,message:'',engineRunning:db.state==='CONNECTED',engineStarting:db.state==='CONNECTING',updatedAt:0,connectedAt:db.connectedAt,sessionEndsAt:0,now:Date.now()});},
    saveService(svc,fields){db.calls.push('save:'+svc);db.saved=db.saved||[];db.saved.push([svc,JSON.parse(fields)]);db.profiles.push({id:'p'+(++id),name:JSON.parse(fields).__name||svc,host:JSON.parse(fields).server||'h',port:Number(JSON.parse(fields).port)||0,protocol:svc});db.selected=db.profiles[db.profiles.length-1].id;return j({ok:true,imported:1,message:'تم حفظ الاتصال.'});},
    importSubscription(u){db.calls.push('sub:'+u);return j({ok:true,imported:2,message:'تم استيراد 2 كونفج.'});},
    trafficStats(){db.rx+=1250000;db.tx+=250000;db.t+=1000;return j({ok:true,rx:db.rx,tx:db.tx,t:db.t});},
  };
})();
"""
fails=[]
def check(name,cond):
    print(('PASS ' if cond else 'FAIL ')+name)
    if not cond: fails.append(name)

with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':390,'height':800})
    errors=[]; pg.on('pageerror',lambda e:errors.append(str(e)))
    pg.on('dialog',lambda d:(errors.append('ALERT '+d.message),d.dismiss()))
    pg.add_init_script(MOCK)
    def _route(r):
        u=r.request.url
        if 'ipwho.is' in u: r.fulfill(status=200,content_type='application/json',body=json.dumps({'success':True,'ip':'1.2.3.4','country_code':'EG','connection':{'isp':'Vodafone'}}))
        elif u.startswith(f'http://127.0.0.1:{port}'): r.continue_()
        else: r.abort()
    pg.route('**/*',_route)
    pg.goto(f'http://127.0.0.1:{port}/index.html'); pg.wait_for_timeout(500)
    check('no JS errors on load',not errors)
    check('design present: power / map / 4-item bottom nav',pg.is_visible('#power') and pg.is_visible('#connectionMap') and pg.locator('.bottom-nav-item').count()==4)

    # --- flags design
    check('Arab flags strip: 22 flags',pg.locator('#arabCountryStrip button').count()==22)
    check('detected country (Egypt) flag lit',pg.locator('#arabCountryStrip button.active').count()==1 and pg.get_attribute('#arabCountryStrip button.active','data-code')=='EG')
    check('services box says خدمات دولة مصر','خدمات دولة' in pg.inner_text('#countryServiceState') and 'مصر' in pg.inner_text('#countryServiceState'))
    pg.click('#falconServerPickerTrigger'); pg.wait_for_timeout(200)
    check('server picker: 3 tier buttons عام/بلاس/برو, عام active',pg.locator('.falcon-main-tier').count()==3 and 'active' in pg.get_attribute('.falcon-main-tier[data-main-tier=general]','class'))
    check('server picker: country flags grid',pg.locator('#falconMainCountryGrid > *').count()>=8)
    check('server picker has no protocol buttons',pg.locator('#falconMainServerPanel .service-choice').count()==0)
    pg.click('.falcon-main-tier[data-main-tier=plus]'); pg.wait_for_timeout(150)
    check('بلاس: subscription offer replaces countries',pg.is_visible('#falconMainSubscriptionCard') and not pg.is_visible('#falconMainCountryGrid'))
    pg.click('#falconMainSubscriptionButton'); pg.wait_for_timeout(200)
    check('بلاس offer -> subscription page',pg.evaluate('document.body.classList.contains("subscription-page")'))
    pg.click('#subscriptionBack'); pg.wait_for_timeout(200); pg.click('#falconServerPickerTrigger'); pg.wait_for_timeout(200)
    pg.click('.falcon-main-tier[data-main-tier=pro]'); pg.wait_for_timeout(150)
    check('برو: subscription offer',pg.is_visible('#falconMainSubscriptionCard'))
    pg.click('.falcon-main-tier[data-main-tier=general]'); pg.click('#falconServerPickerTrigger'); pg.wait_for_timeout(150)
    # service picker: خطوط / راوتر / eSIM / أخرى -> providers
    pg.click('#falconServicePickerTrigger'); pg.wait_for_timeout(200)
    cats=pg.locator('#fspServiceGrid .fsp-service strong').all_inner_texts()
    check('service types in order: خطوط, راوتر, eSIM, أخرى',cats==['خطوط','راوتر','eSIM','أخرى'])
    pg.locator('#fspServiceGrid .fsp-service').nth(0).click()
    check('خطوط -> فودافون / اتصالات / أورنج / WE',pg.locator('#fspServiceGrid .fsp-service strong').all_inner_texts()==['خطوط فودافون','خطوط اتصالات','خطوط أورنج','خطوط WE'])
    pg.click('#fspBack'); pg.locator('#fspServiceGrid .fsp-service').nth(1).click()
    check('راوتر -> راوتر فودافون / اتصالات ...',pg.locator('#fspServiceGrid .fsp-service strong').first.inner_text()=='راوتر فودافون')
    check('back closes service picker',pg.evaluate('falconHandleBack()') is True and not pg.is_visible('#falconServicePickerModal'))

    # --- side menu: إضافة / اختيار اتصال lists the connection models
    pg.evaluate('openServiceChooser()'); pg.wait_for_timeout(200)
    names=pg.locator('#serviceChooserGrid .service-choice b').all_inner_texts()
    check('add-connection lists all models (SSH, VLESS, VMess, Shadowsocks, Trojan, OpenVPN...)',all(x in names for x in ['SSH Tunnel','VLESS','VMess','Shadowsocks','Trojan','OpenVPN','UDP Custom','Hysteria2','TUIC','WireGuard']) and pg.is_visible('#serviceChooserGrid'))
    check('add-connection shows no country flags',not pg.is_visible('#serverTierBrowser'))
    pg.click('#serviceChooserGrid .service-choice:has-text("SSH Tunnel")'); pg.wait_for_timeout(150)
    check('SSH opens its form',pg.is_visible('#servicePreviewForm') and 'SSH' in pg.inner_text('#servicePreviewTitle'))
    pg.click('.service-preview-secondary'); pg.wait_for_timeout(150)
    check('form back returns to the models list',pg.is_visible('#serviceChooserGrid') and not pg.is_visible('#servicePreviewForm'))
    pg.evaluate('closeServicePreview()')

    # --- Shadowsocks form -> importLinks
    pg.evaluate("openServiceForm('Shadowsocks')")
    check('service form opens',pg.is_visible('#servicePreviewForm'))
    pg.fill('[name=server]','ss.example.com'); pg.fill('[name=port]','8388'); pg.select_option('[name=method]','aes-256-gcm')
    pg.fill('[name=password]','p@ss:w/rd#1'); pg.fill('[name=name]','سيرفري')
    pg.click('.service-preview-primary')
    pg.wait_for_timeout(600)
    link=pg.evaluate('__db.links[0]')
    check('ss link built correctly', link=='ss://aes-256-gcm:p%40ss%3Aw%2Frd%231@ss.example.com:8388#'+__import__('urllib.parse').parse.quote('سيرفري',safe=''))
    check('saved profile listed natively',pg.is_visible('#savedConnectionProfiles') and 'سيرفري' in pg.inner_text('#savedConnectionProfileItems'))
    check('selected row marked',pg.locator('.saved-connection-profile.selected').count()==1)

    # --- VLESS form
    pg.evaluate("openServiceForm('VLESS')")
    pg.fill('[name=server]','v.example.com'); pg.fill('[name=port]','443')
    pg.fill('[name=uuid]','11111111-2222-3333-4444-555555555555'); pg.select_option('[name=transport]','WebSocket')
    pg.fill('[name=sni]','cdn.example.com'); pg.fill('[name=name]','VL')
    pg.click('.service-preview-primary'); pg.wait_for_function('__db.links.length>=2',timeout=5000); pg.wait_for_timeout(300)
    vl=pg.evaluate('__db.links[1]')
    check('vless link built correctly',vl=='vless://11111111-2222-3333-4444-555555555555@v.example.com:443?encryption=none&type=ws&security=tls&sni=cdn.example.com#VL')
    check('two profiles listed',pg.locator('.saved-connection-profile').count()==2)

    # --- rejected link surfaces the reason
    pg.evaluate("openServiceForm('Import URL')")
    pg.fill('[name=url]','vless://BAD@h:443'); pg.click('.service-preview-primary'); pg.wait_for_timeout(600)
    check('rejected import shows reason',pg.is_visible('#servicePreviewResult') and 'غير صالح' in pg.inner_text('#servicePreviewResult'))
    check('back button closes the form first',pg.evaluate('falconHandleBack()') is True)
    check('back closes modal after chooser',pg.evaluate('(()=>{let n=0;while(falconHandleBack()&&n<5)n++;return document.getElementById("servicePreviewModal").hidden})()'))

    # --- import form has separate preview / save / back actions
    pg.evaluate("document.getElementById('falconImportModal').hidden=false")
    pg.fill('#falconImportText','vless://11111111-2222-3333-4444-555555555555@import.example.com:443?security=tls&type=ws#Imported')
    calls_before=pg.evaluate("__db.calls.filter(x=>x==='import').length")
    pg.click('#falconImportAnalyze'); pg.wait_for_timeout(80)
    check('import preview does not save by itself',pg.evaluate("__db.calls.filter(x=>x==='import').length")==calls_before)
    check('import form exposes save and back actions',pg.is_visible('#falconImportSave') and pg.is_visible('#falconImportBack'))
    pg.click('#falconImportSave'); pg.wait_for_timeout(200)
    check('save action imports and refreshes services list',pg.evaluate("__db.calls.filter(x=>x==='import').length")==calls_before+1 and pg.is_visible('#savedConnectionProfiles'))
    pg.evaluate("document.getElementById('falconImportModal').hidden=false")
    pg.click('#falconImportBack'); pg.wait_for_timeout(80)
    check('back from import returns to service chooser',pg.is_visible('#serviceChooserGrid'))
    pg.evaluate('closeServicePreview()')

    # --- choose second profile natively
    pg.locator('.saved-connection-profile').nth(1).click()
    check('select goes to native',"select:p2" in pg.evaluate('__db.calls'))

    # --- power button starts the native connection directly (no unfinished ad gate)
    pg.click('#power'); pg.wait_for_timeout(100)
    check('power starts connection directly','connect' in pg.evaluate('__db.calls'))
    check('power click does not open unfinished ad gate',not pg.is_visible('#falconAdGate'))

    # --- status push + real timer + real throughput
    pg.evaluate('__db.state="CONNECTED";__db.connectedAt=Date.now()-65000;falconOnStatus()'); pg.wait_for_timeout(2600)
    check('status = متصل',pg.inner_text('#status').strip()=='متصل')
    check('timer shows uptime 00:01:0x',pg.inner_text('#timer').startswith('00:01:'))
    check('real speeds shown (Mbps)','Mbps' in pg.inner_text('#down') and 'Mbps' in pg.inner_text('#up'))
    check('map speed no longer fake 12.6',pg.inner_text('#mapSpeed').strip()!='12.6 Mbps')
    pg.click('#power'); check('power while connected -> disconnect','disconnect' in pg.evaluate('__db.calls'))
    pg.evaluate('__db.state="DISCONNECTED";__db.connectedAt=0;falconOnStatus()'); pg.wait_for_timeout(300)
    check('disconnected resets',pg.inner_text('#status').strip()=='غير متصل' and pg.inner_text('#down').strip()=='—' and pg.inner_text('#timer')=='00:00:00')

    # --- back button
    pg.click('.bottom-nav-item[data-destination="account"]')
    check('back leaves account page -> home',pg.evaluate('falconHandleBack()') is True and pg.evaluate('!document.body.classList.contains("account-page")'))
    check('back at home -> exit',pg.evaluate('falconHandleBack()') is False)

    # --- every protocol form reaches the native side; unsupported ones are refused honestly
    def fill_and_submit(service, values):
        pg.evaluate(f"openServiceForm('{service}')")
        for k,v in values.items():
            pg.evaluate("([k,v])=>{const el=document.querySelector('#servicePreviewForm [name=\"'+k+'\"]');el.value=v;}",[k,v])
        pg.evaluate("document.getElementById('servicePreviewForm').requestSubmit()"); pg.wait_for_timeout(150)
    for svc,vals in [('VMess',{'server':'v.example.com','port':'443','uuid':'11111111-2222-3333-4444-555555555555','name':'vm'}),
                     ('Trojan',{'server':'t.example.com','port':'443','password':'pw','name':'tr'}),
                     ('Hysteria2',{'server':'h.example.com','port':'443','password':'pw','name':'hy'}),
                     ('TUIC',{'server':'u.example.com','port':'443','uuid':'11111111-2222-3333-4444-555555555555','password':'pw','name':'tu'}),
                     ('SOCKS',{'server':'s.example.com','port':'1080','name':'so'}),
                     ('HTTP Proxy',{'server':'p.example.com','port':'8080','name':'ht'}),
                     ('SSH',{'server':'ssh.example.com','port':'22','username':'u','credential':'pw','name':'sh'})]:
        before=pg.evaluate("(window.__db.saved||[]).length")
        fill_and_submit(svc,vals)
        check(f'{svc} form -> native saveService',pg.evaluate("(window.__db.saved||[]).length")==before+1 and pg.evaluate("window.__db.saved.slice(-1)[0][0]")==svc)
    pg.evaluate("openServiceForm('SOCKS')")
    check('SOCKS form is no longer empty',pg.locator('#servicePreviewFields input').count()>=3)
    pg.evaluate("closeServicePreview()")
    pg.evaluate("openServiceForm('OpenVPN')")
    pg.fill('#servicePreviewForm textarea','client\nremote x 1194')
    pg.evaluate("document.getElementById('servicePreviewForm').requestSubmit()"); pg.wait_for_timeout(150)
    check('OpenVPN refused with a clear message (not silently "saved")','غير مدعوم' in pg.inner_text('#servicePreviewResult'))
    pg.evaluate("closeServicePreview()")
    pg.evaluate("openServiceForm('Import URL')")
    pg.fill('#servicePreviewForm input[name=url]','https://example.com/sub')
    pg.evaluate("document.getElementById('servicePreviewForm').requestSubmit()"); pg.wait_for_timeout(150)
    check('https subscription -> native importSubscription',pg.evaluate("window.__db.calls.some(c=>c.startsWith('sub:https://example.com/sub'))"))
    check('no JS errors / alerts overall',not errors)
    if errors: print(errors)
    pg.screenshot(path='/tmp/home.png')
    b.close()

print('\nFAILED: '+', '.join(fails) if fails else '\nALL PASSED'); raise SystemExit(1 if fails else 0)
