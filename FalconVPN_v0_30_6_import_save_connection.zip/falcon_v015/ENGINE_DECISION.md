# Engine decision — Falcon VPN

Engine: sing-box `libbox` **1.13.14**, supplied as `app/libs/libbox.aar` (see `docs/BUILD_LIBBOX.md`).
It is NOT resolved from Maven/JitPack by Gradle; CI downloads it and checks a pinned SHA-256.

Protocols run natively: Shadowsocks, VLESS (incl. Reality), VMess, Trojan, Hysteria2, TUIC, WireGuard (endpoint),
SOCKS5, HTTP proxy, SSH (TCP only) and a single user-supplied outbound ("Custom JSON").
Not runnable by sing-box and therefore refused with a message: OpenVPN, UDP Custom, Psiphon, One Cloud.

License: sing-box is GPL-3.0-or-later; decide on source-offer obligations before distributing.
