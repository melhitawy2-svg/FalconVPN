/* Pantegnos AGPL-3.0 WebAssembly bridge. Decryption runs locally; file bytes are never uploaded. */
(function () {
  'use strict';
  let corePromise;
  function startCore() {
    if (corePromise) return corePromise;
    corePromise = (async function () {
      if (typeof Go !== 'function') throw new Error('ملفات تشغيل WASM غير موجودة.');
      const go = new Go();
      const response = await fetch('pantegnos.wasm');
      if (!response.ok) throw new Error('تعذر تحميل محرك فك الملفات (' + response.status + ').');
      const bytes = await response.arrayBuffer();
      const result = await WebAssembly.instantiate(bytes, go.importObject);
      // cmd/wasm registers pantegnosDecrypt synchronously during startup and then stays alive.
      go.run(result.instance).catch(function (e) { console.error('Pantegnos runtime:', e); });
      for (let i = 0; i < 100; i++) {
        if (typeof globalThis.pantegnosDecrypt === 'function') return true;
        await new Promise(resolve => setTimeout(resolve, 20));
      }
      throw new Error('محرك فك الملفات لم يكتمل تشغيله.');
    })();
    return corePromise;
  }

  globalThis.falconDecryptImportedFile = async function (fileName, base64Data) {
    try {
      await startCore();
      const binary = atob(base64Data);
      const data = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) data[i] = binary.charCodeAt(i);
      const result = globalThis.pantegnosDecrypt(String(fileName || 'config.bin'), data, '');
      if (!result || !result.ok) throw new Error(result && result.error ? result.error : 'صيغة الملف غير مدعومة.');
      if (globalThis.FalconNative && typeof FalconNative.onPantegnosDecrypted === 'function') {
        FalconNative.onPantegnosDecrypted(String(fileName || ''), String(result.text || ''), '');
      }
    } catch (error) {
      if (globalThis.FalconNative && typeof FalconNative.onPantegnosDecrypted === 'function') {
        FalconNative.onPantegnosDecrypted(String(fileName || ''), '', String(error && error.message || error));
      }
    }
  };
})();
