plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ABIs packaged in the APK. libbox.aar must contain the same ABIs. For an x86_64 emulator build:
//   gradle assembleDebug -PfalconAbis=arm64-v8a,x86_64
val falconAbis: List<String> = (project.findProperty("falconAbis") as String? ?: "arm64-v8a")
    .split(',').map { it.trim() }.filter { it.isNotEmpty() }

android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    namespace = "com.falconvpn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.falconvpn.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 47
        versionName = "0.30.7"
        ndk { abiFilters += falconAbis }
    }
}

dependencies {
    // sing-box libbox AAR, placed in app/libs/libbox.aar (see docs/BUILD_LIBBOX.md and the CI workflows).
    implementation(files("libs/libbox.aar"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    // Serves assets from https://appassets.androidplatform.net/ (secure origin, no file:// access needed).
    implementation("androidx.webkit:webkit:1.12.1")
    testImplementation("junit:junit:4.13.2")
    // Android's org.json is only a stub on the JVM; tests need the real implementation.
    testImplementation("org.json:json:20240303")
}
