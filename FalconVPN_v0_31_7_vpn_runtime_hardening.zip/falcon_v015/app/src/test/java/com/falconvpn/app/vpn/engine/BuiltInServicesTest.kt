package com.falconvpn.app.vpn.engine

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BuiltInServicesTest {
    @Test fun parsesEntriesAndSkipsIncompleteOnes() {
        val list = BuiltInServices.parse("""{"services":[
            {"label":"A","link":"vless://x","category":"router","provider":"WE","description":"d"},
            {"label":"","link":"vless://y"},
            {"label":"B"}]}""")
        assertEquals(1, list.size)
        assertEquals("router", list[0].category)
        assertEquals("WE", list[0].provider)
    }

    @Test fun findMatchesTheTrimmedLabel() {
        val list = listOf(BuiltInService("رفع سرعة راوتر WE", "vless://x"))
        assertNotNull(BuiltInServices.find(list, " رفع سرعة راوتر WE "))
        assertNull(BuiltInServices.find(list, "خدمات فودافون"))
    }

    /** The shipped asset must stay importable: a typo here would only show up on a device otherwise. */
    @Test fun shippedAssetParsesAsAVlessWebsocketTlsProfile() {
        val text = File("src/main/assets/builtin_services.json").readText(Charsets.UTF_8)
        val we = BuiltInServices.find(BuiltInServices.parse(text), "رفع سرعة راوتر WE")
        assertNotNull(we)
        val p = VlessLinkParser.parse(we!!.link)
        assertEquals("ws", p.transport)
        assertEquals("tls", p.security)
        assertEquals("/realtime", p.path)
        assertEquals("scorm.ekb.eg", p.sni)
        assertTrue(p.allowInsecure)
    }
}
