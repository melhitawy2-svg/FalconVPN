package com.falconvpn.app.vpn.engine

import org.json.JSONObject

/** A service of the free-internet picker that ships with a ready config (assets/builtin_services.json). */
data class BuiltInService(
    val label: String,
    val link: String,
    /** Picker category: "router", "lines", "esim" or "other". */
    val category: String = "",
    /** Provider as the picker names it without the category prefix, e.g. "WE". */
    val provider: String = "",
    val description: String = ""
)

/** Pure Kotlin + org.json, so it is unit-testable on the JVM. */
object BuiltInServices {
    fun parse(json: String): List<BuiltInService> {
        val array = JSONObject(json).optJSONArray("services") ?: return emptyList()
        return (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val label = item.optString("label").trim()
            val link = item.optString("link").trim()
            if (label.isEmpty() || link.isEmpty()) null else BuiltInService(
                label, link,
                category = item.optString("category").trim(),
                provider = item.optString("provider").trim(),
                description = item.optString("description").trim()
            )
        }
    }

    fun find(services: List<BuiltInService>, label: String): BuiltInService? =
        services.firstOrNull { it.label == label.trim() }
}
