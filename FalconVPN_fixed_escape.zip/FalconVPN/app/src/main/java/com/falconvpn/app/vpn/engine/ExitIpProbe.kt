package com.falconvpn.app.vpn.engine

/**
 * Public-IP probe used to prove that traffic really leaves through the tunnel.
 * Pure Kotlin so the parsing is unit-tested on the JVM.
 */
object ExitIpProbe {
    /** Independent hosts: one blocked or down host must not make a working tunnel look dead. */
    val ENDPOINTS: List<String> = listOf(
        "https://www.cloudflare.com/cdn-cgi/trace",
        "https://api.ipify.org",
        "https://checkip.amazonaws.com",
        "https://icanhazip.com"
    )
    const val MAX_BODY_BYTES = 2048
    private val IP_CHARS = Regex("^[0-9a-fA-F:.]{3,45}$")

    /** Accepts a bare IP ("1.2.3.4\n") or Cloudflare's key=value trace (a line "ip=1.2.3.4"). Null for anything else. */
    fun parse(body: String): String? {
        val text = body.trim()
        if (text.isEmpty()) return null
        val traceLine = text.lineSequence().map { it.trim() }.firstOrNull { it.startsWith("ip=") }
        if (traceLine != null) return traceLine.removePrefix("ip=").trim().takeIf { isIp(it) }
        return text.takeIf { isIp(it) }
    }

    private fun isIp(value: String): Boolean {
        if (!IP_CHARS.matches(value)) return false
        if (':' in value) return value.count { it == ':' } >= 2 // IPv6, loosely
        val parts = value.split('.')
        return parts.size == 4 && parts.all { p -> p.toIntOrNull()?.let { it in 0..255 } == true }
    }
}
