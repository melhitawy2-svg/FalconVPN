package com.falconvpn.app.vpn.engine

import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the sing-box JSON configuration for a stored profile.
 *
 * The result is returned as a String and handed to libbox in memory: the proxy password / UUID is
 * never written to disk. Needs no Android Context, so it can be unit-tested on the JVM.
 * Never log the returned string.
 */
object SingBoxConfig {
    /** Conservative tunnel MTU; the libbox default is too large for many mobile / tunnelled paths. */
    const val TUN_MTU = 1400

    /**
     * @param bootstrapDns DNS server of the PHYSICAL network (IPv4), used only to resolve the proxy server's
     *   own hostname. Carrier-restricted networks (e.g. a walled garden after the quota ends) often block
     *   public DNS such as 1.1.1.1 but always answer their own resolver. Null falls back to 1.1.1.1.
     * @param stack sing-box TUN stack. "mixed" needs a libbox built with gVisor; the service retries with
     *   "system" when the engine reports that gVisor is missing.
     */
    fun build(profile: JSONObject, bootstrapDns: String? = null, stack: String = "mixed"): String {
        val host = profile.optString("host")
        val port = profile.optInt("port")
        require(host.isNotBlank() && port in 1..65535) { "بيانات السيرفر المحدد غير مكتملة." }

        // Profiles of the generic protocols carry a ready sing-box outbound (or WireGuard endpoint).
        val generic = profile.optString("singbox").takeIf { it.isNotBlank() }?.let { JSONObject(it).put("tag", "proxy") }
        val isEndpoint = generic != null && profile.optBoolean("endpoint")
        val outbound: JSONObject? = when {
            generic != null -> if (isEndpoint) null else generic
            profile.optString("protocol", "Shadowsocks").lowercase() == "vless" -> vlessOutbound(profile, host, port)
            else -> shadowsocksOutbound(profile, host, port)
        }
        val direct = JSONObject().put("type", "direct").put("tag", "direct")

        // dns-direct resolves the proxy server's own hostname outside the tunnel (bootstrap).
        // dns-remote is DNS-over-HTTPS carried through the proxy, so lookups are encrypted and
        // do not depend on the proxy server supporting UDP.
        val dnsDirect = JSONObject()
            .put("type", "udp").put("tag", "dns-direct")
            .put("server", bootstrapDns?.takeIf { it.isNotBlank() } ?: "1.1.1.1").put("server_port", 53)
        // Use Cloudflare's certificate hostname explicitly. Connecting to the DoH service by
        // numeric IP without a TLS server_name can fail certificate verification on some builds.
        // Resolve the DoH hostname through the physical/bootstrap resolver, but carry the actual
        // DoH request through the proxy to avoid sending user DNS queries directly.
        val dnsRemote = JSONObject()
            .put("type", "https").put("tag", "dns-remote")
            .put("server", "cloudflare-dns.com")
            .put("server_port", 443)
            .put("path", "/dns-query")
            .put("tls", JSONObject().put("enabled", true).put("server_name", "cloudflare-dns.com"))
            .put("domain_resolver", "dns-direct")
            .put("detour", "proxy")

        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", TUN_MTU)
            .put("auto_route", true)
            .put("strict_route", false)
            .put("stack", stack)

        val rules = JSONArray()
            .put(JSONObject().put("action", "sniff"))
            .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
            // Local network (printers, router, casting) must not be sent through the proxy.
            .put(JSONObject().put("ip_is_private", true).put("action", "route").put("outbound", "direct"))

        val outbounds = JSONArray()
        outbound?.let { outbounds.put(it) }
        outbounds.put(direct)
        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", JSONObject()
                .put("servers", JSONArray().put(dnsRemote).put(dnsDirect))
                .put("final", "dns-remote"))
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject()
                .put("final", "proxy")
                .put("auto_detect_interface", true)
                .put("default_domain_resolver", "dns-direct")
                .put("rules", rules))
        if (isEndpoint) root.put("endpoints", JSONArray().put(generic))
        return root.toString()
    }

    private fun shadowsocksOutbound(profile: JSONObject, host: String, port: Int): JSONObject {
        val method = profile.optString("method")
        val password = profile.optString("password")
        require(method.isNotBlank() && password.isNotEmpty()) { "بيانات Shadowsocks غير مكتملة." }
        val item = JSONObject()
            .put("type", "shadowsocks").put("tag", "proxy")
            .put("server", profile.optString("resolved_ip").ifBlank { host }).put("server_port", port)
            .put("method", method).put("password", password)
        profile.optString("plugin").takeIf { it.isNotBlank() }?.let { plugin ->
            item.put("plugin", plugin)
            profile.optString("plugin_opts").takeIf { it.isNotBlank() }?.let { item.put("plugin_opts", it) }
        }
        return item
    }

    private fun vlessOutbound(profile: JSONObject, host: String, port: Int): JSONObject {
        val uuid = profile.optString("uuid")
        require(uuid.isNotBlank()) { "UUID الخاص بكونفج VLESS غير موجود." }
        // When the service resolved the hostname on the physical network, the dial address is an IP. The
        // name the server expects (TLS SNI and the HTTP Host header) must then be kept explicitly.
        val resolvedIp = profile.optString("resolved_ip")
        val item = JSONObject()
            .put("type", "vless").put("tag", "proxy")
            .put("server", resolvedIp.ifBlank { host }).put("server_port", port)
            .put("uuid", uuid)
        profile.optString("flow").takeIf { it.isNotBlank() }?.let { item.put("flow", it) }

        val security = profile.optString("security", "none").lowercase()
        val fingerprint = profile.optString("fp")
        when (security) {
            "tls", "reality" -> {
                val tls = JSONObject().put("enabled", true)
                if (profile.optBoolean("allow_insecure")) tls.put("insecure", true)
                val serverName = profile.optString("sni").ifBlank { if (resolvedIp.isNotBlank()) host else "" }
                if (serverName.isNotBlank()) tls.put("server_name", serverName)
                val transportKind = profile.optString("transport", "tcp").lowercase()
                val alpn = profile.optString("alpn").split(',').map { it.trim() }.filter { it.isNotEmpty() }
                    // WebSocket / HTTPUpgrade ride on HTTP/1.1. A uTLS ClientHello advertises h2 first, and a
                    // server that picks h2 then rejects the upgrade, so pin http/1.1 unless the link says otherwise.
                    .ifEmpty { if (transportKind == "ws" || transportKind == "httpupgrade") listOf("http/1.1") else emptyList<String>() }
                if (alpn.isNotEmpty()) tls.put("alpn", JSONArray(alpn))
                if (security == "reality") {
                    val publicKey = profile.optString("pbk")
                    require(publicKey.isNotBlank()) { "كونفج Reality لا يحتوي على المفتاح العام (pbk)." }
                    tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint.ifBlank { "chrome" }))
                    tls.put("reality", JSONObject()
                        .put("enabled", true)
                        .put("public_key", publicKey)
                        .put("short_id", profile.optString("sid")))
                } else if (fingerprint.isNotBlank()) {
                    tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint))
                }
                item.put("tls", tls)
            }
            "none" -> Unit
            else -> error("نوع الحماية غير مدعوم: $security")
        }

        val path = profile.optString("path")
        val hostHeader = profile.optString("ws_host").ifBlank { if (resolvedIp.isNotBlank()) host else "" }
        when (val transport = profile.optString("transport", "tcp").lowercase()) {
            "tcp", "" -> Unit
            "ws" -> {
                val ws = JSONObject().put("type", "ws")
                path.takeIf { it.isNotBlank() }?.let { ws.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { ws.put("headers", JSONObject().put("Host", it)) }
                item.put("transport", ws)
            }
            "grpc" -> item.put("transport", JSONObject()
                .put("type", "grpc").put("service_name", profile.optString("service_name")))
            "httpupgrade" -> {
                val t = JSONObject().put("type", "httpupgrade")
                path.takeIf { it.isNotBlank() }?.let { t.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { t.put("host", it) }
                item.put("transport", t)
            }
            "http" -> {
                val t = JSONObject().put("type", "http")
                path.takeIf { it.isNotBlank() }?.let { t.put("path", it) }
                hostHeader.takeIf { it.isNotBlank() }?.let { t.put("host", JSONArray().put(it)) }
                item.put("transport", t)
            }
            else -> error("نقل VLESS من نوع $transport غير مدعوم.")
        }
        return item
    }
}
