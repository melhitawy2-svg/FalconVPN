package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExitIpProbeTest {
    @Test fun bareIpv4() = assertEquals("203.0.113.7", ExitIpProbe.parse("203.0.113.7\n"))
    @Test fun cloudflareTrace() =
        assertEquals("203.0.113.7", ExitIpProbe.parse("fl=1\nh=www.cloudflare.com\nip=203.0.113.7\nts=1\nvisit_scheme=https\n"))
    @Test fun ipv6() = assertEquals("2606:4700::1111", ExitIpProbe.parse("2606:4700::1111"))
    @Test fun htmlErrorPageIsRejected() = assertNull(ExitIpProbe.parse("<html><body>Blocked</body></html>"))
    @Test fun outOfRangeOctetIsRejected() = assertNull(ExitIpProbe.parse("999.1.1.1"))
    @Test fun emptyIsRejected() = assertNull(ExitIpProbe.parse("  \n"))
    @Test fun traceWithBadIpIsRejected() = assertNull(ExitIpProbe.parse("ip=not-an-ip\n"))
    @Test fun severalIndependentHosts() = assertTrue(ExitIpProbe.ENDPOINTS.size >= 3 && ExitIpProbe.ENDPOINTS.all { it.startsWith("https://") })
}
