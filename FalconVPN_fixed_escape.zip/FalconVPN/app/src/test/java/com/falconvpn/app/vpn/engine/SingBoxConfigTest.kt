package com.falconvpn.app.vpn.engine

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class SingBoxConfigTest {
    private fun ss(extra: JSONObject.() -> Unit = {}) = JSONObject()
        .put("protocol", "Shadowsocks").put("host", "example.com").put("port", 8388)
        .put("method", "aes-256-gcm").put("password", "pw").apply(extra)

    private fun vless(extra: JSONObject.() -> Unit = {}) = JSONObject()
        .put("protocol", "VLESS").put("host", "example.com").put("port", 443)
        .put("uuid", "11111111-2222-3333-4444-555555555555").apply(extra)

    private fun outbound(config: String) = JSONObject(config).getJSONArray("outbounds").getJSONObject(0)

    @Test fun commonSettingsAreApplied() {
        val root = JSONObject(SingBoxConfig.build(ss()))
        val tun = root.getJSONArray("inbounds").getJSONObject(0)
        assertEquals(SingBoxConfig.TUN_MTU, tun.getInt("mtu"))
        assertFalse("legacy inet4_address must not be used", tun.has("inet4_address"))
        val rules = root.getJSONObject("route").getJSONArray("rules")
        val hasPrivateDirect = (0 until rules.length()).map { rules.getJSONObject(it) }
            .any { it.optBoolean("ip_is_private") && it.optString("outbound") == "direct" }
        assertTrue("LAN must bypass the proxy", hasPrivateDirect)
        val privateRule = (0 until rules.length()).map { rules.getJSONObject(it) }
            .first { it.optBoolean("ip_is_private") }
        assertEquals("route", privateRule.getString("action"))
        assertEquals("direct", privateRule.getString("outbound"))
        val dnsRemote = root.getJSONObject("dns").getJSONArray("servers").getJSONObject(0)
        assertEquals("https", dnsRemote.getString("type"))
        assertEquals("cloudflare-dns.com", dnsRemote.getString("server"))
        assertEquals("proxy", dnsRemote.getString("detour"))
        assertEquals("dns-direct", dnsRemote.getString("domain_resolver"))
        assertEquals("cloudflare-dns.com", dnsRemote.getJSONObject("tls").getString("server_name"))
    }

    @Test fun shadowsocksWithPlugin() {
        val o = outbound(SingBoxConfig.build(ss { put("plugin", "obfs-local").put("plugin_opts", "obfs=http;obfs-host=a.com") }))
        assertEquals("shadowsocks", o.getString("type"))
        assertEquals("obfs-local", o.getString("plugin"))
        assertEquals("obfs=http;obfs-host=a.com", o.getString("plugin_opts"))
    }

    @Test fun shadowsocksWithoutPluginHasNoPluginKeys() {
        assertFalse(outbound(SingBoxConfig.build(ss())).has("plugin"))
    }

    @Test fun vlessReality() {
        val o = outbound(SingBoxConfig.build(vless {
            put("security", "reality").put("sni", "www.microsoft.com").put("pbk", "PUB").put("sid", "abcd")
                .put("flow", "xtls-rprx-vision")
        }))
        assertEquals("xtls-rprx-vision", o.getString("flow"))
        val tls = o.getJSONObject("tls")
        assertEquals("www.microsoft.com", tls.getString("server_name"))
        assertEquals("chrome", tls.getJSONObject("utls").getString("fingerprint")) // default for Reality
        val reality = tls.getJSONObject("reality")
        assertTrue(reality.getBoolean("enabled"))
        assertEquals("PUB", reality.getString("public_key"))
        assertEquals("abcd", reality.getString("short_id"))
    }

    @Test fun vlessRealityWithoutPublicKeyFails() {
        assertThrows(IllegalArgumentException::class.java) { SingBoxConfig.build(vless { put("security", "reality") }) }
    }

    @Test fun vlessTlsWebSocketWithAlpnAndFingerprint() {
        val o = outbound(SingBoxConfig.build(vless {
            put("security", "tls").put("sni", "a.com").put("alpn", "h2,http/1.1").put("fp", "firefox")
                .put("transport", "ws").put("path", "/ws").put("ws_host", "cdn.a.com")
        }))
        val tls = o.getJSONObject("tls")
        assertEquals(2, tls.getJSONArray("alpn").length())
        assertEquals("firefox", tls.getJSONObject("utls").getString("fingerprint"))
        val ws = o.getJSONObject("transport")
        assertEquals("ws", ws.getString("type"))
        assertEquals("/ws", ws.getString("path"))
        assertEquals("cdn.a.com", ws.getJSONObject("headers").getString("Host"))
    }

    @Test fun vlessGrpcAndHttpUpgrade() {
        val grpc = outbound(SingBoxConfig.build(vless { put("security", "tls").put("transport", "grpc").put("service_name", "svc") }))
        assertEquals("grpc", grpc.getJSONObject("transport").getString("type"))
        assertEquals("svc", grpc.getJSONObject("transport").getString("service_name"))

        val hu = outbound(SingBoxConfig.build(vless { put("transport", "httpupgrade").put("path", "/u").put("ws_host", "h.com") }))
        assertEquals("httpupgrade", hu.getJSONObject("transport").getString("type"))
        assertEquals("h.com", hu.getJSONObject("transport").getString("host"))
    }


    @Test fun vlessTlsCanPreserveExplicitPerProfileInsecureFlag() {
        val tls = outbound(SingBoxConfig.build(vless {
            put("security", "tls").put("allow_insecure", true)
        })).getJSONObject("tls")
        assertTrue(tls.getBoolean("insecure"))
    }

    @Test fun incompleteProfilesAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { SingBoxConfig.build(JSONObject().put("host", "").put("port", 1)) }
        assertThrows(IllegalArgumentException::class.java) { SingBoxConfig.build(ss { put("password", "") }) }
        assertThrows(IllegalArgumentException::class.java) { SingBoxConfig.build(vless { put("uuid", "") }) }
    }

    // ---- the WE router-speed config (VLESS + WebSocket + TLS with a fronting SNI and a self-signed server)

    private val weLink = "vless://7e364b66-3d3d-40c4-8721-f4dad203c7e2@uk5.taskflowhub.org:8443" +
        "?path=%2Frealtime&security=tls&encryption=none&insecure=1&host=scorm.ekb.eg&fp=ios&type=ws" +
        "&allowInsecure=1&sni=scorm.ekb.eg#test999"

    /** Same field mapping SecureProfileStore.vlessToJson uses. */
    private fun storedVless(p: VlessProfile) = JSONObject()
        .put("protocol", "VLESS").put("host", p.host).put("port", p.port).put("uuid", p.uuid)
        .put("security", p.security).put("sni", p.sni).put("transport", p.transport).put("path", p.path)
        .put("ws_host", p.wsHost).put("flow", p.flow).put("fp", p.fingerprint)
        .put("alpn", p.alpn.joinToString(",")).put("allow_insecure", p.allowInsecure)

    @Test fun weRouterProfileBuildsTheOutboundOtherClientsUse() {
        val out = outbound(SingBoxConfig.build(storedVless(VlessLinkParser.parse(weLink))))
        assertEquals("uk5.taskflowhub.org", out.getString("server"))
        assertEquals(8443, out.getInt("server_port"))
        val tls = out.getJSONObject("tls")
        assertTrue(tls.getBoolean("enabled"))
        assertTrue("the link says insecure=1", tls.getBoolean("insecure"))
        assertEquals("scorm.ekb.eg", tls.getString("server_name"))
        assertEquals("ios", tls.getJSONObject("utls").getString("fingerprint"))
        assertEquals("http/1.1", tls.getJSONArray("alpn").getString(0))
        val ws = out.getJSONObject("transport")
        assertEquals("ws", ws.getString("type"))
        assertEquals("/realtime", ws.getString("path"))
        assertEquals("scorm.ekb.eg", ws.getJSONObject("headers").getString("Host"))
    }

    @Test fun websocketGetsHttp11AlpnButAnExplicitAlpnWins() {
        val ws = outbound(SingBoxConfig.build(vless { put("security", "tls").put("transport", "ws") })).getJSONObject("tls")
        assertEquals("http/1.1", ws.getJSONArray("alpn").getString(0))
        val explicit = outbound(SingBoxConfig.build(vless { put("security", "tls").put("transport", "ws").put("alpn", "h2") }))
            .getJSONObject("tls")
        assertEquals("h2", explicit.getJSONArray("alpn").getString(0))
        val tcp = outbound(SingBoxConfig.build(vless { put("security", "tls") })).getJSONObject("tls")
        assertFalse("plain TCP must not get an ALPN it did not ask for", tcp.has("alpn"))
    }

    @Test fun pinnedAddressKeepsTheNamesTheServerExpects() {
        val out = outbound(SingBoxConfig.build(storedVless(VlessLinkParser.parse(weLink)).put("resolved_ip", "203.0.113.7")))
        assertEquals("203.0.113.7", out.getString("server"))
        assertEquals("scorm.ekb.eg", out.getJSONObject("tls").getString("server_name"))
        assertEquals("scorm.ekb.eg", out.getJSONObject("transport").getJSONObject("headers").getString("Host"))
    }

    @Test fun pinnedAddressFallsBackToTheOriginalHostname() {
        val out = outbound(SingBoxConfig.build(vless {
            put("security", "tls").put("transport", "ws").put("resolved_ip", "203.0.113.7")
        }))
        assertEquals("203.0.113.7", out.getString("server"))
        assertEquals("example.com", out.getJSONObject("tls").getString("server_name"))
        assertEquals("example.com", out.getJSONObject("transport").getJSONObject("headers").getString("Host"))
    }

    @Test fun shadowsocksCanBePinnedToo() {
        assertEquals("203.0.113.7", outbound(SingBoxConfig.build(ss { put("resolved_ip", "203.0.113.7") })).getString("server"))
    }

    @Test fun bootstrapDnsAndStackAreConfigurable() {
        val def = JSONObject(SingBoxConfig.build(ss()))
        assertEquals("mixed", def.getJSONArray("inbounds").getJSONObject(0).getString("stack"))
        val carrier = JSONObject(SingBoxConfig.build(ss(), bootstrapDns = "10.1.2.3", stack = "system"))
        val servers = carrier.getJSONObject("dns").getJSONArray("servers")
        val direct = (0 until servers.length()).map { servers.getJSONObject(it) }.first { it.getString("tag") == "dns-direct" }
        assertEquals("10.1.2.3", direct.getString("server"))
        assertEquals("system", carrier.getJSONArray("inbounds").getJSONObject(0).getString("stack"))
    }
}
