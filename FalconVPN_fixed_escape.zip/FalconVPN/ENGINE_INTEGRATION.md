# Engine integration

This file used to be an early (v0.11) checkpoint that pinned libbox 1.14.0 through JitPack and said the service was
a stub. That is **outdated**: the service, TUN hand-off, status bridge and traffic verification exist now.

Current state and decisions: `ENGINE_DECISION.md`. How libbox.aar is obtained and pinned: `docs/BUILD_LIBBOX.md`.
How to try it on a phone: `docs/TEST_ON_DEVICE.md`. Version history: `CHANGELOG.md`.

Still true: nothing here has been compiled or run on a device by the author, and a successful build is not proof of a
working tunnel.
