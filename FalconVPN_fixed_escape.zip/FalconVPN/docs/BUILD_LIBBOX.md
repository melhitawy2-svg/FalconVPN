# Getting libbox.aar

`app/libs/libbox.aar` is native code that runs inside the VPN process, so its origin matters.

* **Default (CI):** `tools/fetch_libbox.sh` downloads 1.13.14 from JitPack (`singbox-android/libbox`, a third-party
  mirror, not SagerNet), prints the SHA-256 and compares it with `libbox.sha256`. On a mismatch it stops, unless the
  workflow input `trust_first_download` is set. Then it only warns: review the printed hash yourself, then update
  `libbox.sha256`. The pin protects against a swapped file, not against a bad first download.
* **Preferred:** run `build-libbox.yml` (it follows the official `make lib_install` / `make lib_android`, installs an NDK,
  prints the SHA-256, uploads the AAR). Host the result yourself and pass its URL in the `libbox_url` input of `build.yml`.
  The recipe has not been run by the author; if a step fails, follow "Build from source" in the sing-box docs.
* Every CI run uploads `libbox-api.txt` (artifact `libbox-api`): the real Java API of the binary. If the Kotlin code does
  not compile against it, that file is what to compare with `FalconVpnService.kt`.
* The AAR must contain the ABIs you package (`abis` input / `-PfalconAbis=...`). The default is `arm64-v8a` only:
  32-bit ARM phones and x86 emulators need other ABIs in the AAR.
* Protocol support depends on the build tags of the AAR (gVisor, QUIC, uTLS, WireGuard, ...). Test each protocol.

License: sing-box is GPL-3.0. Distributing the APK means distributing under compatible terms (source offer).
Decide this before publishing, especially together with closed-source code or ad SDKs.
