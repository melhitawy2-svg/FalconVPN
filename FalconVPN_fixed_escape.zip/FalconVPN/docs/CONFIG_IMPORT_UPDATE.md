# Falcon VPN — Config Import Service Update

This update hardens the Android file-import path without changing the VPN engine, Libbox service,
profile store, or existing connection configuration.

## Included
- Reads imported files as bounded byte streams (5 MiB limit), not blindly as UTF-8.
- Uses Android's document display name to identify extension-based formats.
- Adds file-open/share intent coverage for generic binary and application MIME types.
- Detects NPVS, NPVT, HTTP Custom, HTTP Injector and HA Tunnel containers before parsing.
- Keeps text/link and sing-box JSON imports on the existing validation + confirmation + encrypted-save path.
- Rejects unknown binary input instead of corrupting it into text or saving guessed profiles.

## Important compatibility status
This is the safe import/recognition layer, not yet the proprietary-format decryption engine.
NPVS and HC are identified and routed to explicit format-specific messages; they are not falsely
reported as decrypted or converted. Full NPVS/HC decoding must be added as a separately licensed,
version-tested decoder module, then mapped field-by-field into sing-box outbounds. In particular,
password/HWID/creator-secret protected variants must continue to require their legitimate unlock
material; no credentials are guessed or bypassed.

## Safety
No VPN runtime files, Libbox integration, selected profile, connection service, or visual assets
were intentionally changed.
