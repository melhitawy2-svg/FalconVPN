# Falcon VPN 0.31.8 — confirmed root cause and verification

## Evidence from the user-provided `app-debug.apk`

The APK archive contained `assets/index.html` and `lib/arm64-v8a/libbox.so`, but did not contain `assets/builtin_services.json`. Its bundled `index.html` also did not contain the `builtInServices` or `useBuiltInService` bridge names. Therefore the APK on the phone was not built from the source revision that contains the WE built-in service picker integration. The Android bridge cannot load a missing asset, and the picker cannot request/select the built-in profile. This matches the empty WE list shown in the screenshot.

## Source-side fixes

- Keep the WE VLESS entry at `app/src/main/assets/builtin_services.json`.
- Do not swallow asset-read/parse errors as `emptyList()`; return a native diagnostic to the picker.
- After selecting the built-in entry, verify it was saved, selected, and can be read back for the engine.
- Add `:app:verifyDebugApkContents`, which inspects the *final APK* and fails unless it contains:
  - `assets/builtin_services.json` with the WE profile label and endpoint host;
  - `assets/index.html` with both native bridge method names.
- CI uploads the APK only after tests, lint, and final APK content verification pass.

## What this proves / does not prove

This fixes the packaging/source-revision failure that prevented the WE profile from appearing. It does not prove the remote VLESS server is currently reachable, that its credentials are still valid, or that the tunnel passes traffic. Those require a successful CI APK build and a device test against the server, including verified exit-IP traffic.
