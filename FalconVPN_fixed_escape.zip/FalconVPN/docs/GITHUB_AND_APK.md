# رفع المشروع على GitHub واستخراج الـ APK

> المشروع **لسه ما اتبنى ولا اتجرّب على جهاز**. الـ CI هو أول مرة بيتبني فيها فعليًا، واللي هيطلع منه (نجاح أو خطأ) هو اللي هيحدد الخطوة الجاية.

## 1) الرفع (مستودع Private مُوصى به)
```bash
cd falcon_v015
git init -b main
git add .
git commit -m "Falcon VPN 0.31.11"
git remote add origin https://github.com/<USER>/<REPO>.git
git push -u origin main
```
- **اجعل المستودع Private.** ملف `app/src/main/assets/builtin_services.json` فيه UUID السيرفر، وهو كمان بيتحزّم داخل أي APK.
- الـ push على `main` بيشغّل البناء تلقائيًا؛ ويمكن تشغيله يدويًا من **Actions → Build APK → Run workflow**.

## 2) أول تشغيل
1. شغّل الـ workflow بالقيم الافتراضية (`abis = arm64-v8a`). الـ SHA-256 المثبّت في `libbox.sha256` يطابق الرقم المنشور للملف `libbox-1.13.14.aar`، فمفروض ما تحتاجش `trust_first_download`.
2. لو وقف عند خطوة الـ hash: افتح **Summary**، راجع الرقم، وفعّل `trust_first_download` مرة واحدة.
3. لو فشل بخطأ compile: نزّل artifact `libbox-api` (ملف `libbox-api.txt`) وابعته مع نص الخطأ — ده بيوضح الفرق بين توقيعات Kotlin والـ AAR الحقيقي.

## 3) الـ APK
- من صفحة التشغيل نزّل artifact **`falcon-debug-apk`** (فيه `app-debug.apk` و`SHA256SUMS.txt`).
- الـ APK بيترفع **قبل** الاختبارات والـ lint؛ فشلهم لا يمنع الحصول عليه (راجع artifact `reports`).
- التثبيت: `adb install -r app-debug.apk` (جهاز arm64، أندرويد 8+). لو الموبايل 32-bit أو emulator شغّل بـ `abis = arm64-v8a,armeabi-v7a` أو `arm64-v8a,x86_64`.

## 4) هل الخدمة شغالة فعلًا؟
الاتصال بيُعتبر ناجح **فقط** بعد: TUN اتفتح ← أندرويد جعل VPN هو الشبكة الافتراضية ← طلب HTTPS نجح عبر النفق وأرجع IP الخروج. لو مفيش IP الخروج ظهر في الرسالة، فالـ VPN غير مُثبت. تابع:
```
adb logcat -s FalconVpnService FalconWebView AndroidRuntime
```
وراجع جدول رسائل الفشل في `docs/TEST_ON_DEVICE.md`.

## 5) قبل نشر أي نسخة للناس
- sing-box رخصته GPL-3.0: تحتاج تتيح الكود المصدري، ولا تدمجه مع SDK إعلانات مغلقة بدون مراجعة.
- كونفج «رفع سرعة راوتر WE» يستخدم `insecure` (لا يتحقق من شهادة السيرفر) + SNI مموّه: أي طرف في الطريق يقدر يقرأ المرور. والـ VPN لا يرفع سرعة الراوتر، فالوصف التسويقي مضلّل ومحتمل يخالف شروط المشغّل. الأفضل: شهادة صحيحة على السيرفر وإزالة `insecure`.
- النسخة debug للتجربة فقط؛ للنشر يلزم توقيع release بمفتاح خاص (يُحفظ في GitHub Secrets).
