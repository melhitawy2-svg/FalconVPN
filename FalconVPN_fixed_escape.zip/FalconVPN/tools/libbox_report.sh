#!/usr/bin/env bash
# Usage: tools/libbox_report.sh path/to/libbox.aar out.txt
# Dumps the Java API of the libbox classes the app uses, so Kotlin signatures can be compared with the
# real binary (a mismatch otherwise only shows up as a compile error). Needs a JDK (javap).
set -uo pipefail
AAR="$1"; OUT="$2"
TMP="$(mktemp -d)"
unzip -p "$AAR" classes.jar > "$TMP/classes.jar"
{
  echo "== native libraries (ABIs) =="
  unzip -l "$AAR" | grep -oE 'jni/[^/]+/[^ ]+' | sort -u
  echo
  echo "== libbox classes =="
  unzip -l "$TMP/classes.jar" | grep -oE 'io/nekohasekai/libbox/[A-Za-z0-9_$]+\.class' | sort -u
  echo
  for c in Libbox SetupOptions PlatformInterface CommandServer CommandServerHandler OverrideOptions TunOptions \
           InterfaceUpdateListener NetworkInterface NetworkInterfaceIterator LocalDNSTransport RoutePrefix \
           RoutePrefixIterator StringIterator SystemProxyStatus WIFIState ConnectionOwner Notification; do
    echo "== io.nekohasekai.libbox.$c =="
    javap -classpath "$TMP/classes.jar" "io.nekohasekai.libbox.$c" 2>&1
    echo
  done
} > "$OUT"
rm -rf "$TMP"
echo "API report written to $OUT"
