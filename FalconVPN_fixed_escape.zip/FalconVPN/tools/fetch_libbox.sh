#!/usr/bin/env bash
# Usage: tools/fetch_libbox.sh [url]
# Env:   TRUST_FIRST_DOWNLOAD=true  continue when the SHA-256 differs from libbox.sha256 (hash is printed; review it)
#        ABIS=arm64-v8a[,x86_64]    native ABIs the AAR must contain
# libbox.aar is native code that runs inside the VPN process, so it is hash-pinned (libbox.sha256).
set -euo pipefail
URL="${1:-}"
[ -n "$URL" ] || URL="https://jitpack.io/com/github/singbox-android/libbox/1.13.14/libbox-1.13.14.aar"
mkdir -p app/libs build-reports
curl -fL --retry 3 "$URL" -o app/libs/libbox.aar
ACTUAL="$(sha256sum app/libs/libbox.aar | cut -d' ' -f1)"
PIN="$(tr -d ' \n\r' < libbox.sha256)"
echo "libbox.aar: $(stat -c %s app/libs/libbox.aar) bytes"
echo "SHA-256 actual: $ACTUAL"
echo "SHA-256 pinned: $PIN"
if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
  { echo "### libbox.aar"; echo "- source: $URL"; echo "- SHA-256: \`$ACTUAL\`"; } >> "$GITHUB_STEP_SUMMARY"
fi

# Capture the listing first: "unzip | grep -q" under pipefail can fail spuriously (SIGPIPE) on large archives.
LISTING="$(unzip -l app/libs/libbox.aar)"
for abi in $(echo "${ABIS:-arm64-v8a}" | tr ',' ' '); do
  if ! grep -q "jni/$abi/" <<< "$LISTING"; then
    echo "::error::libbox.aar contains no native library for ABI '$abi'. Choose ABIs it contains (see build-reports/libbox-api.txt)."
    bash tools/libbox_report.sh app/libs/libbox.aar build-reports/libbox-api.txt || true
    exit 1
  fi
done
bash tools/libbox_report.sh app/libs/libbox.aar build-reports/libbox-api.txt || true

if [ "$ACTUAL" != "$PIN" ]; then
  if [ "${TRUST_FIRST_DOWNLOAD:-false}" = "true" ]; then
    echo "::warning::libbox.aar SHA-256 differs from libbox.sha256 (pinned $PIN). Continuing because trust_first_download=true. Verify $ACTUAL yourself, then write it into libbox.sha256."
  else
    echo "::error::libbox.aar SHA-256 mismatch. Actual: $ACTUAL  Pinned: $PIN. Re-run with trust_first_download=true, review the hash, then update libbox.sha256."
    exit 1
  fi
fi
