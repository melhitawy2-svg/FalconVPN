# Falcon VPN (Android)

WebView UI (`app/src/main/assets/index.html`, the country-flags design, single file) + native Kotlin VPN service on top of sing-box **libbox 1.13.14**.
Imports `ss://`, `vless://`, `vmess://`, `trojan://`, `hysteria2://` links and https subscriptions; forms for VMess, Trojan, Hysteria2, TUIC, WireGuard, SOCKS, HTTP, SSH, Custom JSON.

**Status: not yet compiled or run on a device.** See `CHANGELOG.md` for what changed and what is still open.

## Build
CI: `.github/workflows/build.yml` downloads `libbox.aar` (checksum-verified, fails on mismatch), runs the JVM unit tests,
builds a debug APK and uploads it as an artifact. Locally: put `libbox.aar` in `app/libs/` and run
`gradle testDebugUnitTest assembleDebug`.

## Layout
- `vpn/engine/` — `LinkSyntax`, `ShadowsocksLinkParser`, `VlessLinkParser`, `SingBoxConfig`, `SecureProfileStore`
  (pure Kotlin except the store; covered by tests in `app/src/test`).
- `vpn/platform/FalconVpnService.kt` — libbox `PlatformInterface` + `CommandServerHandler`, TUN, lifecycle.
- `com.falconvpn.app.MainActivity` — WebView host, native bridge, status push, import confirmation.
- `tools/ui_test.py` — UI logic tests against a mock bridge (needs `pip install playwright`).
- `docs/history/` — per-version notes up to v0.27.0.
