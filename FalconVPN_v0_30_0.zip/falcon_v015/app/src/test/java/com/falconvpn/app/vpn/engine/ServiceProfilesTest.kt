package com.falconvpn.app.vpn.engine

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

class ServiceProfilesTest {
    private val uuid = "11111111-2222-3333-4444-555555555555"
    private val key = Base64.getEncoder().encodeToString(ByteArray(32) { it.toByte() })

    private fun rejects(block: () -> Unit) {
        try { block(); fail("expected IllegalArgumentException") } catch (_: IllegalArgumentException) {}
    }

    @Test fun trojanForm() {
        val p = ServiceProfiles.fromForm("Trojan", mapOf("server" to "t.example.com", "port" to "443", "password" to "pw"), "")
        assertEquals("trojan", p.singbox.getString("type"))
        assertEquals("proxy", p.singbox.getString("tag"))
        assertTrue(p.singbox.getJSONObject("tls").getBoolean("enabled"))
    }

    @Test fun vmessWebSocketForm() {
        val p = ServiceProfiles.fromForm("VMess", mapOf("server" to "v.example.com", "port" to "443", "uuid" to uuid,
            "transport" to "WebSocket", "tls" to "مفعّل"), "n")
        assertEquals("ws", p.singbox.getJSONObject("transport").getString("type"))
        assertEquals("v.example.com", p.singbox.getJSONObject("tls").getString("server_name"))
    }

    @Test fun badPortAndUuidRejected() {
        rejects { ServiceProfiles.fromForm("Trojan", mapOf("server" to "a", "port" to "70000", "password" to "x"), "") }
        rejects { ServiceProfiles.fromForm("TUIC", mapOf("server" to "a", "port" to "1", "uuid" to "nope", "password" to "x"), "") }
    }

    @Test fun wireGuardIsAnEndpoint() {
        val p = ServiceProfiles.fromForm("WireGuard", mapOf("server" to "w.example.com", "port" to "51820",
            "privateKey" to key, "peerKey" to key, "address" to "10.0.0.2/32"), "")
        assertTrue(p.endpoint)
        assertEquals("wireguard", p.singbox.getString("type"))
        rejects { ServiceProfiles.fromForm("WireGuard", mapOf("server" to "w", "port" to "1", "privateKey" to "short",
            "peerKey" to key, "address" to "10.0.0.2/32"), "") }
    }

    @Test fun unsupportedServicesAreRefused() {
        for (s in listOf("OpenVPN", "UDP Custom", "Psiphon", "One Cloud")) rejects { ServiceProfiles.fromForm(s, emptyMap(), "") }
    }

    @Test fun customJsonOnlyAcceptsOneOutbound() {
        val ok = ServiceProfiles.fromForm("Custom JSON", mapOf("json" to """{"type":"socks","server":"s.example.com","server_port":1080,"detour":"x"}"""), "")
        assertFalse(ok.singbox.has("detour"))
        assertEquals("proxy", ok.singbox.getString("tag"))
        rejects { ServiceProfiles.fromForm("Custom JSON", mapOf("json" to """{"outbounds":[]}"""), "") }
        rejects { ServiceProfiles.fromForm("Custom JSON", mapOf("json" to """{"type":"direct"}"""), "") }
    }

    @Test fun trojanAndHysteria2Links() {
        val t = ServiceProfiles.fromLink("trojan://pw@t.example.com:443?sni=a.com&type=ws&path=%2Fx#My%20Trojan")
        assertEquals("My Trojan", t.name)
        assertEquals("ws", t.singbox.getJSONObject("transport").getString("type"))
        val h = ServiceProfiles.fromLink("hy2://tok@h.example.com:8443?sni=a.com&obfs=salamander&obfs-password=o#h")
        assertEquals("salamander", h.singbox.getJSONObject("obfs").getString("type"))
        rejects { ServiceProfiles.fromLink("hysteria2://tok@h.example.com:443?insecure=1") }
        rejects { ServiceProfiles.fromLink("trojan://pw@t.example.com:443?allowInsecure=1") }
    }

    @Test fun vmessLink() {
        val json = """{"v":"2","ps":"vm","add":"v.example.com","port":"443","id":"$uuid","aid":"0","net":"ws","path":"/p","tls":"tls"}"""
        val link = "vmess://" + Base64.getEncoder().encodeToString(json.toByteArray())
        val p = ServiceProfiles.fromLink(link)
        assertEquals("vm", p.name)
        assertEquals("/p", p.singbox.getJSONObject("transport").getString("path"))
    }

    @Test fun configBuilderUsesGenericOutboundAndEndpoint() {
        val trojan = ServiceProfiles.fromForm("Trojan", mapOf("server" to "t.example.com", "port" to "443", "password" to "pw"), "")
        val cfg = JSONObject(SingBoxConfig.build(JSONObject().put("host", trojan.host).put("port", trojan.port)
            .put("protocol", "Trojan").put("singbox", trojan.singbox.toString())))
        assertEquals("trojan", cfg.getJSONArray("outbounds").getJSONObject(0).getString("type"))
        val wg = ServiceProfiles.fromForm("WireGuard", mapOf("server" to "w.example.com", "port" to "51820",
            "privateKey" to key, "peerKey" to key, "address" to "10.0.0.2/32"), "")
        val cfg2 = JSONObject(SingBoxConfig.build(JSONObject().put("host", wg.host).put("port", wg.port)
            .put("protocol", "WireGuard").put("endpoint", true).put("singbox", wg.singbox.toString())))
        assertEquals("wireguard", cfg2.getJSONArray("endpoints").getJSONObject(0).getString("type"))
        assertEquals("direct", cfg2.getJSONArray("outbounds").getJSONObject(0).getString("type"))
    }
}
