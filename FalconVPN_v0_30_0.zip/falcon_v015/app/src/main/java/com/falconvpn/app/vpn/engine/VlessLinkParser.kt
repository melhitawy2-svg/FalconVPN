package com.falconvpn.app.vpn.engine

/**
 * Parses vless:// share links. Parsing/importing does not establish a VPN tunnel.
 *
 * Every option this parser accepts is implemented by [SingBoxConfig]; options that cannot be
 * honoured (xhttp, kcp, allowInsecure, VLESS encryption, ...) are rejected at import time with a
 * clear message instead of failing later at connect time.
 */
data class VlessProfile(
    val name: String,
    val host: String,
    val port: Int,
    val uuid: String,
    val security: String,
    val sni: String,
    val transport: String,
    val path: String,
    val wsHost: String,
    /** "" or "xtls-rprx-vision". */
    val flow: String = "",
    /** uTLS fingerprint (chrome, firefox, ...); empty = none (Reality defaults to chrome). */
    val fingerprint: String = "",
    val alpn: List<String> = emptyList(),
    /** Reality public key (pbk). */
    val publicKey: String = "",
    /** Reality short id (sid), hex, may be empty. */
    val shortId: String = "",
    /** gRPC service name. */
    val serviceName: String = ""
)

object VlessLinkParser {
    // Any 8-4-4-4-12 hex UUID. Do NOT enforce RFC 4122 version/variant: many servers use custom ones.
    private val UUID_PATTERN = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private val SHORT_ID_PATTERN = Regex("[0-9a-fA-F]{0,16}")
    private val TRANSPORTS = setOf("tcp", "ws", "grpc", "httpupgrade", "http")

    fun parse(rawLink: String): VlessProfile {
        val raw = rawLink.trim()
        require(raw.startsWith("vless://", ignoreCase = true)) { "Not a VLESS link" }

        val (beforeFragment, fragment) = LinkSyntax.splitFragment(raw.substring(8))
        val (main, rawQuery) = LinkSyntax.splitQuery(beforeFragment)
        // Keys are matched case-insensitively (serverName / servername / SNI all occur in the wild).
        val query = LinkSyntax.parseQuery(rawQuery).mapKeys { it.key.lowercase() }
        fun q(vararg keys: String): String = keys.firstNotNullOfOrNull { query[it]?.takeIf { v -> v.isNotBlank() } }.orEmpty()

        val at = main.lastIndexOf('@')
        require(at > 0) { "رابط VLESS لا يحتوي على UUID" }
        val uuid = LinkSyntax.percentDecode(main.substring(0, at), lenient = true).trim()
        require(UUID_PATTERN.matches(uuid)) { "UUID في رابط VLESS غير صالح" }
        val endpoint = LinkSyntax.parseHostPort(main.substring(at + 1).substringBefore('/'))

        val encryption = q("encryption").lowercase()
        require(encryption.isEmpty() || encryption == "none") { "تشفير VLESS (encryption) غير مدعوم: يجب أن يكون none." }
        require(q("allowinsecure").lowercase() !in setOf("1", "true")) {
            "الرابط يطلب تعطيل التحقق من الشهادة (allowInsecure) وهذا غير مسموح لأسباب أمنية."
        }

        val security = q("security").lowercase().ifEmpty { "none" }
        require(security in setOf("none", "tls", "reality")) { "نوع الحماية غير مدعوم في رابط VLESS: ${LinkSyntax.sanitizeLabel(security, 20)}" }

        val transport = q("type").lowercase().ifEmpty { "tcp" }.let { if (it == "h2") "http" else it }
        require(transport in TRANSPORTS) { "نوع النقل غير مدعوم حاليًا: ${LinkSyntax.sanitizeLabel(transport, 20)}" }
        require(!(transport == "tcp" && q("headertype").lowercase() == "http")) { "تمويه HTTP على TCP (headerType=http) غير مدعوم." }

        val flow = q("flow")
        require(flow.isEmpty() || flow == "xtls-rprx-vision") { "قيمة flow غير مدعومة: ${LinkSyntax.sanitizeLabel(flow, 30)}" }
        require(flow.isEmpty() || security != "none") { "flow يتطلب security=tls أو reality." }

        val publicKey = q("pbk")
        val shortId = q("sid")
        if (security == "reality") {
            require(publicKey.isNotEmpty()) { "رابط Reality لا يحتوي على المفتاح العام (pbk)." }
            require(SHORT_ID_PATTERN.matches(shortId)) { "قيمة shortId (sid) غير صالحة." }
        }

        var path = q("path")
        // Some sharing services double-encode the path (%252F -> %2F -> /); LinkSyntax already decoded once.
        repeat(2) { if (path.contains('%')) path = LinkSyntax.percentDecode(path, lenient = true) }
        if ((transport == "ws" || transport == "httpupgrade" || transport == "http") && path.isBlank()) path = "/"

        return VlessProfile(
            name = LinkSyntax.sanitizeLabel(fragment.orEmpty()).ifBlank { "VLESS server" },
            host = endpoint.host,
            port = endpoint.port,
            uuid = uuid,
            security = security,
            sni = q("sni", "servername", "peer"),
            transport = transport,
            path = path,
            wsHost = q("host"),
            flow = flow,
            fingerprint = q("fp"),
            alpn = q("alpn").split(',').map { it.trim() }.filter { it.isNotEmpty() },
            publicKey = publicKey,
            shortId = shortId,
            serviceName = q("servicename")
        )
    }
}
