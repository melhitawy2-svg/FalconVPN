# Falcon VPN v0.30.7 — Import form and TLS flag fix

- Import modal now places Save and Back actions directly below the text/file inputs and keeps them sticky while preview output scrolls.
- Save reads either pasted text or the selected file.
- All share links are routed through one native parser and confirmation flow.
- VLESS `allowInsecure=1` / `insecure=1` is parsed per profile, explicitly warned about, stored encrypted, and mapped to sing-box `tls.insecure=true`; it is not treated as an Android permission.
- VLESS manual template now exposes the same explicit per-profile option.
- Saved native profiles are refreshed after confirmation and the first imported profile is selected when no tunnel is active.
- OpenVPN, Psiphon, One Cloud and UDP Custom remain visibly marked as unavailable because their separate engines are not integrated. They are not falsely saved as working VPN services.

Import success only confirms parse and local save. It does not prove that the remote server is live or credentials are valid. Real connection must be verified on-device.
