package com.falconvpn.app.vpn.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import androidx.core.app.NotificationCompat
import com.falconvpn.app.MainActivity
import com.falconvpn.app.vpn.engine.SecureProfileStore
import com.falconvpn.app.vpn.engine.SingBoxConfig
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.RoutePrefix
import io.nekohasekai.libbox.RoutePrefixIterator
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.InetAddress
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.util.Log
import io.nekohasekai.libbox.NetworkInterface as BoxNetworkInterface
import io.nekohasekai.libbox.Notification as BoxNotification
import java.net.NetworkInterface as JavaNetworkInterface

/**
 * Android VPN service backed by sing-box libbox (CommandServer + PlatformInterface).
 * A valid TUN descriptor proves only that Android created the local VPN interface.
 * CONNECTED is reported only after a public-IP HTTPS request succeeds through the
 * app's normal network route (which should be the VPN route).
 * Written against libbox 1.13.14 signatures; device verification is still required.
 */
class FalconVpnService : VpnService(), PlatformInterface, CommandServerHandler {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val connectivity by lazy { getSystemService(ConnectivityManager::class.java) }
    @Volatile private var commandServer: CommandServer? = null
    @Volatile private var tunPfd: ParcelFileDescriptor? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val store by lazy { SecureProfileStore(applicationContext) }
    /** True from the moment a start is accepted until shutdown/failure completes. Prevents a second
     *  CommandServer from being created by a double tap or a duplicate START intent. */
    private val engineActive = AtomicBoolean(false)
    @Volatile private var lastNotificationText = "Falcon VPN"
    private var foregroundStarted = false
    private val timerHandler = Handler(Looper.getMainLooper())
    private var sessionEndsAtMillis = 0L
    /** Optional auto-disconnect chosen by the user in Settings (0 = off). Fires once, no per-second work. */
    private val sessionTimer = Runnable {
        if (sessionEndsAtMillis > 0L) stopRealSession("انتهى مؤقت الفصل التلقائي.")
    }

    override fun onCreate() {
        super.onCreate()
        alive = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                executor.execute { shutdown("تم إيقاف الاتصال.") }
                return START_NOT_STICKY
            }
            ACTION_START -> startConnection(startId)
            else -> {
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startConnection(startId: Int) {
        createNotificationChannel()
        // A start issued with startForegroundService() MUST reach startForeground() even when we end up
        // ignoring it, otherwise Android kills the app (ForegroundServiceDidNotStartInTimeException).
        val duplicate = !engineActive.compareAndSet(false, true)
        if (!duplicate) engineStarting = true
        startForeground(NOTIFICATION_ID, notification(if (duplicate) lastNotificationText else "جارٍ تجهيز اتصال Falcon VPN"))
        foregroundStarted = true
        if (duplicate) return // already starting or running: do not touch state or create a second engine
        updateState(STATE_CONNECTING, "بدء خدمة VPN…")
        Log.i(TAG, "startConnection: service accepted startId=$startId")

        // Defense in depth: permission is normally requested by MainActivity, but the
        // service must also fail safely if it is started from a notification/system path.
        if (VpnService.prepare(this) != null) {
            failAndStop(startId, "إذن VPN غير متاح. افتح التطبيق واضغط اتصال لمنح الإذن.", STATE_NEEDS_PERMISSION)
            return
        }
        updateState(STATE_CONNECTING, "إذن VPN متاح؛ جارٍ التحقق من الكونفيج…")

        // Do not establish an empty TUN or show CONNECTED without a live engine.
        val profile = runCatching { store.getSelectedForEngine() }.getOrNull()
        if (profile == null) {
            failAndStop(startId, "لا يوجد كونفيج محدد. استورد رابط VLESS أو VMess أو Shadowsocks صالحًا ثم حدده.")
            return
        }

        executor.execute {
            try {
                updateState(STATE_CONNECTING, "تم العثور على الكونفيج؛ جارٍ تهيئة Libbox…")
                startEngine(profile)
                // CONNECTED is only valid after libbox has called openTun and Android has
                // returned a live TUN descriptor. A successful method return alone is not enough.
                val deadline = System.currentTimeMillis() + 5_000L
                while ((tunPfd == null || tunPfd?.fileDescriptor?.valid() != true || tunPfd?.isClosed == true) &&
                    System.currentTimeMillis() < deadline) {
                    Thread.sleep(100)
                }
                val activeTun = tunPfd
                if (activeTun == null || activeTun.isClosed || !activeTun.fileDescriptor.valid()) {
                    throw IllegalStateException("لم ينشئ Libbox واجهة TUN صالحة؛ لم يتم بدء نفق VPN.")
                }
                updateState(STATE_CONNECTING, "تم إنشاء TUN؛ جارٍ التأكد أن Android يوجّه الشبكة عبر VPN…")
                awaitVpnAsDefaultNetwork()
                updateState(STATE_CONNECTING, "شبكة VPN أصبحت المسار الافتراضي؛ جارٍ اختبار عنوان الخروج…")
                val exitIp = verifyTrafficThroughTunnel()
                // Re-check after the probe as the VPN may have been revoked or replaced while
                // the HTTPS request was in flight. Do not accept a successful direct-network probe.
                requireActiveVpnDefaultNetwork()
                engineRunning = true
                engineStarting = false
                startSessionTimerAfterEngineConnected()
                getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_VERIFIED_EXIT_IP, exitIp)
                    .putLong(KEY_TRAFFIC_VERIFIED_AT, System.currentTimeMillis())
                    .apply()
                Log.i(TAG, "libbox TUN is active and HTTPS traffic probe succeeded; exitIp=$exitIp")
                updateState(STATE_CONNECTED, "اتصال VPN نشط؛ تم التحقق من مرور البيانات. IP الخروج: $exitIp")
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("متصل • $exitIp"))
            } catch (e: Throwable) {
                Log.e(TAG, "libbox startup failed", e)
                stopEngine()
                val detail = (e.message ?: e.javaClass.simpleName).take(350)
                getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_LAST_ERROR, detail)
                    .putString(KEY_ENGINE_STAGE, "LIBBOX_START")
                    .apply()
                failAndStop(startId, "فشل تشغيل Libbox: $detail")
            }
        }
    }

    /**
     * Wait until Android exposes the VPN as this process' active/default network. This prevents
     * a successful HTTPS request over the physical network from being mistaken for VPN traffic.
     * We intentionally do not bind the probe to the underlying Network and do not call protect().
     */
    private fun awaitVpnAsDefaultNetwork() {
        val deadline = System.currentTimeMillis() + 10_000L
        var last = "لم يعلن Android عن شبكة VPN كمسار افتراضي بعد."
        while (System.currentTimeMillis() < deadline) {
            try {
                requireActiveVpnDefaultNetwork()
                return
            } catch (e: Exception) {
                last = e.message ?: last
                Thread.sleep(250)
            }
        }
        throw IllegalStateException("تم إنشاء TUN لكن Android لم يجعل VPN شبكة الاتصال الافتراضية: $last")
    }

    /** Requires the app's active network to carry TRANSPORT_VPN. */
    private fun requireActiveVpnDefaultNetwork() {
        val active = connectivity.activeNetwork
            ?: throw IllegalStateException("لا توجد شبكة افتراضية نشطة في Android.")
        val caps = connectivity.getNetworkCapabilities(active)
            ?: throw IllegalStateException("تعذر قراءة خصائص شبكة Android النشطة.")
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
            throw IllegalStateException("شبكة Android النشطة ليست VPN؛ رفضنا اعتبار اختبار الإنترنت اتصالاً ناجحاً.")
        }
    }

    /**
     * Verifies real outbound traffic after Android confirms VPN is the active/default network.
     * The request deliberately uses the normal app network (no protect(), no explicit underlying
     * Network), so it must traverse sing-box. A live TUN alone is never treated as success.
     */
    private fun verifyTrafficThroughTunnel(): String {
        requireActiveVpnDefaultNetwork()
        val endpoints = listOf(
            "https://api.ipify.org",
            "https://checkip.amazonaws.com"
        )
        var lastFailure: Throwable? = null
        for (endpoint in endpoints) {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Accept", "text/plain")
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("اختبار الإنترنت أعاد HTTP $code من $endpoint")
                val ip = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().trim() }
                require(ip.length in 3..64 && ip.matches(Regex("[0-9a-fA-F:.]+"))) {
                    "استجابة اختبار IP غير صالحة."
                }
                return ip
            } catch (t: Throwable) {
                lastFailure = t
                Log.w(TAG, "Traffic verification endpoint failed: $endpoint", t)
            } finally {
                connection?.disconnect()
            }
        }
        throw IllegalStateException(
            "تم إنشاء TUN لكن لم ينجح اختبار مرور الإنترنت عبره؛ لن نعرض الاتصال كناجح. " +
                (lastFailure?.message ?: "تعذر الوصول إلى خوادم اختبار IP.")
        )
    }

    private fun startEngine(profile: org.json.JSONObject) {
        // Built in memory and passed straight to libbox: the config contains the proxy password / UUID
        // and is never written to disk.
        updateState(STATE_CONNECTING, "جارٍ فحص إعدادات السيرفر…")
        val configJson = SingBoxConfig.build(profile)
        Log.i(TAG, "profile validated: protocol=${profile.optString("protocol")} host=${profile.optString("host")} port=${profile.optInt("port")}")
        updateState(STATE_CONNECTING, "جارٍ تحميل مكتبة Libbox…")
        synchronized(FalconVpnService::class.java) {
            if (!setupDone) {
                Libbox.setup(SetupOptions().also {
                    it.basePath = filesDir.path
                    it.workingPath = (getExternalFilesDir(null) ?: filesDir).path
                    it.tempPath = cacheDir.path
                    it.logMaxLines = 500L
                    it.debug = false
                })
                setupDone = true
            }
        }
        updateState(STATE_CONNECTING, "تم تحميل Libbox؛ جارٍ تشغيل CommandServer…")
        val server = Libbox.newCommandServer(this, this)
        commandServer = server
        server.start()
        updateState(STATE_CONNECTING, "CommandServer يعمل؛ جارٍ إنشاء نفق TUN…")
        server.startOrReloadService(configJson, OverrideOptions())
    }

    @Synchronized
    private fun stopEngine() {
        runCatching { commandServer?.closeService() }
        runCatching { commandServer?.close() }
        commandServer = null
        runCatching { tunPfd?.close() }
        tunPfd = null
        networkCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        networkCallback = null
    }

    /** Runs on the executor thread. */
    private fun shutdown(message: String) {
        stopEngine()
        engineRunning = false
        engineStarting = false
        stopSessionTimer()
        engineActive.set(false)
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .remove(KEY_VERIFIED_EXIT_IP).remove(KEY_TRAFFIC_VERIFIED_AT).apply()
        updateState(STATE_DISCONNECTED, message)
        stopForegroundCompat()
        stopSelf()
    }

    /** Safe to call from any thread, including libbox callbacks. */
    private fun shutdownAsync(message: String) {
        mainHandler.post { executor.execute { shutdown(message) } }
    }

    /** Call only after libbox reports a successfully started, working tunnel. */
    private fun startSessionTimerAfterEngineConnected() {
        val now = System.currentTimeMillis()
        val minutes = getSharedPreferences(SETTINGS_PREFS, MODE_PRIVATE).getInt(KEY_AUTO_DISCONNECT_MIN, 0)
        val edit = getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit().putLong(KEY_CONNECTED_AT, now)
        timerHandler.removeCallbacks(sessionTimer)
        if (minutes > 0) {
            val duration = minutes * 60_000L
            sessionEndsAtMillis = now + duration
            edit.putLong(KEY_SESSION_ENDS_AT, sessionEndsAtMillis)
            timerHandler.postDelayed(sessionTimer, duration)
        } else {
            sessionEndsAtMillis = 0L
            edit.remove(KEY_SESSION_ENDS_AT)
        }
        edit.apply()
    }

    private fun stopSessionTimer() {
        timerHandler.removeCallbacks(sessionTimer)
        sessionEndsAtMillis = 0L
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .remove(KEY_SESSION_ENDS_AT).remove(KEY_CONNECTED_AT).apply()
    }

    private fun stopRealSession(reason: String) = shutdownAsync(reason)

    private fun failAndStop(startId: Int, message: String, state: String = STATE_ERROR) {
        stopEngine()
        engineRunning = false
        engineStarting = false
        stopSessionTimer()
        engineActive.set(false)
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .remove(KEY_VERIFIED_EXIT_IP).remove(KEY_TRAFFIC_VERIFIED_AT).apply()
        updateState(state, message)
        if (foregroundStarted) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, notification(message))
        }
        stopForegroundCompat()
        stopSelf(startId)
    }

    private fun notification(message: String): Notification {
        lastNotificationText = message
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FalconVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.falconvpn.app.R.drawable.ic_stat_falcon)
            .setContentTitle("Falcon VPN")
            .setContentText(message.take(180))
            .setContentIntent(openApp)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(foregroundStarted)
            .setOnlyAlertOnce(true)
            .addAction(0, "إيقاف", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "اتصال Falcon VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun updateState(state: String, message: String) {
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATE, state)
            .putString(KEY_MESSAGE, message)
            .putString(KEY_ENGINE_STAGE, message)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        foregroundStarted = false
    }

    override fun onRevoke() {
        shutdownAsync("تم إلغاء إذن VPN من إعدادات أندرويد؛ تم إيقاف الخدمة بأمان.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopEngine()
        engineRunning = false
        engineStarting = false
        stopSessionTimer()
        engineActive.set(false)
        alive = false
        // Never leave a stale CONNECTED/CONNECTING behind for the UI to read.
        reconcileStaleState(applicationContext)
        if (foregroundStarted) stopForegroundCompat()
        super.onDestroy()
    }

    // ---------------- CommandServerHandler ----------------
    override fun getSystemProxyStatus(): SystemProxyStatus = throw UnsupportedOperationException()
    override fun serviceReload() = shutdownAsync("طلب المحرك إعادة التحميل؛ تم إيقاف الاتصال.")
    override fun serviceStop() = shutdownAsync("أوقف المحرك الاتصال.")
    override fun setSystemProxyEnabled(isEnabled: Boolean) {}
    override fun writeDebugMessage(message: String?) {}

    // ---------------- PlatformInterface ----------------
    override fun autoDetectInterfaceControl(fd: Int) {
        if (!protect(fd)) throw Exception("تعذر حماية المقبس (protect) من نفق VPN.")
    }

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true
    override fun clearDNSCache() {}
    override fun includeAllNetworks(): Boolean = false
    override fun underNetworkExtension(): Boolean = false
    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
    override fun localDNSTransport(): LocalDNSTransport? = null
    override fun readWIFIState(): WIFIState? = null
    override fun sendNotification(notification: BoxNotification) {}
    override fun systemCertificates(): StringIterator = StringArray(emptyList())

    override fun findConnectionOwner(
        ipProtocol: Int, sourceAddress: String?, sourcePort: Int,
        destinationAddress: String?, destinationPort: Int
    ): ConnectionOwner = throw Exception("البحث عن مالك الاتصال غير مدعوم.")

    private fun pickUnderlying(): Network? {
        @Suppress("DEPRECATION")
        val candidates = connectivity.allNetworks.mapNotNull { n ->
            val c = connectivity.getNetworkCapabilities(n) ?: return@mapNotNull null
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return@mapNotNull null
            val rank = when {
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 0
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 2
                else -> 3
            }
            val validated = if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 0 else 10
            Triple(n, rank + validated, c)
        }
        return candidates.minByOrNull { it.second }?.first
    }

    private fun reportDefault(listener: InterfaceUpdateListener) {
        val network = pickUnderlying()
        // Tell Android which physical network carries the tunnel: fixes "connected, no internet" after a
        // Wi-Fi <-> mobile data switch and makes the system report the right network to apps.
        runCatching { setUnderlyingNetworks(if (network != null) arrayOf(network) else null) }
        val name = network?.let { connectivity.getLinkProperties(it)?.interfaceName }
        if (network == null || name == null) {
            listener.updateDefaultInterface("", -1, false, false)
            return
        }
        val index = runCatching { JavaNetworkInterface.getByName(name)?.index ?: 0 }.getOrDefault(0)
        val caps = connectivity.getNetworkCapabilities(network)
        val metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        listener.updateDefaultInterface(name, index, metered, false)
    }

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = reportDefault(listener)
            override fun onLost(network: Network) = reportDefault(listener)
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = reportDefault(listener)
        }
        networkCallback = callback
        connectivity.registerNetworkCallback(
            NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), callback
        )
        reportDefault(listener)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        networkCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        networkCallback = null
    }

    override fun getInterfaces(): NetworkInterfaceIterator {
        val javaIfaces = JavaNetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        val out = mutableListOf<BoxNetworkInterface>()
        @Suppress("DEPRECATION")
        for (network in connectivity.allNetworks) {
            val lp = connectivity.getLinkProperties(network) ?: continue
            val caps = connectivity.getNetworkCapabilities(network) ?: continue
            val name = lp.interfaceName ?: continue
            val ji = javaIfaces.find { it.name == name } ?: continue
            val box = BoxNetworkInterface()
            box.name = name
            box.index = ji.index
            box.dnsServer = StringArray(lp.dnsServers.mapNotNull { it.hostAddress?.substringBefore('%') })
            box.type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                else -> Libbox.InterfaceTypeOther
            }
            runCatching { box.mtu = ji.mtu }
            box.addresses = StringArray(ji.interfaceAddresses.map { it.address.hostAddress.orEmpty().substringBefore('%') + "/" + it.networkPrefixLength })
            var flags = 0
            if (ji.isUp) flags = flags or OsConstants.IFF_UP or OsConstants.IFF_RUNNING
            if (ji.isLoopback) flags = flags or OsConstants.IFF_LOOPBACK
            if (ji.isPointToPoint) flags = flags or OsConstants.IFF_POINTOPOINT
            if (ji.supportsMulticast()) flags = flags or OsConstants.IFF_MULTICAST
            box.flags = flags
            box.metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            out.add(box)
        }
        return InterfaceArray(out.iterator())
    }

    private fun RoutePrefixIterator.collect(): List<RoutePrefix> {
        val l = mutableListOf<RoutePrefix>(); while (hasNext()) l.add(next()); return l
    }

    private fun StringIterator.collect(): List<String> {
        val l = mutableListOf<String>(); while (hasNext()) l.add(next()); return l
    }

    override fun openTun(options: TunOptions): Int {
        if (VpnService.prepare(this) != null) throw Exception("إذن VPN غير ممنوح.")
        val builder = Builder().setSession("Falcon VPN").setMtu(options.getMTU())
        val v4 = options.getInet4Address().collect()
        val v6 = options.getInet6Address().collect()
        v4.forEach { builder.addAddress(it.address(), it.prefix()) }
        v6.forEach { builder.addAddress(it.address(), it.prefix()) }
        if (options.getAutoRoute()) {
            builder.addDnsServer(options.getDNSServerAddress().value)
            val r4 = options.getInet4RouteAddress().collect() + options.getInet4RouteRange().collect()
            val r6 = options.getInet6RouteAddress().collect() + options.getInet6RouteRange().collect()
            if (r4.isNotEmpty()) r4.forEach { builder.addRoute(it.address(), it.prefix()) }
            else if (v4.isNotEmpty()) builder.addRoute("0.0.0.0", 0)
            if (r6.isNotEmpty()) r6.forEach { builder.addRoute(it.address(), it.prefix()) }
            else if (v6.isNotEmpty()) builder.addRoute("::", 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                (options.getInet4RouteExcludeAddress().collect() + options.getInet6RouteExcludeAddress().collect()).forEach {
                    builder.excludeRoute(IpPrefix(InetAddress.getByName(it.address()), it.prefix()))
                }
            }
            options.getIncludePackage().collect().forEach { runCatching { builder.addAllowedApplication(it) } }
            options.getExcludePackage().collect().forEach { runCatching { builder.addDisallowedApplication(it) } }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        pickUnderlying()?.let { builder.setUnderlyingNetworks(arrayOf(it)) }
        val pfd = builder.establish() ?: throw Exception("تعذر إنشاء واجهة VPN (ربما تم سحب الإذن).")
        tunPfd = pfd
        return pfd.fd
    }

    private class StringArray(items: List<String>) : StringIterator {
        private val it = items.iterator()
        private val size = items.size
        override fun hasNext(): Boolean = it.hasNext()
        override fun len(): Int = size
        override fun next(): String = it.next()
    }

    private class InterfaceArray(private val it: Iterator<BoxNetworkInterface>) : NetworkInterfaceIterator {
        override fun hasNext(): Boolean = it.hasNext()
        override fun next(): BoxNetworkInterface = it.next()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    companion object {
        @Volatile private var setupDone = false
        /** Set only after libbox opened a valid Android TUN descriptor; never persisted. */
        @Volatile var engineRunning = false
        /** True only while a real native start attempt is in progress. */
        @Volatile var engineStarting = false

        /** True while a FalconVpnService instance exists in THIS process. After the process is killed it is
         *  false again, which is how a persisted CONNECTED state is recognised as stale. */
        @Volatile var alive = false
            private set

        /**
         * The runtime state lives in SharedPreferences and survives process death. If the service is not
         * running, any "active" state left there is stale: reset it so the UI cannot show "connected"
         * while no VPN exists. Safe to call from any thread.
         */
        fun reconcileStaleState(context: android.content.Context) {
            val prefs = context.getSharedPreferences(STATUS_PREFS, android.content.Context.MODE_PRIVATE)
            val state = prefs.getString(KEY_STATE, STATE_DISCONNECTED)
            // CONNECTING is legitimate while the service instance is alive. CONNECTED is
            // legitimate only while this process still owns a successfully opened TUN.
            val stale = when (state) {
                STATE_CONNECTED -> !alive || !engineRunning
                STATE_CONNECTING -> !alive || !engineStarting
                else -> false
            }
            if (stale) {
                prefs.edit()
                    .putString(KEY_STATE, STATE_DISCONNECTED)
                    .putString(KEY_MESSAGE, "تم إيقاف الاتصال.")
                    .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
                    .remove(KEY_SESSION_ENDS_AT)
                    .remove(KEY_CONNECTED_AT)
                    .putString(KEY_ENGINE_STAGE, "IDLE")
                    .apply()
            }
        }
        const val ACTION_START = "com.falconvpn.app.vpn.START"
        const val ACTION_STOP = "com.falconvpn.app.vpn.STOP"
        const val STATUS_PREFS = "falcon_vpn_runtime_status"
        const val KEY_STATE = "state"
        const val KEY_MESSAGE = "message"
        const val KEY_UPDATED_AT = "updated_at"
        const val KEY_ENGINE_STAGE = "engine_stage"
        const val KEY_LAST_ERROR = "last_error"
        const val KEY_VERIFIED_EXIT_IP = "verified_exit_ip"
        const val KEY_TRAFFIC_VERIFIED_AT = "traffic_verified_at"
        private const val TAG = "FalconVpnService"
        const val KEY_SESSION_ENDS_AT = "session_ends_at"
        const val KEY_CONNECTED_AT = "connected_at"
        const val SETTINGS_PREFS = "falcon_settings"
        const val KEY_AUTO_DISCONNECT_MIN = "auto_disconnect_minutes"
        const val STATE_DISCONNECTED = "DISCONNECTED"
        const val STATE_NEEDS_PERMISSION = "NEEDS_PERMISSION"
        const val STATE_CONNECTING = "CONNECTING"
        const val STATE_CONNECTED = "CONNECTED"
        const val STATE_ERROR = "ERROR"
        private const val CHANNEL_ID = "falcon_vpn_connection"
        private const val NOTIFICATION_ID = 7101
    }
}
