package com.falconvpn.app.vpn.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ShadowsocksLinkParserTest {
    @Test fun parsesSip002Link() {
        val link = "ss://YWVzLTEyOC1nY206c2hhZG93c29ja3M=@37.19.198.236:443#%F0%9F%87%BA%F0%9F%87%B8US-37.19.198.236-0169"
        val profile = ShadowsocksLinkParser.parse(link)
        assertEquals("37.19.198.236", profile.host)
        assertEquals(443, profile.port)
        assertEquals("aes-128-gcm", profile.method)
        assertEquals("shadowsocks", profile.password)
        assertTrue(profile.name.contains("US-37.19.198.236-0169"))
    }

    @Test fun rejectsNonShadowsocksLink() {
        try {
            ShadowsocksLinkParser.parse("https://example.com")
            throw AssertionError("Expected invalid link to be rejected")
        } catch (_: IllegalArgumentException) {
            // Expected.
        }
    }
}
