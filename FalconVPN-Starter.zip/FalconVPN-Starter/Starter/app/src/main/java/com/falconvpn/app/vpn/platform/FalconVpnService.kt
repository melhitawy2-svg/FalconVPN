package com.falconvpn.app.vpn.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.vpnstarter.MainActivity

/**
 * Android VPN lifecycle entry point for Falcon VPN.
 *
 * Safety behavior: this scaffold does not call startForeground() or create a TUN
 * interface until the libbox PlatformInterface + service lifecycle are wired.
 * It therefore cannot claim a connection is active and intentionally stops on
 * START until the real engine adapter is supplied.
 */
class FalconVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf(startId)
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        closeTun()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        closeTun()
        super.onDestroy()
    }

    private fun closeTun() {
        try { tun?.close() } catch (_: Exception) { }
        tun = null
    }

    companion object {
        const val ACTION_START = "com.falconvpn.app.vpn.START"
        const val ACTION_STOP = "com.falconvpn.app.vpn.STOP"
    }
}
