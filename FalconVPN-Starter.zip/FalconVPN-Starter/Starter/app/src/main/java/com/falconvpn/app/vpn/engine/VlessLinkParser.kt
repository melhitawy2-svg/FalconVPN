package com.falconvpn.app.vpn.engine

import java.net.URI
import java.net.URLDecoder
import org.json.JSONObject

/** Parses common vless:// share URIs. Parsing/importing does not establish a VPN tunnel. */
data class VlessProfile(
    val name: String,
    val host: String,
    val port: Int,
    val uuid: String,
    val security: String,
    val sni: String,
    val transport: String,
    val path: String,
    val wsHost: String
)

object VlessLinkParser {
    fun parse(rawLink: String): VlessProfile {
        val raw = rawLink.trim()
        require(raw.startsWith("vless://", ignoreCase = true)) { "Not a VLESS link" }
        val uri = URI(raw)
        val host = uri.host ?: throw IllegalArgumentException("رابط VLESS لا يحتوي على عنوان السيرفر")
        val port = uri.port
        require(port in 1..65535) { "منفذ السيرفر غير صالح" }
        val uuid = uri.rawUserInfo?.let { URLDecoder.decode(it, "UTF-8") }
            ?: throw IllegalArgumentException("رابط VLESS لا يحتوي على UUID")
        require(uuid.matches(Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}"))) {
            "UUID في رابط VLESS غير صالح"
        }
        val query = linkedMapOf<String, String>()
        uri.rawQuery.orEmpty().split('&').filter { it.isNotBlank() }.forEach { pair ->
            val k = pair.substringBefore('=')
            val v = pair.substringAfter('=', "")
            query[URLDecoder.decode(k, "UTF-8")] = URLDecoder.decode(v, "UTF-8")
        }
        val security = query["security"]?.lowercase() ?: "none"
        require(security in setOf("none", "tls", "reality")) { "نوع الحماية غير مدعوم في رابط VLESS" }
        val transport = query["type"]?.lowercase() ?: "tcp"
        require(transport in setOf("ws", "tcp", "grpc", "httpupgrade", "http")) { "نوع النقل غير مدعوم حاليًا: $transport" }
        var path = query["path"].orEmpty()
        // Some sharing services double-encode the path (%252F -> %2F -> /).
        repeat(2) {
            if (path.contains("%")) runCatching { URLDecoder.decode(path, "UTF-8") }.getOrNull()?.let { path = it }
        }
        if (transport == "ws" && path.isBlank()) path = "/"
        val name = uri.rawFragment?.let { URLDecoder.decode(it, "UTF-8") }
            ?.takeIf { it.isNotBlank() } ?: "VLESS server"
        return VlessProfile(
            name = name,
            host = host,
            port = port,
            uuid = uuid,
            security = security,
            sni = query["sni"].orEmpty().ifBlank { query["serverName"].orEmpty() },
            transport = transport,
            path = path,
            wsHost = query["host"].orEmpty()
        )
    }

    fun toStoredJson(profile: VlessProfile, id: String): JSONObject = JSONObject()
        .put("id", id).put("name", profile.name).put("host", profile.host).put("port", profile.port)
        .put("protocol", "VLESS").put("uuid", profile.uuid).put("security", profile.security)
        .put("sni", profile.sni).put("transport", profile.transport).put("path", profile.path)
        .put("ws_host", profile.wsHost)
}
