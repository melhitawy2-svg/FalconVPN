package com.example.vpnstarter

import android.os.Bundle
import android.content.Context
import android.content.ClipboardManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFF2CB25)
private val Navy = Color(0xFF17123F)
private val Canvas = Color(0xFFF7F7FB)
private val Green = Color(0xFF19B86A)

private data class ConfigProfile(val id: Long, val name: String, val protocol: String, val raw: String, val source: String)

private fun detectProtocol(raw: String): String? {
    val value = raw.trim()
    return when {
        value.startsWith("vless://", true) -> "VLESS"
        value.startsWith("vmess://", true) -> "VMess"
        value.startsWith("trojan://", true) -> "Trojan"
        value.startsWith("ss://", true) -> "Shadowsocks"
        value.startsWith("ssh://", true) -> "SSH"
        value.startsWith("socks://", true) || value.startsWith("socks5://", true) -> "SOCKS5"
        value.startsWith("{", true) || value.startsWith("[", true) -> "JSON"
        else -> null
    }
}

private fun loadProfiles(context: Context): List<ConfigProfile> {
    return try {
        val json = JSONArray(context.getSharedPreferences("falcon_profiles", Context.MODE_PRIVATE).getString("profiles", "[]"))
        (0 until json.length()).map { i ->
            val item = json.getJSONObject(i)
            ConfigProfile(item.getLong("id"), item.getString("name"), item.getString("protocol"), item.getString("raw"), item.optString("source", "Imported"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveProfiles(context: Context, profiles: List<ConfigProfile>) {
    val json = JSONArray()
    profiles.forEach { p -> json.put(JSONObject().put("id", p.id).put("name", p.name).put("protocol", p.protocol).put("raw", p.raw).put("source", p.source)) }
    context.getSharedPreferences("falcon_profiles", Context.MODE_PRIVATE).edit().putString("profiles", json.toString()).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VpnApp() } }
    }
}

private data class Server(val flag: String, val name: String, val detail: String, val ping: String)
private val sampleServers = listOf(
    Server("🇪🇬", "Egypt • Demo profile", "Sample entry — not a live server", "—"),
    Server("🇺🇸", "United States • Demo profile", "Sample entry — not a live server", "—"),
    Server("🇬🇧", "United Kingdom • Demo profile", "Sample entry — not a live server", "—"),
    Server("🇨🇦", "Canada • Demo profile", "Sample entry — not a live server", "—"),
    Server("🇸🇦", "Saudi Arabia • Demo profile", "Sample entry — not a live server", "—"),
    Server("🇲🇦", "Morocco • Demo profile", "Sample entry — not a live server", "—")
)

@Composable
private fun VpnApp() {
    var page by remember { mutableStateOf("Home") }
    var connected by remember { mutableStateOf(false) }
    var remainingMinutes by remember { mutableIntStateOf(15) }
    var selectedServer by remember { mutableStateOf(sampleServers[0]) }
    var darkMode by remember { mutableStateOf(false) }
    var timerEnabled by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val context = LocalContext.current
    val profiles = remember { mutableStateListOf<ConfigProfile>().apply { addAll(loadProfiles(context)) } }
    var pendingExport by remember { mutableStateOf<ConfigProfile?>(null) }
    val fileImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val added = importProfiles(text, "File", profiles)
                if (added > 0) { saveProfiles(context, profiles); Toast.makeText(context, "Imported $added config(s)", Toast.LENGTH_LONG).show() }
                else Toast.makeText(context, "No supported config found in this file", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(context, "Could not read file", Toast.LENGTH_LONG).show() }
        }
    }
    val fileExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        val profile = pendingExport
        if (uri != null && profile != null) {
            try { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(profile.raw) }; Toast.makeText(context, "Config exported", Toast.LENGTH_SHORT).show() }
            catch (_: Exception) { Toast.makeText(context, "Export failed", Toast.LENGTH_LONG).show() }
        }
        pendingExport = null
    }
    val bg = if (darkMode) Color(0xFF101018) else Canvas
    val fg = if (darkMode) Color.White else Color(0xFF20202A)

    Scaffold(
        containerColor = bg,
        topBar = {
            TopAppBarSimple(
                title = when (page) {
                    "Servers" -> "Choose a server"
                    "Settings" -> "Settings"
                    "Tools" -> "Tools"
                    "Config" -> "Config manager"
                    else -> "Falcon VPN"
                },
                onMenu = { page = if (page == "Settings") "Home" else "Settings" },
                fg = fg
            )
        },
        bottomBar = {
            NavigationBar(containerColor = if (darkMode) Color(0xFF1B1B27) else Color.White) {
                listOf("Home" to Icons.Default.Home, "Servers" to Icons.Default.Public, "Config" to Icons.Default.FolderOpen, "Settings" to Icons.Default.Settings).forEach { (label, icon) ->
                    NavigationBarItem(selected = page == label, onClick = { page = label }, icon = { Icon(icon, null) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Navy, indicatorColor = Gold))
                }
            }
        }
    ) { padding ->
        when (page) {
            "Servers" -> ServerScreen(padding, search, { search = it }, selectedServer) { selectedServer = it; page = "Home" }
            "Settings" -> SettingsScreen(padding, darkMode, { darkMode = it }, timerEnabled, { timerEnabled = it }, { page = "Tools" }, { page = "Config" }, fg)
            "Tools" -> ToolsScreen(padding, fg)
            "Config" -> ConfigScreen(
                padding = padding, fg = fg, profiles = profiles,
                onPaste = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                    val added = importProfiles(text, "Clipboard", profiles)
                    if (added > 0) { saveProfiles(context, profiles); Toast.makeText(context, "Imported $added config(s)", Toast.LENGTH_LONG).show() }
                    else Toast.makeText(context, "No supported config found in clipboard", Toast.LENGTH_LONG).show()
                },
                onPickFile = { fileImport.launch(arrayOf("text/*", "application/json", "application/octet-stream")) },
                onExport = { profile -> pendingExport = profile; fileExport.launch("falcon-${profile.protocol.lowercase()}-${profile.id}.txt") },
                onDelete = { profile -> profiles.removeAll { it.id == profile.id }; saveProfiles(context, profiles) },
                onAddManual = { raw ->
                    val added = importProfiles(raw, "Manual", profiles)
                    if (added > 0) { saveProfiles(context, profiles); Toast.makeText(context, "Config saved", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(context, "Unsupported format. Paste a supported URI or JSON config.", Toast.LENGTH_LONG).show()
                }
            )
            else -> HomeScreen(
                padding, connected, {
                    connected = false
                    Toast.makeText(context, "محرك VPN الحقيقي لسه مش مدمج؛ لم يتم إنشاء اتصال.", Toast.LENGTH_LONG).show()
                }, selectedServer,
                { page = "Servers" }, fg, darkMode, remainingMinutes,
                onWatchRewardAd = {
                    Toast.makeText(context, "إعلانات الفيديو المكافأة لم يتم ربطها بعد؛ لن يُضاف الوقت قبل مشاهدة إعلان فعلي.", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}

@Composable
private fun TopAppBarSimple(title: String, onMenu: () -> Unit, fg: Color) {
    Row(Modifier.fillMaxWidth().background(Gold).statusBarsPadding().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Navy)
        IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Navy) }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, connected: Boolean, onConnect: () -> Unit, server: Server, onServers: () -> Unit, fg: Color, dark: Boolean, remainingMinutes: Int, onWatchRewardAd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(18.dp))
        Text("SECURE CONNECTION", color = if (connected) Green else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(220.dp).background(if (dark) Color(0xFF22213A) else Color.White, CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(174.dp).background(Navy, CircleShape).clickable { onConnect() }, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PowerSettingsNew, null, tint = Gold, modifier = Modifier.size(66.dp))
                    Text(if (connected) "CONNECTED" else "CONNECT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(if (connected) "Connection active" else "VPN engine not integrated", color = fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Server profiles can be imported, but a real tunnel is not available in this build.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Card(Modifier.fillMaxWidth().clickable { onServers() }, colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF22213A) else Color.White), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(server.flag, fontSize = 30.sp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Selected server", color = Color.Gray, fontSize = 12.sp)
                    Text(server.name, color = fg, fontWeight = FontWeight.SemiBold)
                    Text(server.ping, color = Green, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = fg)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("DOWNLOAD", "0 KB/s", fg, dark, Modifier.weight(1f))
            StatCard("UPLOAD", "0 KB/s", fg, dark, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Text("Ad space", color = Color.Gray, fontSize = 11.sp)
        Card(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF22213A) else Color.White),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Gold.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = if (dark) Gold else Navy)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("Connection time", color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Your free time balance", color = Color.Gray, fontSize = 12.sp)
                    }
                    Text("${remainingMinutes} min", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { (remainingMinutes / 15f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = Green,
                    trackColor = Color.Gray.copy(alpha = 0.2f)
                )
                Spacer(Modifier.height(10.dp))
                Text("Start with 15 minutes free. Watch a rewarded video to earn 15 extra minutes.", color = fg, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onWatchRewardAd,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Navy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Gold)
                    Spacer(Modifier.width(8.dp))
                    Text("Watch video • +15 minutes", color = Color.White)
                }
                Text("Rewarded ads are not connected in this prototype yet.", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Privacy first • Connection statistics are placeholders until VPN integration", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String, fg: Color, dark: Boolean, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF22213A) else Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(value, color = fg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun ServerScreen(padding: PaddingValues, search: String, onSearch: (String) -> Unit, selected: Server, onChoose: (Server) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search country or server") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(12.dp))
        Text("SERVER LOCATIONS", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(sampleServers.filter { it.name.contains(search, true) || it.detail.contains(search, true) }) { server ->
                Card(Modifier.fillMaxWidth().clickable { onChoose(server) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (server == selected) Gold else Color(0xFFE7E7E7))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(server.flag, fontSize = 28.sp)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(server.name, color = Color(0xFF242430), fontWeight = FontWeight.SemiBold)
                            Text(server.detail, color = Color.Gray, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(server.ping, color = Green, fontSize = 12.sp)
                            RadioButton(selected = server == selected, onClick = { onChoose(server) }, colors = RadioButtonDefaults.colors(selectedColor = Gold))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(padding: PaddingValues, darkMode: Boolean, onDark: (Boolean) -> Unit, timer: Boolean, onTimer: (Boolean) -> Unit, onTools: () -> Unit, onConfig: () -> Unit, fg: Color) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
        item { SectionTitle("UI SETTINGS") }
        item { SettingSwitch("Enable dark mode", "Change app appearance", Icons.Default.Palette, darkMode, onDark) }
        item { SectionTitle("CONFIG UPDATE") }
        item { SettingRow("Online update", "Fetch approved config updates", Icons.Default.CloudDownload, onConfig) }
        item { SettingRow("Offline update", "Import a local config file", Icons.Default.FileOpen, onConfig) }
        item { SettingRow("Clipboard update", "Import copied config text", Icons.Default.ContentPaste, onConfig) }
        item { SectionTitle("TIMER NOTIFICATION") }
        item { SettingSwitch("Connection timer", "Show connection duration", Icons.Default.Timer, timer, onTimer) }
        item { SectionTitle("VPN SETTINGS") }
        item { SettingRow("VPN settings", "Protocol and connection options", Icons.Default.Tune, onTools) }
        item { SectionTitle("TOOLS") }
        item { SettingRow("IP check", "Check public IP after connecting", Icons.Default.Public, onTools) }
        item { SettingRow("Custom DNS", "Configure DNS where supported", Icons.Default.Dns, onTools) }
        item { SettingRow("Battery optimization", "Background connection guidance", Icons.Default.BatteryChargingFull, onTools) }
        item { SettingRow("Privacy & permissions", "Review app permissions", Icons.Default.Security, onTools) }
        item { Spacer(Modifier.height(20.dp)) }
        item { Text("Prototype only: connection, imports, DNS and server checks need implementation and testing.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 24.dp)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, modifier = Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 8.dp), color = Color.Gray, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(27.dp))
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, fontSize = 17.sp, color = Color(0xFF242430))
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
    HorizontalDivider(color = Color(0xFFE8E8EC))
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(27.dp))
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, fontSize = 17.sp, color = Color(0xFF242430))
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
        }
        Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Navy, checkedTrackColor = Gold))
    }
    HorizontalDivider(color = Color(0xFFE8E8EC))
}

@Composable
private fun ToolsScreen(padding: PaddingValues, fg: Color) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Tools", color = fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        listOf("IP check" to "A real IP lookup will be connected later.", "Custom DNS" to "DNS controls depend on the selected VPN protocol.", "Battery guidance" to "Instructions for reliable background operation.", "Diagnostics" to "Connection logs should avoid storing sensitive data.").forEach { (title, body) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.SemiBold, color = Color(0xFF242430)); Text(body, color = Color.Gray, fontSize = 13.sp) }
            }
        }
    }
}

private fun importProfiles(input: String, source: String, profiles: MutableList<ConfigProfile>): Int {
    val trimmedInput = input.trim()
    val candidates = if (trimmedInput.startsWith("{") || trimmedInput.startsWith("[")) listOf(trimmedInput)
        else trimmedInput.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
    var added = 0
    candidates.forEach { raw ->
        val protocol = detectProtocol(raw) ?: return@forEach
        val duplicate = profiles.any { it.raw == raw }
        if (!duplicate) {
            val name = when {
                raw.startsWith("{") || raw.startsWith("[") -> "Imported JSON config"
                else -> raw.substringAfter("#", "").takeIf { it.isNotBlank() }?.let { Uri.decode(it) }
                    ?: "${protocol} server ${profiles.count { it.protocol == protocol } + 1}"
            }
            profiles.add(ConfigProfile(System.currentTimeMillis() + added, name, protocol, raw, source))
            added++
        }
    }
    return added
}

@Composable
private fun ConfigScreen(
    padding: PaddingValues,
    fg: Color,
    profiles: List<ConfigProfile>,
    onPaste: () -> Unit,
    onPickFile: () -> Unit,
    onExport: (ConfigProfile) -> Unit,
    onDelete: (ConfigProfile) -> Unit,
    onAddManual: (String) -> Unit
) {
    var showManual by remember { mutableStateOf(false) }
    var rawConfig by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("Server & Config Manager", color = fg, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Import supported links or JSON profiles. Shadowsocks links can be parsed for engine integration; this prototype does not yet establish a VPN tunnel.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { showManual = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Add manually") }
            OutlinedButton(onClick = onPaste, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(5.dp)); Text("Paste") }
        }
        OutlinedButton(onClick = onPickFile, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(8.dp)); Text("Import file") }
        Spacer(Modifier.height(12.dp))
        Text("SAVED PROFILES (${profiles.size})", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        if (profiles.isEmpty()) {
            Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(18.dp)) {
                    Icon(Icons.Default.CloudUpload, null, tint = Gold, modifier = Modifier.size(30.dp))
                    Text("No configs yet", color = Color(0xFF242430), fontWeight = FontWeight.SemiBold)
                    Text("Add a VLESS, VMess, Trojan, Shadowsocks, SSH/SOCKS URI or a compatible JSON config.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(profiles, key = { it.id }) { profile ->
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(13.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Dns, null, tint = Gold, modifier = Modifier.size(28.dp))
                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                    Text(profile.name, color = Color(0xFF242430), fontWeight = FontWeight.SemiBold)
                                    Text("${profile.protocol} • ${profile.source}", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { onExport(profile) }) { Icon(Icons.Default.FileDownload, null); Text("Export") }
                                TextButton(onClick = { onDelete(profile) }) { Icon(Icons.Default.DeleteOutline, null); Text("Delete") }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Security: configs may contain credentials. Do not share them publicly. Profiles are stored locally in app preferences and are not encrypted in this prototype.", color = Color.Gray, fontSize = 11.sp)
    }
    if (showManual) {
        AlertDialog(
            onDismissRequest = { showManual = false },
            title = { Text("Add config") },
            text = {
                Column {
                    Text("Paste one supported URI or a JSON config. Multiple newline-separated links can also be imported.", fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = rawConfig, onValueChange = { rawConfig = it }, label = { Text("Config link or JSON") }, minLines = 4, maxLines = 8)
                }
            },
            confirmButton = { TextButton(onClick = { onAddManual(rawConfig); rawConfig = ""; showManual = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showManual = false }) { Text("Cancel") } }
        )
    }
}
